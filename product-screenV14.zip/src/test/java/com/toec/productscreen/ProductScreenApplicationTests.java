package com.toec.productscreen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductScreenApplicationTests {

    @Test
    void contextLoads() {
    }

}

﻿使用模版相关页面等置于templates文件夹下的各自文件下,
用于存放jsp、thymeleaf等模板文件

多用户多页面显示
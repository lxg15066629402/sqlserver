package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/12 0012 9:40
 */

import java.util.Date;
import java.util.List;

/**
 * 工单计划编制表表体
 */
public class PlAssemblyPlanDetail {

    // 1 工单计划表表体ID
    private int id;
    // 2 时间戳
    private Date ts;
    // 3 工单计划编制表表头ID
    private  int assemblyPlanID;
    // 4 计划序号
    private int listNo;
    // 5 工单号
    private String worOrder ;
    // 6 物料ID
    //private int materialID;
    // 替换 materialSpc
    private String materialID;
    // 7 物料编码
    private String materialCode;
    // 8 物料名称
    private String materialName;
    // 9 数量
    private int quantity;
    // 10 开始时间
    private String onlineTime;
    // 11 结束时间
    private String offlineTime;
    // 12 客户订单号
    private String customerOrder;
    // 13 交货日期
    private String deliveryDate;
    // 14 客户ID
    private  int  customerID;
    // 15 客户代码
    private String  customerCode;
    // 16 客户名称
    private String   customerName;
    // 17 出货地ID
    private int sendPlaceID;
    // 18 出货地代码
    private String sendPlaceCode;
    // 19 出货地名称
    private  String  getSendPlaceName;
    // 20 是否发布
    private Boolean isPublish;
    // 21 是否锁定
    private Boolean isLock;
    // 22 扩展字段1（销售订单号）
    private String extendOne;
    // 23 扩展字段2 （ERP 物料编码）
    private String extendTwo;
    // 24 拓展字段3 （ERP 物料名称）
    private String extendThree;
    // 25 拓展字段4
    private String extendFour;
    // 26 拓展字段5
    private String extendFive;
    // 27  是否做首件
    private boolean useFAI;
    // 28 首件数量
    private int falQty;
    // 29 首件结果
    private int falResult;
    // 30 工艺ID
    private int routingID;
    // 31 是否启用
    private boolean isUsing;
    // 32 备料状态
    private int pickMaterialStatus;
    // 33 是否返工
    private  Boolean isRework;
    // 34 软件版本号ID
    private int softVisionID;

    // 35 与 OpPlanExecutMain
    private List<OpPlanExecutMain> opPlanExecutMainList;

    // 36 与 PlAssemblyPlan
    private List<PlAssemblyPlan>  plAssemblyPlanList;

    // 37 生产产能
    private int totalQty;

    // 38  产线名称
    private String assemblyLineName;

    // 生产报备表 与 opMesFbStartAndEnd
    private List<OpMesFbStartAndEnd> opMesFbStartAndEndList;

    // 完成数量
    private int  computerNumber;

    // 累计完成数量
    private int accumulateNumber;

    // 下线数量
    private int offlineNumber;

    // 完成情况
    private  Boolean IsCompleted2;

    // 生产订单表
    private List<BaMO2> baMO2List;

    // 生产任务单号 -- 任务单号
    private String moNo;

    // 单据类型   -- 生产类型
    private String  moType;

    // 加入对应的get set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getAssemblyPlanID() {
        return assemblyPlanID;
    }

    public void setAssemblyPlanID(int assemblyPlanID) {
        this.assemblyPlanID = assemblyPlanID;
    }

    public int getListNo() {
        return listNo;
    }

    public void setListNo(int listNo) {
        this.listNo = listNo;
    }

    public String getWorOrder() {
        return worOrder;
    }

    public void setWorOrder(String worOreder) {
        this.worOrder = worOreder;
    }

//    public int getMaterialID() {
//        return materialID;
//    }
//
//    public void setMaterialID(int materialID) {
//        this.materialID = materialID;
//    }


    public String getMaterialID() {
        return materialID;
    }

    public void setMaterialID(String materialID) {
        this.materialID = materialID;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getOnlineTime() {
        return onlineTime;
    }

    public void setOnlineTime(String onlineTime) {
        this.onlineTime = onlineTime;
    }

    public String getOfflineTime() {
        return offlineTime;
    }

    public void setOfflineTime(String offlineTime) {
        this.offlineTime = offlineTime;
    }

    public String getCustomerOrder() {
        return customerOrder;
    }

    public void setCustomerOrder(String customerOrder) {
        this.customerOrder = customerOrder;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getSendPlaceID() {
        return sendPlaceID;
    }

    public void setSendPlaceID(int sendPlaceID) {
        this.sendPlaceID = sendPlaceID;
    }

    public String getSendPlaceCode() {
        return sendPlaceCode;
    }

    public void setSendPlaceCode(String sendPlaceCode) {
        this.sendPlaceCode = sendPlaceCode;
    }

    public String getGetSendPlaceName() {
        return getSendPlaceName;
    }

    public void setGetSendPlaceName(String getSendPlaceName) {
        this.getSendPlaceName = getSendPlaceName;
    }

    public Boolean getPublish() {
        return isPublish;
    }

    public void setPublish(Boolean publish) {
        isPublish = publish;
    }

    public Boolean getLock() {
        return isLock;
    }

    public void setLock(Boolean lock) {
        isLock = lock;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public String getExtendThree() {
        return extendThree;
    }

    public void setExtendThree(String extendThree) {
        this.extendThree = extendThree;
    }

    public String getExtendFour() {
        return extendFour;
    }

    public void setExtendFour(String extendFour) {
        this.extendFour = extendFour;
    }

    public String getExtendFive() {
        return extendFive;
    }

    public void setExtendFive(String extendFive) {
        this.extendFive = extendFive;
    }

    public Boolean getRework() {
        return isRework;
    }

    public void setRework(Boolean rework) {
        isRework = rework;
    }

    public boolean isUseFAI() {
        return useFAI;
    }

    public void setUseFAI(boolean useFAI) {
        this.useFAI = useFAI;
    }

    public int getFalQty() {
        return falQty;
    }

    public void setFalQty(int falQty) {
        this.falQty = falQty;
    }

    public int getFalResult() {
        return falResult;
    }

    public void setFalResult(int falResult) {
        this.falResult = falResult;
    }

    public int getRoutingID() {
        return routingID;
    }

    public void setRoutingID(int routingID) {
        this.routingID = routingID;
    }

    public boolean isUsing() {
        return isUsing;
    }

    public void setUsing(boolean using) {
        isUsing = using;
    }

    public int getPickMaterialStatus() {
        return pickMaterialStatus;
    }

    public void setPickMaterialStatus(int pickMaterialStatus) {
        this.pickMaterialStatus = pickMaterialStatus;
    }

    public int getSoftVisionID() {
        return softVisionID;
    }

    public void setSoftVisionID(int softVisionID) {
        this.softVisionID = softVisionID;
    }

    public List<OpPlanExecutMain> getOpPlanExecutMainList() {
        return opPlanExecutMainList;
    }

    public void setOpPlanExecutMainList(List<OpPlanExecutMain> opPlanExecutMainList) {
        this.opPlanExecutMainList = opPlanExecutMainList;
    }

    public List<PlAssemblyPlan> getPlAssemblyPlanList() {
        return plAssemblyPlanList;
    }

    public void setPlAssemblyPlanList(List<PlAssemblyPlan> plAssemblyPlanList) {
        this.plAssemblyPlanList = plAssemblyPlanList;
    }

    public int getTotalQty() {
        return totalQty;
    }

    public void setTotalQty(int totalQty) {
        this.totalQty = totalQty;
    }


    public String getAssemblyLineName() {
        return assemblyLineName;
    }

    public void setAssemblyLineName(String assemblyLineName) {
        this.assemblyLineName = assemblyLineName;
    }

    public List<OpMesFbStartAndEnd> getOpMesFbStartAndEndList() {
        return opMesFbStartAndEndList;
    }

    public void setOpMesFbStartAndEndList(List<OpMesFbStartAndEnd> opMesFbStartAndEndList) {
        this.opMesFbStartAndEndList = opMesFbStartAndEndList;
    }

    public int getComputerNumber() {
        return computerNumber;
    }

    public void setComputerNumber(int computerNumber) {
        this.computerNumber = computerNumber;
    }

    public int getAccumulateNumber() {
        return accumulateNumber;
    }

    public void setAccumulateNumber(int accumulateNumber) {
        this.accumulateNumber = accumulateNumber;
    }

    public int getOfflineNumber() {
        return offlineNumber;
    }

    public void setOfflineNumber(int offlineNumber) {
        this.offlineNumber = offlineNumber;
    }

    public Boolean getCompleted2() {
        return IsCompleted2;
    }

    public void setCompleted2(Boolean completed2) {
        IsCompleted2 = completed2;
    }

    public List<BaMO2> getBaMO2List() {
        return baMO2List;
    }

    public void setBaMO2List(List<BaMO2> baMO2List) {
        this.baMO2List = baMO2List;
    }

    public String getMoNo() {
        return moNo;
    }

    public void setMoNo(String moNo) {
        this.moNo = moNo;
    }

    public String getMoType() {
        return moType;
    }

    public void setMoType(String moType) {
        this.moType = moType;
    }
}

package com.toec.productscreen.business.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.toec.productscreen.business.entity.QlBadAcquistionMain;
import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.socket.WebSocketServer;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : Jone
 * @date : 20:55 2021/3/8 0008
 * @function :
 */
public class RepairInfo {

    /**
     * 维修看板
     * item=5
     */
    /**
     * 今日维修完成率
     */
    public void getTodayRepair(WebSocketServer webSocketServer, ProdectService prodectService, String item){
        try{
            List<QlBadAcquistionMain> todayRepairTest = prodectService.findTodayRepairData();

            // 创建一个map 对象
            Map<String, Object> todayRepairExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayRepairExtTest=new ArrayList<>();
            // 初始化信息
            todayRepairExtTest.put("code", 0);
            todayRepairExtTest.put("type", "1");
            for(QlBadAcquistionMain todayRepairTestItem: todayRepairTest) {

                DecimalFormat df = new DecimalFormat("#.0");
                // 创建一个Map 对象
                Map<String, Object> todayRepair = new LinkedHashMap<String, Object>();

                // 完成数量
                todayRepair.put("completeNumber", todayRepairTestItem.getCompleteNumber());
                // 总维修数量
                todayRepair.put("allNumber", todayRepairTestItem.getAllNumber());

                // 今日维修完成率
                float repairRate = (float) todayRepairTestItem.getCompleteNumber() / (float)todayRepairTestItem.getAllNumber();

                todayRepair.put("repairRate", (int)(repairRate*100));
                // todayRepair.put("repairRate",df.format(repairRate));

                tempTodayRepairExtTest.add(todayRepair);
            }

            todayRepairExtTest.put("data", tempTodayRepairExtTest);
            // Json 序列化
            String todayRepairData = JSON.toJSONString(todayRepairExtTest); //

            System.out.println(todayRepairData);

            webSocketServer.sendOneMessage(item, todayRepairData);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     *  今日维修不良统计
     *  item=5
     */
    public void getRepairError(WebSocketServer webSocketServer, ProdectService prodectService, String item) {
        try{
            List<QlBadAcquistionMain> todayErrorTest =  prodectService.findTodayErroData();

            // 创建一个map 对象
            Map<String, Object> todayErrorExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayErrorExtTest=new ArrayList<>();
            // 初始化信息
            todayErrorExtTest.put("code", 0);
            todayErrorExtTest.put("type", "2");
            for(QlBadAcquistionMain todayErrorTestItem: todayErrorTest) {
                // 创建一个Map 对象
                Map<String, Object> todayError = new LinkedHashMap<String, Object>();

                // 补焊
                todayError.put("typeOne", todayErrorTestItem.getTypeOne());


                // 创建一个Map 对象
                Map<String, Object> todayErrorOne = new LinkedHashMap<String, Object>();
                todayErrorOne.put("name", "补焊");
                todayErrorOne.put("value", todayErrorTestItem.getTypeOne());


                // 虚焊
                Map<String, Object> todayErrorTwo = new LinkedHashMap<String, Object>();
                todayErrorTwo.put("name", "虚焊");
                todayErrorTwo.put("value", todayErrorTestItem.getTypeTwo());

                // 调整物料
                Map<String, Object> todayErrorThree = new LinkedHashMap<String, Object>();
                todayErrorThree.put("name", "调整物料");
                todayErrorThree.put("value", todayErrorTestItem.getTypeThree());
                // 更换补料
                Map<String, Object> todayErrorFour = new LinkedHashMap<String, Object>();
                todayErrorFour.put("name", "更换补料");
                todayErrorFour.put("value", todayErrorTestItem.getTypeFour());
                // 无法维修
                Map<String, Object> todayErrorFive = new LinkedHashMap<String, Object>();
                todayErrorFive.put("name", "无法维修");
                todayErrorFive.put("value", todayErrorTestItem.getTypeFive());

                tempTodayErrorExtTest.add(todayErrorOne);
                tempTodayErrorExtTest.add(todayErrorTwo);
                tempTodayErrorExtTest.add(todayErrorThree);
                tempTodayErrorExtTest.add(todayErrorFour);
                tempTodayErrorExtTest.add(todayErrorFive);
            }

            todayErrorExtTest.put("data", tempTodayErrorExtTest);
            // Json 序列化
            String todayErrorData = JSON.toJSONString(todayErrorExtTest); //

            System.out.println(todayErrorData);

            webSocketServer.sendOneMessage(item, todayErrorData);

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 一周维修数量趋势
     * item=5
     */
    public void getWeekRepair(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{


            List<QlBadAcquistionMain> weekRepairTest = prodectService.findWeekRepairData();

            // 创建一个map 对象
            Map<String, Object> weekRepairExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempweekRepairExtTest=new ArrayList<>();

            // 初始化信息
            weekRepairExtTest.put("code", 0);
            weekRepairExtTest.put("type", "3");

            Map<String, Object> weekRepair = new LinkedHashMap<String, Object>();
            JSONArray jsonWeekNumber = new JSONArray();

            // 获取当日数据
            Date date = new Date();

            int completeSum = 0;

            int completeSum1 = 0;

            int completeSum2 = 0;

            int completeSum3 = 0;

            int completeSum4 = 0;

            int completeSum5 = 0;

            int completeSum6 = 0;

            int completeSum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeRepairTest = new LinkedHashMap<String, Object>();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(QlBadAcquistionMain weekRepairTestItem: weekRepairTest){

                // 获取一周的数据
                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(weekRepairTestItem.getRepairTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    completeSum = completeSum + weekRepairTestItem.getCompleteNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    completeSum1 = completeSum1 + weekRepairTestItem.getCompleteNumber();

                }else if(weekdaysql == 3){
                    completeSum2 = completeSum2 + weekRepairTestItem.getCompleteNumber();

                }else if(weekdaysql == 4){
                    completeSum3 = completeSum3 + weekRepairTestItem.getCompleteNumber();

                }else if(weekdaysql == 5){
                    completeSum4 = completeSum4 + weekRepairTestItem.getCompleteNumber();

                }else if(weekdaysql == 6){
                    completeSum5 = completeSum5 + weekRepairTestItem.getCompleteNumber();

                }else if(weekdaysql == 7){
                    completeSum6 = completeSum6 + weekRepairTestItem.getCompleteNumber();

                }else if(weekdaysql == 0){
                    completeSum7 = completeSum7 + weekRepairTestItem.getCompleteNumber();

                }

            }

            jsonWeekNumber.add(completeSum1);
            jsonWeekNumber.add(completeSum2);
            jsonWeekNumber.add(completeSum3);
            jsonWeekNumber.add(completeSum4);
            jsonWeekNumber.add(completeSum5);
            jsonWeekNumber.add(completeSum6);
            jsonWeekNumber.add(completeSum7);

            // 计划完成一周趋势
            weekRepair.put("weekRepairNumber", jsonWeekNumber);
            tempweekRepairExtTest.add(weekRepair);

            weekRepairExtTest.put("data", tempweekRepairExtTest);
            // Json 序列化
            String weekData = JSON.toJSONString(weekRepairExtTest); //

            System.out.println(weekData);

            webSocketServer.sendOneMessage(item, weekData);

        }catch(Exception e){
            e.printStackTrace();
        }

    }
    /**
     * 维修执行情况
     */
    public void getRepairTable(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{
            List<QlBadAcquistionMain> repairTableTest =  prodectService.findRepairTableData();

            // 创建一个map 对象
            Map<String, Object> repairTableExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempRepairTableExtTest=new ArrayList<>();
            // 初始化信息
            repairTableExtTest.put("code", 0);
            repairTableExtTest.put("type", "4");

            for(QlBadAcquistionMain repairTableTestItem: repairTableTest){
                // 创建一个Map 对象
                Map<String, Object> repairtableTest = new LinkedHashMap<String, Object>();

                // 生产线
                repairtableTest.put("assemblyLineName", repairTableTestItem.getAssemblyLineName());

                // 任务单号
                repairtableTest.put("moNO", repairTableTestItem.getMoNo());

                // 不良工序编码
                repairtableTest.put("procedureCode", repairTableTestItem.getProcedureCode());

                // 物料条码
                repairtableTest.put("barCode", repairTableTestItem.getBarCode());

                // 维修类别
                repairtableTest.put("lineRemark",repairTableTestItem.getLineRemark());

                // 维修信息
                repairtableTest.put("lv1_PoorName", repairTableTestItem.getLv1_PoorName());
                // 创建人
                repairtableTest.put("createUser", repairTableTestItem.getCreateUser());
                // 问题原因
                repairtableTest.put("poorReason", repairTableTestItem.getPoorReason());
                // 维修人
                repairtableTest.put("repairUser", repairTableTestItem.getRepairUser());
                // 维修状态
                if(repairTableTestItem.isRepair() == true){
                    repairtableTest.put("isRepair", "维修完成");
                }else{
                    repairtableTest.put("isRepair", "待维修");
                }


                tempRepairTableExtTest.add(repairtableTest);

            }

            repairTableExtTest.put("data", tempRepairTableExtTest);
            // Json 序列化
            String repairTableData = JSON.toJSONString(repairTableExtTest); //

            System.out.println(repairTableData);

            webSocketServer.sendOneMessage(item, repairTableData);
        }catch(Exception e){
            e.printStackTrace();
        }

    }
}

package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/29 0029 16:38
 */

import java.util.Date;
import java.util.List;

/**
 * 备料主表
 */
public class PlMaterialPickMain {

    // 1
    private int id;

    // 2
    private Date ts;

    // 3
    private int fStatus;

    // 4
    private Date fDate;

    // 5
    // private int  billType;
    private String billType;

    // 6
    private String billNo;

    // 7
    private int  moID;

    // 8
    private String moNo;

    // 9
    private int planDetailID;

    // 10
    private String workOrder;

    // 11
    // private int CompleteStatus;
    private String CompleteStatus;

    // 12
    private String remark;

    // 13
    private int crtUserID;

    // 14
    private Date crtTime;

    // 15
    private String icStockOutBillNo;

    // 16
    private int applicantUserID;

    // 17
    private int stockModel;

    // 18
    private boolean noNeedPickConfirm;

    // 19
    private int allBill;

    // 20
    private int completeBill;

    // 21
    private List<SyUser> syUserList;

    // 22
    private String userName;


    // list
    private List<PlMaterialPickDetail> plMaterialPickDetailList;

    //
    private List<TStockPlace> tStockPlaceList;

    //
    private List<BaMaterial> baMaterialList;

    //
    private String materialName;

    //
    private int  BatchNo;

    //
    private int  planPickedQty;

    //
    private String fName;

    //
    private String custos;

    // get set  方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getfStatus() {
        return fStatus;
    }

    public void setfStatus(int fStatus) {
        this.fStatus = fStatus;
    }

    public Date getfDate() {
        return fDate;
    }

    public void setfDate(Date fDate) {
        this.fDate = fDate;
    }

//    public int getBillType() {
//        return billType;
//    }
//
//    public void setBillType(int billType) {
//        this.billType = billType;
//    }


    public String getBillType() {
        return billType;
    }

    public void setBillType(String billType) {
        this.billType = billType;
    }

    public String getBillNo() {
        return billNo;
    }

    public void setBillNo(String billNo) {
        this.billNo = billNo;
    }

    public int getMoID() {
        return moID;
    }

    public void setMoID(int moID) {
        this.moID = moID;
    }

    public String getMoNo() {
        return moNo;
    }

    public void setMoNo(String moNo) {
        this.moNo = moNo;
    }

    public int getPlanDetailID() {
        return planDetailID;
    }

    public void setPlanDetailID(int planDetailID) {
        this.planDetailID = planDetailID;
    }

    public String getWorkOrder() {
        return workOrder;
    }

    public void setWorkOrder(String workOrder) {
        this.workOrder = workOrder;
    }

//    public int getCompleteStatus() {
//        return CompleteStatus;
//    }
//
//    public void setCompleteStatus(int completeStatus) {
//        CompleteStatus = completeStatus;
//    }


    public String getCompleteStatus() {
        return CompleteStatus;
    }

    public void setCompleteStatus(String completeStatus) {
        CompleteStatus = completeStatus;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public int getCrtUserID() {
        return crtUserID;
    }

    public void setCrtUserID(int crtUserID) {
        this.crtUserID = crtUserID;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public String getIcStockOutBillNo() {
        return icStockOutBillNo;
    }

    public void setIcStockOutBillNo(String icStockOutBillNo) {
        this.icStockOutBillNo = icStockOutBillNo;
    }

    public int getApplicantUserID() {
        return applicantUserID;
    }

    public void setApplicantUserID(int applicantUserID) {
        this.applicantUserID = applicantUserID;
    }

    public int getStockModel() {
        return stockModel;
    }

    public void setStockModel(int stockModel) {
        this.stockModel = stockModel;
    }

    public boolean isNoNeedPickConfirm() {
        return noNeedPickConfirm;
    }

    public void setNoNeedPickConfirm(boolean noNeedPickConfirm) {
        this.noNeedPickConfirm = noNeedPickConfirm;
    }

    public int getAllBill() {
        return allBill;
    }

    public void setAllBill(int allBill) {
        this.allBill = allBill;
    }

    public int getCompleteBill() {
        return completeBill;
    }

    public void setCompleteBill(int completeBill) {
        this.completeBill = completeBill;
    }

    public List<SyUser> getSyUserList() {
        return syUserList;
    }

    public void setSyUserList(List<SyUser> syUserList) {
        this.syUserList = syUserList;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }


    public List<PlMaterialPickDetail> getPlMaterialPickDetailList() {
        return plMaterialPickDetailList;
    }

    public void setPlMaterialPickDetailList(List<PlMaterialPickDetail> plMaterialPickDetailList) {
        this.plMaterialPickDetailList = plMaterialPickDetailList;
    }

    public List<TStockPlace> gettStockPlaceList() {
        return tStockPlaceList;
    }

    public void settStockPlaceList(List<TStockPlace> tStockPlaceList) {
        this.tStockPlaceList = tStockPlaceList;
    }

    public List<BaMaterial> getBaMaterialList() {
        return baMaterialList;
    }

    public void setBaMaterialList(List<BaMaterial> baMaterialList) {
        this.baMaterialList = baMaterialList;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public int getBatchNo() {
        return BatchNo;
    }

    public void setBatchNo(int batchNo) {
        BatchNo = batchNo;
    }

    public int getPlanPickedQty() {
        return planPickedQty;
    }

    public void setPlanPickedQty(int planPickedQty) {
        this.planPickedQty = planPickedQty;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getCustos() {
        return custos;
    }

    public void setCustos(String custos) {
        this.custos = custos;
    }
}

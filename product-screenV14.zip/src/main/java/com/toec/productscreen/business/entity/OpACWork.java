package com.toec.productscreen.business.entity;

import java.util.Date;

/**
 * @Author Jone
 * @Date 2021/1/13 0013 9:24
 */

/**
 * opACWork
 */
public class OpACWork {
    // 1
    private int id;

    // 2
    private String acCode;

    // 3
    private String acName;

    // 4
    private int bookDay;

    // 5
    private int bookHour;

    // 6
    private int bookMinute;

    // 7
    private int bookTotal;

    // 8
    private int  capacity;

    // 9
    private int currentCount;

    // 10
    private String currentState;

    // 11
    private Date  startTime;

    // 12
    private Date  lastStartTime;

    // 13
    private String pauseRecord;

    // 14
    private  Date  endTime;

    // 15
    private  int takeTime;

    // 16
    private String remark;

    // 17  时间戳
    private Date ts;

    // 添加get/ set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAcCode() {
        return acCode;
    }

    public void setAcCode(String acCode) {
        this.acCode = acCode;
    }

    public String getAcName() {
        return acName;
    }

    public void setAcName(String acName) {
        this.acName = acName;
    }

    public int getBookDay() {
        return bookDay;
    }

    public void setBookDay(int bookDay) {
        this.bookDay = bookDay;
    }

    public int getBookHour() {
        return bookHour;
    }

    public void setBookHour(int bookHour) {
        this.bookHour = bookHour;
    }

    public int getBookMinute() {
        return bookMinute;
    }

    public void setBookMinute(int bookMinute) {
        this.bookMinute = bookMinute;
    }

    public int getBookTotal() {
        return bookTotal;
    }

    public void setBookTotal(int bookTotal) {
        this.bookTotal = bookTotal;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getCurrentCount() {
        return currentCount;
    }

    public void setCurrentCount(int currentCount) {
        this.currentCount = currentCount;
    }

    public String getCurrentState() {
        return currentState;
    }

    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getLastStartTime() {
        return lastStartTime;
    }

    public void setLastStartTime(Date lastStartTime) {
        this.lastStartTime = lastStartTime;
    }

    public String getPauseRecord() {
        return pauseRecord;
    }

    public void setPauseRecord(String pauseRecord) {
        this.pauseRecord = pauseRecord;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public int getTakeTime() {
        return takeTime;
    }

    public void setTakeTime(int takeTime) {
        this.takeTime = takeTime;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String toString() {

        return "{" +
                "ID：" + id +  ", " +
                "BookDay：" + bookDay + ", " +
                "BookHour：" + bookHour + ", " +
                "BookMinute：" + bookMinute + ", " +
                "BookTotal：" + bookTotal + "," +
                "CurrentCount：" + currentCount + "," +
                "StartTime：" + startTime + "," +
                "LastStartTime：" + lastStartTime + ", " +
                "PauseRecord：" + pauseRecord + ", " +
                "EndTime：" + endTime + ", " +
                "TakeTime：" + takeTime + ", " +
                "Remark：" + remark + "," +
                "CurrentState：" + currentState + ", " +
                "EndTime2：" + endTime + ", " +
                "StartTime2：" + startTime +
                "}";
    }
}

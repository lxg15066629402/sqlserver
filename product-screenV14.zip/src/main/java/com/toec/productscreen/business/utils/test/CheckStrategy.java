package com.toec.productscreen.business.utils.test;

import lombok.extern.slf4j.Slf4j;

/**
 * @author : Jone
 * @date : 22:31 2021/3/11 0011
 * @function :
 */
// 插装抽象类
@Slf4j
public class CheckStrategy extends AbstractTest{

    @Override
        public String screenID(String id) {
        log.info("插装线看板号：={}", id);
        return id;
    }
}

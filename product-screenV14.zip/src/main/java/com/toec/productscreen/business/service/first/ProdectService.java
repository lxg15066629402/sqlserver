package com.toec.productscreen.business.service.first;

import com.toec.productscreen.business.dao.first.ProductDao;
import com.toec.productscreen.business.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Jone
 * @function ProductService 业务逻辑层
 * @date: 2021/1/14
 */

@Service
public class ProdectService {

    @Autowired
    private ProductDao productDao;


    /**
     * 查找插装线看板数据 screenId = 1
     */
    // 按时
    public List<PlAssemblyPlanDetail> findDoingCheckData(){
        return productDao.findDoingCheckData();
    }

    // 一周计划记录
    public List<PlAssemblyPlanDetail> findWeekCheckData(){
        return productDao.findWeekCheckData();
    }

    // 一周按时记录
    public List<PlAssemblyPlanDetail> findWeektimeCheckData(){
        return productDao.findWeektimeCheckData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableCheckData(){
        return productDao.findTableCheckData();
    }


    /**
     * 查找总装线数据 screenId = 2
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingAssemblyData(){
        return productDao.findDoingAssemblyData();
    };

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekAssemblyData(){
        return productDao.findWeekAssemblyData();
    };

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeAssemblyData(){
        return productDao.findWeektimeAssemblyData();
    };

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableAssemblyData(){
        return productDao.findTableAssemblyData();
    };


    /**
     * 查找整机测试线数据 screenId = 3
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingWholeData(){
        return productDao.findDoingWholeData();
    };

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekWholeData(){
        return productDao.findWeekWholeData();
    };

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeWholeData(){
        return productDao.findWeektimeWholeData();
    };

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableWholeData(){
        return productDao.findTableWholeData();
    };


    /**
     * 查找部件看板数据 screenId = 6
     */
    // 按时
    public List<PlAssemblyPlanDetail> findDoingPartsOneData(){
        return productDao.findDoingPartsOneData();
    }

    // 一周计划记录
    public List<PlAssemblyPlanDetail> findWeekPartsOneData(){
        return productDao.findWeekPartsOneData();
    }

    // 一周按时记录
    public List<PlAssemblyPlanDetail> findWeektimePartsOneData(){
        return productDao.findWeektimePartsOneData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTablePartsOneData(){
        return productDao.findTablePartsOneData();
    }


    /**
     * 查找部件2看板数据 screenId = 7
     */
    // 按时
    public List<PlAssemblyPlanDetail> findDoingPartsTwoData(){
        return productDao.findDoingPartsTwoData();
    }

    // 一周计划记录
    public List<PlAssemblyPlanDetail> findWeekPartsTwoData(){
        return productDao.findWeekPartsTwoData();
    }

    // 一周按时记录
    public List<PlAssemblyPlanDetail> findWeektimePartsTwoData(){
        return productDao.findWeektimePartsTwoData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTablePartsTwoData(){
        return productDao.findTablePartsTwoData();
    }


    /**
     * 查看包装线看板数据 screenId = 10
     */
    public List<PlAssemblyPlanDetail> findPackingData(){
        return productDao.findPackingData();
    }

    // 进行中
    public List<PlAssemblyPlanDetail> findDoingPackingData(){
        return productDao.findDoingPackingData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekPackingData(){
        return productDao.findWeekPackingData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimePackingData(){
        return productDao.findWeektimePackingData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTablePackingData(){
        return productDao.findTablePackingData();
    }


    /**
     * 查看电装%线看板数据 screenId = 8
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingFittingData(){
        return productDao.findDoingFittingData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekFittingData(){
        return productDao.findWeekFittingData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeFittingData(){
        return productDao.findWeektimeFittingData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableFittingData(){
        return productDao.findTableFittingData();
    }


    /**
     * 查看自动传动线看板数据 screenId = 9
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingAutoData(){
        return productDao.findDoingAutoData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekAutoData(){
        return productDao.findWeekAutoData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeAutoData(){
        return productDao.findWeektimeAutoData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableAutoData(){
        return productDao.findTableAutoData();
    }


    /**
     * 测试拉看板数据 screenId = 18
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingTestData(){
        return productDao.findDoingTestData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekTestData(){
        return productDao.findWeekTestData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeTestData(){
        return productDao.findWeektimeTestData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableTestData(){
        return productDao.findTableTestData();
    }


    /**
     * 电装贴片1 screenId = 11
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdOneData(){
        return productDao.findDoingSmdOneData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdOneData(){
        return productDao.findWeekSmdOneData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdOneData(){
        return productDao.findWeektimeSmdOneData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdOneData(){
        return productDao.findTableSmdOneData();
    }

    /**
     * 电装贴片2 screenId = 12
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdTwoData(){
        return productDao.findDoingSmdTwoData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdTwoData(){
        return productDao.findWeekSmdTwoData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdTwoData(){
        return productDao.findWeektimeSmdTwoData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdTwoData(){
        return productDao.findTableSmdTwoData();
    }


    /**
     * 电装贴片3 screenId = 13
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdThreeData(){
        return productDao.findDoingSmdThreeData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdThreeData(){
        return productDao.findWeekSmdThreeData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdThreeData(){
        return productDao.findWeektimeSmdThreeData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdThreeData(){
        return productDao.findTableSmdThreeData();
    }


    /**
     * 电装贴片4 screenId = 14
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdFourData(){
        return productDao.findDoingSmdFourData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdFourData(){
        return productDao.findWeekSmdFourData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdFourData(){
        return productDao.findWeektimeSmdFourData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdFourData(){
        return productDao.findTableSmdFourData();
    }


    /**
     * 电装贴片5线看板数据 screenId = 15
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdFiveData(){
        return productDao.findDoingSmdFiveData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdFiveData(){
        return productDao.findWeekSmdFiveData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdFiveData(){
        return productDao.findWeektimeSmdFiveData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdFiveData(){
        return productDao.findTableSmdFiveData();
    }


    /**
     * 电装贴片6 screenId = 16
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdSixData(){
        return productDao.findDoingSmdSixData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdSixData(){
        return productDao.findWeekSmdSixData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdSixData(){
        return productDao.findWeektimeSmdSixData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdSixData(){
        return productDao.findTableSmdSixData();
    }


    /**
     * 电装贴片7 screenId = 17
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdSevenData(){
        return productDao.findDoingSmdSevenData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdSevenData(){
        return productDao.findWeekSmdSevenData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdSevenData(){
        return productDao.findWeektimeSmdSevenData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdSevenData(){
        return productDao.findTableSmdSevenData();
    }


    /**
     * 维修线看板信息 screenId = 5
     */
    // 维修执行情况
    public List<QlBadAcquistionMain> findRepairTableData(){
        return productDao.findRepairTableData();
    }

    // 今日维修完成率
    public List<QlBadAcquistionMain>  findTodayRepairData(){
        return productDao.findTodayRepairData();
    }

    // 今日维修不良统计
    public List<QlBadAcquistionMain> findTodayErroData(){
        return productDao.findTodayErroData();
    }

    // 一周维修数量趋势
    public List<QlBadAcquistionMain> findWeekRepairData(){
        return productDao.findWeekRepairData();
    }


    /**
     * 查找老化看板信息 screenId = 4
     */
    public List<OpAgingCar> findOldData() {
        return productDao.findOldData();
    }


    /**
     * 备料线信息 screenId = 19
     */
    // 备料执行情况
    public List<PlMaterialPickMain>  findBillTableData(){
        return productDao.findBillTableData();
    }

    // 今日备料完成率
    public List<PlMaterialPickMain> findBillTodayData(){
        return productDao.findBillTodayData();
    }

    // 一周备料频次趋势
    public List<PlMaterialPickMain> findWeekBillData(){
        return productDao.findWeekBillData();
    }

    // 入库信息
    public List<PrdMORPT> findInData(){
            return productDao.findInData();
    }

    // 出库信息
    public List<PlMaterialPickMain> findOutData(){
        return productDao.findOutData();
    }


    /**
     * 测试数据
     */
    public  List<OpAgingCar>  findTets(){
        return productDao.findTets();
    }



}

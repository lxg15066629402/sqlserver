package com.toec.productscreen.business.utils.test;

import lombok.extern.slf4j.Slf4j;

/**
 * @author : Jone
 * @date : 22:36 2021/3/11 0011
 * @function :
 */
@Slf4j
public class AssemblyStrategy extends AbstractTest{

    @Override
    public String screenID(String id) {
        return id;
    }
}

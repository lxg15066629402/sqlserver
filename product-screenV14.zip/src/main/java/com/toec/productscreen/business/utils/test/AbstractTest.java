package com.toec.productscreen.business.utils.test;

/**
 * @author : Jone
 * @date : 22:28 2021/3/11 0011
 * @function :
 */
// 首先建立一个 大屏版号的 抽象类AbstractTest
public abstract class AbstractTest {

    public abstract String  screenID(String id);
}

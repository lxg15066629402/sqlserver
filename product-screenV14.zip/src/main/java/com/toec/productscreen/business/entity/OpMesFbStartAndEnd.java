package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/19 0019 10:53
 */

import java.util.Date;

/**
 * 部件生产报工表
 */
public class OpMesFbStartAndEnd {
    // ID
    private int id;

    // 装备ID
    private int assemblyPlanDetailID;

    // 时间戳
    private Date ts;

    // 开始时间
    private String fStartTime;

    // 结束时间
    private String fEndTime;

    // 上报数据
    private int qty;

    // get set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAssemblyPlanDetailID() {
        return assemblyPlanDetailID;
    }

    public void setAssemblyPlanDetailID(int assemblyPlanDetailID) {
        this.assemblyPlanDetailID = assemblyPlanDetailID;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String getfStartTime() {
        return fStartTime;
    }

    public void setfStartTime(String fStartTime) {
        this.fStartTime = fStartTime;
    }

    public String getfEndTime() {
        return fEndTime;
    }

    public void setfEndTime(String fEndTime) {
        this.fEndTime = fEndTime;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
}

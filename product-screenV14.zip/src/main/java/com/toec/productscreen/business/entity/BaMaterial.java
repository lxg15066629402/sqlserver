package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/2/8 0008 17:08
 */

import java.util.Date;

/**
 * 物料档案表
 */
public class BaMaterial {

    // 内码 ID
    private int id;

    // 2 时间戳
    private Date ts;

    // 3 物料分类
    private int materialTypeID;

    // 4 物料编码
    private String materialCode;

    // 5 物料名称
    private String materialName;

    // 6 品牌（条码格式）
    private String brand;

    // 7 颜色
    private String color;

    // 8 允许最低直通率
    private int lowerFPY;

    // 9 纹理 （允许维修次数）
    private String texture;

    // 10 是否纸盒包装
    private boolean isBox;

    // 11 规格
    private String spec;

    // 12 规格2
    private String spec2;

    // 13 单位
    private String  unit;

    // 14 重量
    private int  weight;

    // 15 备注
    private String remark;

    // 16 是否可以转单
    private boolean isCanChangePO;

    // 17 每卡板重量
    private int palletSumWight;

    // 18 每箱重量
    private int boxWeight;

    // 19 每卡板卡通数
    private int boxCount;

    // 20 每箱单机头数
    private int perBoxCount;

    // 21 彩盒数量
    private int colorBoxCount;

    // 22
    private int  palletRoughWeight;

    // 23 保险检查提醒
    private int inspect;

    // 24
    private int lastInspectDD;

    // 25
    private boolean isUseRouting;

    // 26
    private String newBrand;

    // 27 旧物料编码
    private String oldMaterialCode;

    // 28 保管人
    private String custos;

    // 29
    private String materialTpye;

    // 30
    private String modelType;

    // 31
    private String extendOne;

    // 32
    private String extendTwo;

    // 33
    private String extendThree;

    // 34
    private int innerBoxPrtTmpID;

    // 35
    private int outerBoxPrtTmpID;

    // 36
    private int pallerPrtTmpID;

    // 37
    private int formalBarcodePrtTmpID;

    // 38
    private String oldMaterialName;

    // 39
    private String f_bqdymc;

    // 40
    private String f_bqxh;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getMaterialTypeID() {
        return materialTypeID;
    }

    public void setMaterialTypeID(int materialTypeID) {
        this.materialTypeID = materialTypeID;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getLowerFPY() {
        return lowerFPY;
    }

    public void setLowerFPY(int lowerFPY) {
        this.lowerFPY = lowerFPY;
    }

    public String getTexture() {
        return texture;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }

    public boolean isBox() {
        return isBox;
    }

    public void setBox(boolean box) {
        isBox = box;
    }

    public String getSpec() {
        return spec;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }

    public String getSpec2() {
        return spec2;
    }

    public void setSpec2(String spec2) {
        this.spec2 = spec2;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public boolean isCanChangePO() {
        return isCanChangePO;
    }

    public void setCanChangePO(boolean canChangePO) {
        isCanChangePO = canChangePO;
    }

    public int getPalletSumWight() {
        return palletSumWight;
    }

    public void setPalletSumWight(int palletSumWight) {
        this.palletSumWight = palletSumWight;
    }

    public int getBoxWeight() {
        return boxWeight;
    }

    public void setBoxWeight(int boxWeight) {
        this.boxWeight = boxWeight;
    }

    public int getBoxCount() {
        return boxCount;
    }

    public void setBoxCount(int boxCount) {
        this.boxCount = boxCount;
    }

    public int getPerBoxCount() {
        return perBoxCount;
    }

    public void setPerBoxCount(int perBoxCount) {
        this.perBoxCount = perBoxCount;
    }

    public int getColorBoxCount() {
        return colorBoxCount;
    }

    public void setColorBoxCount(int colorBoxCount) {
        this.colorBoxCount = colorBoxCount;
    }

    public int getPalletRoughWeight() {
        return palletRoughWeight;
    }

    public void setPalletRoughWeight(int palletRoughWeight) {
        this.palletRoughWeight = palletRoughWeight;
    }

    public int getInspect() {
        return inspect;
    }

    public void setInspect(int inspect) {
        this.inspect = inspect;
    }

    public int getLastInspectDD() {
        return lastInspectDD;
    }

    public void setLastInspectDD(int lastInspectDD) {
        this.lastInspectDD = lastInspectDD;
    }

    public boolean isUseRouting() {
        return isUseRouting;
    }

    public void setUseRouting(boolean useRouting) {
        isUseRouting = useRouting;
    }

    public String getNewBrand() {
        return newBrand;
    }

    public void setNewBrand(String newBrand) {
        this.newBrand = newBrand;
    }

    public String getOldMaterialCode() {
        return oldMaterialCode;
    }

    public void setOldMaterialCode(String oldMaterialCode) {
        this.oldMaterialCode = oldMaterialCode;
    }

    public String getCustos() {
        return custos;
    }

    public void setCustos(String custos) {
        this.custos = custos;
    }

    public String getMaterialTpye() {
        return materialTpye;
    }

    public void setMaterialTpye(String materialTpye) {
        this.materialTpye = materialTpye;
    }

    public String getModelType() {
        return modelType;
    }

    public void setModelType(String modelType) {
        this.modelType = modelType;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public String getExtendThree() {
        return extendThree;
    }

    public void setExtendThree(String extendThree) {
        this.extendThree = extendThree;
    }

    public int getInnerBoxPrtTmpID() {
        return innerBoxPrtTmpID;
    }

    public void setInnerBoxPrtTmpID(int innerBoxPrtTmpID) {
        this.innerBoxPrtTmpID = innerBoxPrtTmpID;
    }

    public int getOuterBoxPrtTmpID() {
        return outerBoxPrtTmpID;
    }

    public void setOuterBoxPrtTmpID(int outerBoxPrtTmpID) {
        this.outerBoxPrtTmpID = outerBoxPrtTmpID;
    }

    public int getPallerPrtTmpID() {
        return pallerPrtTmpID;
    }

    public void setPallerPrtTmpID(int pallerPrtTmpID) {
        this.pallerPrtTmpID = pallerPrtTmpID;
    }

    public int getFormalBarcodePrtTmpID() {
        return formalBarcodePrtTmpID;
    }

    public void setFormalBarcodePrtTmpID(int formalBarcodePrtTmpID) {
        this.formalBarcodePrtTmpID = formalBarcodePrtTmpID;
    }

    public String getOldMaterialName() {
        return oldMaterialName;
    }

    public void setOldMaterialName(String oldMaterialName) {
        this.oldMaterialName = oldMaterialName;
    }

    public String getF_bqdymc() {
        return f_bqdymc;
    }

    public void setF_bqdymc(String f_bqdymc) {
        this.f_bqdymc = f_bqdymc;
    }

    public String getF_bqxh() {
        return f_bqxh;
    }

    public void setF_bqxh(String f_bqxh) {
        this.f_bqxh = f_bqxh;
    }
}

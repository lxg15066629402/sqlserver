package com.toec.productscreen.business.dao.first;

import com.toec.productscreen.business.entity.*;
import com.toec.productscreen.business.mapper.first.ProductMapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * @author Jone
 * @function ProductDao
 * @date: 2021/2/14
 */
@Repository
public class ProductDao {

    @Autowired
    private ProductMapper productMapper;


    /**
     * 查找插装线看板数据 screenId = 1
     */
    // 进行中的项目
    public List<PlAssemblyPlanDetail> findDoingCheckData(){
        return productMapper.findDoingCheckData();
    }

    // 一周计划完成趋势
    public List<PlAssemblyPlanDetail> findWeekCheckData(){
        return productMapper.findWeekCheckData();
    }

    // 一周按时完成趋势
    public List<PlAssemblyPlanDetail> findWeektimeCheckData(){
        return productMapper.findWeektimeCheckData();
    }

    // 项目执行情况
    public List<PlAssemblyPlanDetail> findTableCheckData(){
        return productMapper.findTableCheckData();
    }


    /**
     * 查找总装线数据 screenId = 2
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingAssemblyData(){
        return productMapper.findDoingAssemblyData();
    };

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekAssemblyData(){
        return productMapper.findWeekAssemblyData();
    };

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeAssemblyData(){
        return productMapper.findWeektimeAssemblyData();
    };

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableAssemblyData(){
        return productMapper.findTableAssemblyData();
    };


    /**
     * 查找整机测试线数据 screenId = 3
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingWholeData(){
        return productMapper.findDoingWholeData();
    };

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekWholeData(){
        return productMapper.findWeekWholeData();
    };

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeWholeData(){
        return productMapper.findWeektimeWholeData();
    };

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableWholeData(){
        return productMapper.findTableWholeData();
    };


    /**
     * 查找部件1看板数据 screenId = 6
     */
    public List<PlAssemblyPlanDetail> findPartsOneData(){
        return productMapper.findPartsOneData();
    }

    // 进行中的项目
    public List<PlAssemblyPlanDetail> findDoingPartsOneData(){
        return productMapper.findDoingPartsOneData();
    }

    // 一周计划完成趋势
    public List<PlAssemblyPlanDetail> findWeekPartsOneData(){
        return productMapper.findWeekPartsOneData();
    }

    // 一周按时完成趋势
    public List<PlAssemblyPlanDetail> findWeektimePartsOneData(){
        return productMapper.findWeektimePartsOneData();
    }

    // 项目执行情况
    public List<PlAssemblyPlanDetail> findTablePartsOneData(){
        return productMapper.findTablePartsOneData();
    }


    /**
     * 查找部件2看板数据 screenId = 7
     */
    public List<PlAssemblyPlanDetail> findPartsTwoData(){
        return productMapper.findPartsTwoData();
    }

    // 进行中的项目
    public List<PlAssemblyPlanDetail> findDoingPartsTwoData(){
        return productMapper.findDoingPartsTwoData();
    }

    // 一周计划完成趋势
    public List<PlAssemblyPlanDetail> findWeekPartsTwoData(){
        return productMapper.findWeekPartsTwoData();
    }

    // 一周按时完成趋势
    public List<PlAssemblyPlanDetail> findWeektimePartsTwoData(){
        return productMapper.findWeektimePartsTwoData();
    }

    // 项目执行情况
    public List<PlAssemblyPlanDetail> findTablePartsTwoData(){
        return productMapper.findTablePartsTwoData();
    }


    /**
     * 查看包装线看板数据 screenId = 10
     */
    public List<PlAssemblyPlanDetail> findPackingData(){
        return productMapper.findPackingData();
    }

    // 进行中
    public List<PlAssemblyPlanDetail> findDoingPackingData(){
        return productMapper.findDoingPackingData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekPackingData(){
        return productMapper.findWeekPackingData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimePackingData(){
        return productMapper.findWeektimePackingData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTablePackingData(){
        return productMapper.findTablePackingData();
    }


    /**
     * 查看电装%线看板数据 screenId = 8
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingFittingData(){
        return productMapper.findDoingFittingData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekFittingData(){
       return productMapper.findWeekFittingData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeFittingData(){
        return productMapper.findWeektimeFittingData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableFittingData(){
       return productMapper.findTableFittingData();
    }


    /**
     * 查看自动传动线看板数据 screenId = 9
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingAutoData(){
        return productMapper.findDoingAutoData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekAutoData(){
        return productMapper.findWeekAutoData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeAutoData(){
        return productMapper.findWeektimeAutoData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableAutoData(){
        return productMapper.findTableAutoData();
    }


    /**
     * 测试拉看板数据 screenId = 18
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingTestData(){
        return productMapper.findDoingTestData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekTestData(){
        return productMapper.findWeekTestData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeTestData(){
        return productMapper.findWeektimeTestData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableTestData(){
        return productMapper.findTableTestData();
    }


    /**
     * 电装贴片1 screenId = 11
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdOneData(){
        return productMapper.findDoingSmdOneData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdOneData(){
        return productMapper.findWeekSmdOneData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdOneData(){
        return productMapper.findWeektimeSmdOneData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdOneData(){
        return productMapper.findTableSmdOneData();
    }


    /**
     * 电装贴片2  screenId = 12
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdTwoData(){
        return productMapper.findDoingSmdTwoData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdTwoData(){
        return productMapper.findWeekSmdTwoData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdTwoData(){
        return productMapper.findWeektimeSmdTwoData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdTwoData(){
        return productMapper.findTableSmdTwoData();
    }


    /**
     * 电装贴片3 screenId = 13
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdThreeData(){
        return productMapper.findDoingSmdThreeData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdThreeData(){
        return productMapper.findWeekSmdThreeData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdThreeData(){
        return productMapper.findWeektimeSmdThreeData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdThreeData(){
        return productMapper.findTableSmdThreeData();
    }


    /**
     * 电装贴片4 screenId = 14
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdFourData(){
        return productMapper.findDoingSmdFourData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdFourData(){
        return productMapper.findWeekSmdFourData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdFourData(){
        return productMapper.findWeektimeSmdFourData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdFourData(){
        return productMapper.findTableSmdFourData();
    }


    /**
     * 电装贴片5 screenId = 15
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdFiveData(){
        return productMapper.findDoingSmdFiveData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdFiveData(){
        return productMapper.findWeekSmdFiveData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdFiveData(){
        return productMapper.findWeektimeSmdFiveData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdFiveData(){
        return productMapper.findTableSmdFiveData();
    }


    /**
     * 电装贴片6 screenId = 16
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdSixData(){
        return productMapper.findDoingSmdSixData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdSixData(){
        return productMapper.findWeekSmdSixData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdSixData(){
        return productMapper.findWeektimeSmdSixData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdSixData(){
        return productMapper.findTableSmdSixData();
    }


    /**
     * 电装贴片7 screenId = 17
     */
    // 进行中
    public List<PlAssemblyPlanDetail> findDoingSmdSevenData(){
        return productMapper.findDoingSmdSevenData();
    }

    // 周数据信息
    public List<PlAssemblyPlanDetail> findWeekSmdSevenData(){
        return productMapper.findWeekSmdSevenData();
    }

    // 按时完成
    public List<PlAssemblyPlanDetail> findWeektimeSmdSevenData(){
        return productMapper.findWeektimeSmdSevenData();
    }

    // 项目生产执行情况
    public List<PlAssemblyPlanDetail> findTableSmdSevenData(){
        return productMapper.findTableSmdSevenData();
    }


    /**
     * 维修线看板信息 screenId = 5
     */
    // 维修执行情况
    public List<QlBadAcquistionMain> findRepairTableData(){
        return productMapper.findRepairTableData();
    }

    // 今日维修完成率
    public List<QlBadAcquistionMain>  findTodayRepairData(){
        return productMapper.findTodayRepairData();
    }

    // 今日维修不良统计
    public List<QlBadAcquistionMain> findTodayErroData(){
        return productMapper.findTodayErroData();
    }

    // 一周维修数量趋势
    public List<QlBadAcquistionMain> findWeekRepairData(){
        return productMapper.findWeekRepairData();
    }


    /**
     * 查找老化看板信息 screenId = 4
     */
    public List<OpAgingCar> findOldData(){
        return productMapper.findOldData();
    }


    /**
     * 备料线信息 screenId = 19
     */
    // 备料执行情况
    public List<PlMaterialPickMain>  findBillTableData(){
        return productMapper.findBillTableData();
    }

    // 今日备料完成率
    public List<PlMaterialPickMain> findBillTodayData(){
        return productMapper.findBillTodayData();
    }

    // 一周备料频次趋势
    public List<PlMaterialPickMain> findWeekBillData(){
        return productMapper.findWeekBillData();
    }

    // 入库信息
    public List<PrdMORPT> findInData(){
        return productMapper.findInData();
    }

    // 出库信息
    public List<PlMaterialPickMain> findOutData(){
        return productMapper.findOutData();
    }


    /**
     * 测试信息
     */
    public List<OpAgingCar> findTets(){
        return productMapper.findTets();
    }

}

package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/28 0028 13:45
 */

import java.util.Date;

/**
 * 用户定义表
 */
public class SyUser {

    // 1 内码 ID
    private  int id;

    // 2 时间戳
    private Date ts;

    // 3 登录ID
    private String loginID;

    // 4 用户名称
    private String  userName;

    // 5 密码
    private String passWord;

    // 6 是否管理员
    private boolean isAdmin;

    // 7 是否禁用
    private boolean isFreezed;

    // 8 部门ID
    private int organizationID;

    // 9 角色ID
    private int roleID;

    // 10 拓展1
    private String extendOne;

    // 11 拓展
    private String extendTwo;

    // get set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String getLoginID() {
        return loginID;
    }

    public void setLoginID(String loginID) {
        this.loginID = loginID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean admin) {
        isAdmin = admin;
    }

    public boolean isFreezed() {
        return isFreezed;
    }

    public void setFreezed(boolean freezed) {
        isFreezed = freezed;
    }

    public int getOrganizationID() {
        return organizationID;
    }

    public void setOrganizationID(int organizationID) {
        this.organizationID = organizationID;
    }

    public int getRoleID() {
        return roleID;
    }

    public void setRoleID(int roleID) {
        this.roleID = roleID;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }
}

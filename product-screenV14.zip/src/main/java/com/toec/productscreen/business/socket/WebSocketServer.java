package com.toec.productscreen.business.socket;

import com.toec.productscreen.sys.service.serviceImpl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.alibaba.fastjson.JSON;

//import org.apache.commons.lang3.StringEscapeUtils;

/**
 * @Author Jone
 * @Date 2021/1/6 0006 15:11
*/

// 接收websocket 请求路径，传递带参数
@ServerEndpoint(value = "/websocket/{token}/{screenId}")
@Component
public class WebSocketServer {

    // 静态变量， 用来记录当前在线连接数，
    private static int onlineCount = 0;

    // 与某个客户端的连接会话，需要通过它来实现给客户端发送数据
    private Session session;

    //
//    @Autowired
//    private InitData initDataTest;

    /*
    标识当前的token
     */
    private String token;

    /*
    标识当前的 screenId
     */
    private String screenId;

    /*
    初始化一个全局变量
     */
    public static String gscreenId;

    @Autowired
    private UserServiceImpl userServiceImpl;

    /**
     *  用于存所有的连接服务的客户端，这个对象存储是安全的
     */
    // private static ConcurrentHashMap<String, WebSocketServer> webSocketSet = new ConcurrentHashMap<>();
    public static ConcurrentHashMap<String, WebSocketServer> webSocketSet = new ConcurrentHashMap<>();

    /**
     * 连接建立成功调用的方法
     */
    @OnOpen
    public void onOpen(Session session, @PathParam("token") String token,
                       @PathParam("screenId") String  screenId){

        this.session = session;
        this.screenId = screenId;


        // 为了代码强壮性考虑
        // 实际使用的时候发现偶尔会出现重连失败或者其他原因导致之前的session还存在，
        // 这里就做了一个清除旧session，迎接新session的功能。
        if (webSocketSet.containsKey(screenId)){
            webSocketSet.remove(screenId);
            webSocketSet.put(screenId, this);
        }else{
            webSocketSet.put(screenId, this);
            addOnlineCount();
        }
        /**
         * 实际使用的时候发现偶尔会出现重连失败或者其他原因导致之前的session还存在，
         * 这里就做了一个清除旧session，迎接新session的功能。
         */
        // 加入set
        if (webSocketSet.containsKey(screenId)){
            webSocketSet.remove(screenId);
            webSocketSet.put(screenId, this);
        }else{
            webSocketSet.put(screenId, this);
            addOnlineCount();
            // System.out.println("==================================================================" + webSocketSet.keySet());
            // keySet() 方法返回值是Map中key值的集合
            System.out.println("有新连接加入！当前在线人数为：" + getOnlineCount());
        }

        /**
         * 该模块实现的功能与上面的code 实现功能一样
         * webSocketSet.put(screenId,this);
         *
         * System.out.println(webSocketSet);
         * // 在线数加1
         * addOnlineCount();
         * System.out.println("有新连接加入！当前在线人数为：" + getOnlineCount());
         */


        // 获取传递过来的数据 token 、 screenId
        System.out.println("token = " + token);
        System.out.println("screenId = " + screenId);

        gscreenId = screenId;
        // 创建一个map 对象
        Map<String, Object> map = new HashMap<String, Object>(new LinkedHashMap());

        // 判断token 值, 前端获得 token 与 后端 token 进行比较
        if(token.equals(userServiceImpl.token)){
            try {

                map.put("code", 0);
                map.put("screenId", screenId);
                map.put("message", "连接成功");
                // 建立连接后即可发送数据
                InitData initDataTest = new InitData();
                // initDataTest.FirstItemMessage(screenId);

                map.put("initData", initDataTest.FirstItemMessage(screenId));

                // json 转为 string
                String firstData = JSON.toJSONString(map);

                // json 反斜杠问题
                System.out.println("**********************" + firstData);

                sendMessage(firstData);

                // 发送前端数据处理
                // js string转json有斜杠_详解json串反转义（消除反斜杠）
                // String tmp = StringEscapeUtils.unescapeJson(Initdata);
                // sendMessage(tmp);
                // System.out.println("======" + tmp);

            } catch (IOException e) {
                System.out.println("IO异常");
            }
        }else if(!token.equals(userServiceImpl.token)){
            //
            try{
                map.put("code", 1);
                map.put("screenId", screenId);
                map.put("message", "token 不正确");
                String Initdata = JSON.toJSONString(map);
                sendMessage(Initdata);
                onClose();  // 关闭连接
            }catch(IOException e){
                System.out.println("IO异常");
            }

        }
        // 判断 token 失效
        else if(token == null){
            try{
                map.put("code", 2);
                map.put("screenId", screenId);
                map.put("message", "token值失效");
                String Initdata = JSON.toJSONString(map);
                sendMessage(Initdata);
                onClose();
            }catch(IOException e){
                System.out.println("IO异常");
            }

        }
    }

    /**
     * 连接关闭调用的方法
     */
    @OnClose
    public void onClose(){
        // 从set 中删除
         webSocketSet.remove(this.screenId);
        // 在线人数减1
        subOnlineCount();
        System.out.println("有一连接关闭！当前在线人数为" + getOnlineCount());
        System.out.println(session.getId());

    }

    /**
     * 收到客户端消息后调用的方法
     * @param message 客户端发送过来的信息
     */
    @OnMessage
    public void onMessage(String message, Session session){
        System.out.println("来自客户端的消息：" + message);

        //群发消息
        for (String item : webSocketSet.keySet()){
            try{
                webSocketSet.get(item).sendMessage(message);
            }catch (IOException e){
                e.printStackTrace();
            }

        }

    }

    /**
     * 发生错误信息时，调用
     */
    @OnError
    public void onError(Session session, Throwable error){
        System.out.println("错误信息");
        error.printStackTrace();
    }


    /**
     * @Descripation: 实现服务器主动发送信息
     */
    public void sendMessage(String message) throws IOException{
        // System.out.println(this.session.isOpen());
        this.session.getBasicRemote().sendText(message);

    }


    /**
     * @Descripation: 实现服务器主动为指定发送信息
     */
    public static void sendOneMessage(String screenId, String message) throws IOException{
        // 此时不会抛出空指针异常
        // System.out.println(this.session.isOpen());
        try {
            webSocketSet.get(screenId).session.getBasicRemote().sendText(message);
        }catch(Exception e){
            // 防止打印空指针异常
            // e.printStackTrace();
        }

        //webSocketSet.get(screenId).session.getBasicRemote().sendText(message);

    }


    /**
     * @Description: 群发自定义消息
     */
    public static void sendInfo(String message) throws IOException{
        for(String item : webSocketSet.keySet()){
            try{
                webSocketSet.get(item).sendMessage(message);
            }catch(IOException e){
                continue;
            }
        }
    }


    /**
     * @Description 获取当前在线人数
     */
    public static synchronized int getOnlineCount(){
        return onlineCount;
    }

    /**
     * @Description: 在线人数+1
     */
    public static synchronized void addOnlineCount(){
        WebSocketServer.onlineCount++;
    }

    /**
     * @Description: 在线人数-1
     */
    public static synchronized void subOnlineCount(){
        WebSocketServer.onlineCount--;
    }
}


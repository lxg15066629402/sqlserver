package com.toec.productscreen.business.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.toec.productscreen.business.entity.PlMaterialPickMain;
import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.socket.WebSocketServer;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : Jone
 * @date : 22:35 2021/3/8 0008
 * @function :
 */
public class BillInfo {

    /**
     * 备料线信息
     * item=19
     */
    /**
     * 今日备料完成率
     * item= 19
     */
    public void getTodayBill(WebSocketServer webSocketServer, ProdectService prodectService, String item){
        try{
            List<PlMaterialPickMain> billTodayTest = prodectService.findBillTodayData();

            // 创建一个map 对象
            Map<String, Object> todayBillExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayBillExtTest=new ArrayList<>();
            // 初始化信息
            todayBillExtTest.put("code", 0);
            todayBillExtTest.put("type", "1");
            for(PlMaterialPickMain billTodayTestItem: billTodayTest) {

                DecimalFormat df = new DecimalFormat("#");
                // 创建一个Map 对象
                Map<String, Object> todayBill = new LinkedHashMap<String, Object>();

                // 完成数量
                todayBill.put("completeNumber", billTodayTestItem.getCompleteBill());
                // 总维修数量
                todayBill.put("allNumber", billTodayTestItem.getAllBill());

                // 今日维修完成率
                float billRate = (float) billTodayTestItem.getCompleteBill() / (float) billTodayTestItem.getAllBill();

                todayBill.put("billRate", (int)(billRate*100));
                // todayBill.put("billRate", df.format(billRate));

                tempTodayBillExtTest.add(todayBill);
            }

            todayBillExtTest.put("data", tempTodayBillExtTest);
            // Json 序列化
            String todayBillData = JSON.toJSONString(todayBillExtTest); //

            Object to  = todayBillExtTest.get("data");

            System.out.println(todayBillData);

            if(((ArrayList) to).size() != 0){
                webSocketServer.sendOneMessage(item, todayBillData);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 一周备料频次趋势
     * item=19
     */
    public void getBillWeek(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{
            List<PlMaterialPickMain> billWeekTest =  prodectService.findWeekBillData();

            // 创建一个map 对象
            Map<String, Object> billWeekExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempBillWeekTest=new ArrayList<>();
            billWeekExtTest.put("code", 0);
            billWeekExtTest.put("type", "2");


            // 创建一个Map 对象
            Map<String, Object> weekBill = new LinkedHashMap<String, Object>();

            JSONArray jsonWeekNumber = new JSONArray();

            for(PlMaterialPickMain billWeekTestItem: billWeekTest){

                jsonWeekNumber.add(billWeekTestItem.getCompleteBill());

            }

            // 判断jsonWeekNumber
            if(jsonWeekNumber.size() !=7){
                jsonWeekNumber.add(0);
            }

            weekBill.put("weekBillNumber",  jsonWeekNumber);

            tempBillWeekTest.add(weekBill);

            billWeekExtTest.put("data", tempBillWeekTest);

            // Json 序列化
            String weekBillData = JSON.toJSONString(billWeekExtTest); //

            System.out.println(weekBillData);

            webSocketServer.sendOneMessage(item, weekBillData);

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    /**
     *
     * @param item
     */
    // 备料执行情况
    public void getBillTable(WebSocketServer webSocketServer, ProdectService prodectService, String item){
        try{
            List<PlMaterialPickMain> billTableTest = prodectService.findBillTableData();

            // 创建一个map 对象
            Map<String, Object> billTableExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempBillTableTest=new ArrayList<>();
            billTableExtTest.put("code", 0);
            billTableExtTest.put("type", "3");

            for(PlMaterialPickMain billTableTestItem: billTableTest) {

                // 创建一个Map 对象
                Map<String, Object> billTable = new LinkedHashMap<String, Object>();

                // 备料单号
                billTable.put("billNo", billTableTestItem.getBillNo());

                //生产订单号
                billTable.put("moNo", billTableTestItem.getMoNo());

                //备料类型
                billTable.put("billType", billTableTestItem.getBillType());

                //备料状态
                billTable.put("completeStatus", billTableTestItem.getCompleteStatus());

                //备料人
                billTable.put("userName", billTableTestItem.getUserName());

                tempBillTableTest.add(billTable);


            }

            billTableExtTest.put("data", tempBillTableTest);

            String billTableData =  JSON.toJSONString(billTableExtTest);

            Object  bill = billTableExtTest.get("data");

            System.out.println(billTableData);

            if(((ArrayList) bill).size() != 0){
                webSocketServer.sendOneMessage(item, billTableData);
            }


        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

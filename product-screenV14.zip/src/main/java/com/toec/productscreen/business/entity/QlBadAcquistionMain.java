package com.toec.productscreen.business.entity;

import java.util.Date;
import java.util.List;

/**
 * @Author Jone
 * @Date 2021/1/26 0026 18:09
 */

/**
 * 维修表
 */
public class QlBadAcquistionMain {

    //1  ID
    private int id;

    //2  时间戳
    private Date ts;

    //3  工单号
    private String worOrder;

    //4 客户订单号
    private String customerOrder;

    //5 产品条形码
    private String barCode;

    //6 工序ID
    private int procedureID;

    //7 工序编码
    private String procedureCode;

    //8 工序名称
    private String procedureName;

    //9 工位ID
    private int workPartID;

    //10 工位编码
    private String  workPartCode;

    //11 工位名称
    private String workPartName;

    //12
    private int rPoorID;

    //13 不良代码
    private String rPoorCode;

    //14 不良名称
    private String rPoorName;

    //15 不良原因
    private String poorReason;

    //16 创建人ID
    private int creatUserID;

    //17 创建时间
    private String createDate;

    //18 是否维修完成
    private boolean isRepair;

    //19 维修人ID
    private int repairUserID;

    //20 维修时间
    private String repairTime;

    //21
    private String extendOne;

    //22
    private String extendTwo;

    //23
    private String extendThree;

    //24 产品编码
    private String materialCode;

    //25 产品名称
    private String materialName;

    //26
    private int reWorkLineID;

    //27
    private String reWorkLindCode;

    //28
    private String reWorkLineName;

    //29
    private int reWorkProcedureID;

    //30
    private String reWorkProcedureCode;

    //31
    private String reWorkProcedureName;

    //32 是否报废
    private boolean isScrap;

    //33
    private String scrapReason;

    //34
    private int submitOrigin;

    //35 维修类型
    private String lineRemark;

    //36
    private String solution;

    // 用户表
    private List<SyUser> syUserList;

    // 返修登记表表体
    private List<QlBadAcquistionDetail> qlBadAcquistionDetailList;

    // 工单计划表表头
    private List<PlAssemblyPlan> plAssemblyPlanList;

    // 工单计划表表体
    private List<PlAssemblyPlanDetail> plAssemblyPlanDetailList;

    // 生产产线
    private String assemblyLineName;

    // 任务单号
    private String moNo;

    // 维修信息
    private String lv1_PoorName;

    // 创建人
    private String CreateUser;

    // 维修人
    private String  RepairUser;

    // 总数量
    private int allNumber;

    // 完成数量
    private int completeNumber;

    // 类别1
    private String  typeOne;

    // 类别2
    private String typeTwo;

    // 类别3
    private String typeThree;

    // 类别4
    private String typeFour;

    // 类别5
    private String typeFive;



    // get set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String getWorOrder() {
        return worOrder;
    }

    public void setWorOrder(String worOrder) {
        this.worOrder = worOrder;
    }

    public String getCustomerOrder() {
        return customerOrder;
    }

    public void setCustomerOrder(String customerOrder) {
        this.customerOrder = customerOrder;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public int getProcedureID() {
        return procedureID;
    }

    public void setProcedureID(int procedureID) {
        this.procedureID = procedureID;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public int getWorkPartID() {
        return workPartID;
    }

    public void setWorkPartID(int workPartID) {
        this.workPartID = workPartID;
    }

    public String getWorkPartCode() {
        return workPartCode;
    }

    public void setWorkPartCode(String workPartCode) {
        this.workPartCode = workPartCode;
    }

    public String getWorkPartName() {
        return workPartName;
    }

    public void setWorkPartName(String workPartName) {
        this.workPartName = workPartName;
    }

    public int getrPoorID() {
        return rPoorID;
    }

    public void setrPoorID(int rPoorID) {
        this.rPoorID = rPoorID;
    }

    public String getrPoorCode() {
        return rPoorCode;
    }

    public void setrPoorCode(String rPoorCode) {
        this.rPoorCode = rPoorCode;
    }

    public String getrPoorName() {
        return rPoorName;
    }

    public void setrPoorName(String rPoorName) {
        this.rPoorName = rPoorName;
    }

    public String getPoorReason() {
        return poorReason;
    }

    public void setPoorReason(String poorReason) {
        this.poorReason = poorReason;
    }

    public int getCreatUserID() {
        return creatUserID;
    }

    public void setCreatUserID(int creatUserID) {
        this.creatUserID = creatUserID;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public boolean isRepair() {
        return isRepair;
    }

    public void setRepair(boolean repair) {
        isRepair = repair;
    }

    public int getRepairUserID() {
        return repairUserID;
    }

    public void setRepairUserID(int repairUserID) {
        this.repairUserID = repairUserID;
    }

    public String getRepairTime() {
        return repairTime;
    }

    public void setRepairTime(String repairTime) {
        this.repairTime = repairTime;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public String getExtendThree() {
        return extendThree;
    }

    public void setExtendThree(String extendThree) {
        this.extendThree = extendThree;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public int getReWorkLineID() {
        return reWorkLineID;
    }

    public void setReWorkLineID(int reWorkLineID) {
        this.reWorkLineID = reWorkLineID;
    }

    public String getReWorkLindCode() {
        return reWorkLindCode;
    }

    public void setReWorkLindCode(String reWorkLindCode) {
        this.reWorkLindCode = reWorkLindCode;
    }

    public String getReWorkLineName() {
        return reWorkLineName;
    }

    public void setReWorkLineName(String reWorkLineName) {
        this.reWorkLineName = reWorkLineName;
    }

    public int getReWorkProcedureID() {
        return reWorkProcedureID;
    }

    public void setReWorkProcedureID(int reWorkProcedureID) {
        this.reWorkProcedureID = reWorkProcedureID;
    }

    public String getReWorkProcedureCode() {
        return reWorkProcedureCode;
    }

    public void setReWorkProcedureCode(String reWorkProcedureCode) {
        this.reWorkProcedureCode = reWorkProcedureCode;
    }

    public String getReWorkProcedureName() {
        return reWorkProcedureName;
    }

    public void setReWorkProcedureName(String reWorkProcedureName) {
        this.reWorkProcedureName = reWorkProcedureName;
    }

    public boolean isScrap() {
        return isScrap;
    }

    public void setScrap(boolean scrap) {
        isScrap = scrap;
    }

    public String getScrapReason() {
        return scrapReason;
    }

    public void setScrapReason(String scrapReason) {
        this.scrapReason = scrapReason;
    }

    public int getSubmitOrigin() {
        return submitOrigin;
    }

    public void setSubmitOrigin(int submitOrigin) {
        this.submitOrigin = submitOrigin;
    }

    public String getLineRemark() {
        return lineRemark;
    }

    public void setLineRemark(String lineRemark) {
        this.lineRemark = lineRemark;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public List<SyUser> getSyUserList() {
        return syUserList;
    }

    public void setSyUserList(List<SyUser> syUserList) {
        this.syUserList = syUserList;
    }

    public List<QlBadAcquistionDetail> getQlBadAcquistionDetailList() {
        return qlBadAcquistionDetailList;
    }

    public void setQlBadAcquistionDetailList(List<QlBadAcquistionDetail> qlBadAcquistionDetailList) {
        this.qlBadAcquistionDetailList = qlBadAcquistionDetailList;
    }

    public List<PlAssemblyPlan> getPlAssemblyPlanList() {
        return plAssemblyPlanList;
    }

    public void setPlAssemblyPlanList(List<PlAssemblyPlan> plAssemblyPlanList) {
        this.plAssemblyPlanList = plAssemblyPlanList;
    }

    public List<PlAssemblyPlanDetail> getPlAssemblyPlanDetailList() {
        return plAssemblyPlanDetailList;
    }

    public void setPlAssemblyPlanDetailList(List<PlAssemblyPlanDetail> plAssemblyPlanDetailList) {
        this.plAssemblyPlanDetailList = plAssemblyPlanDetailList;
    }

    public String getAssemblyLineName() {
        return assemblyLineName;
    }

    public void setAssemblyLineName(String assemblyLineName) {
        this.assemblyLineName = assemblyLineName;
    }

    public String getMoNo() {
        return moNo;
    }

    public void setMoNo(String moNo) {
        this.moNo = moNo;
    }

    public String getLv1_PoorName() {
        return lv1_PoorName;
    }

    public void setLv1_PoorName(String lv1_PoorName) {
        this.lv1_PoorName = lv1_PoorName;
    }

    public String getCreateUser() {
        return CreateUser;
    }

    public void setCreateUser(String createUser) {
        CreateUser = createUser;
    }

    public String getRepairUser() {
        return RepairUser;
    }

    public void setRepairUser(String repairUser) {
        RepairUser = repairUser;
    }

    public int getAllNumber() {
        return allNumber;
    }

    public void setAllNumber(int allNumber) {
        this.allNumber = allNumber;
    }

    public int getCompleteNumber() {
        return completeNumber;
    }

    public void setCompleteNumber(int completeNumber) {
        this.completeNumber = completeNumber;
    }

    public String getTypeOne() {
        return typeOne;
    }

    public void setTypeOne(String typeOne) {
        this.typeOne = typeOne;
    }

    public String getTypeTwo() {
        return typeTwo;
    }

    public void setTypeTwo(String typeTwo) {
        this.typeTwo = typeTwo;
    }

    public String getTypeThree() {
        return typeThree;
    }

    public void setTypeThree(String typeThree) {
        this.typeThree = typeThree;
    }

    public String getTypeFour() {
        return typeFour;
    }

    public void setTypeFour(String typeFour) {
        this.typeFour = typeFour;
    }

    public String getTypeFive() {
        return typeFive;
    }

    public void setTypeFive(String typeFive) {
        this.typeFive = typeFive;
    }
}

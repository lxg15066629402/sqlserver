package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/28 0028 13:57
 */

import javax.xml.crypto.Data;
import java.util.Date;

/**
 * 返修信息登记表表体
 */
public class QlBadAcquistionDetail {

    // 1 内置ID
    private int id;

    // 2 时间戳
    private Date ts;

    // 3 返修表表头ID
    private int mainID;

    // 4 拓展字段1
    private String extendOne;

    // 5 拓展字段2
    private String  extendTwo;

    // 6 拓展字段3
    private String extendThree;

    // 7 Lv1_生产不良原因ID
    private int lv1_PoorID;

    // 8 Lv1_生产不良原因编码
    private String lv1_PoorCode;

    // 9 Lv1_生产不良原因名称
    private String lv1_PoorName;

    // 10 Lv2_生产不良原因ID
    private int poorID;

    // 11 Lv2_生产不良原因编码
    private String poorCode;

    // 12 Lv2_生产不良原因名称
    private String poorName;

    // 13 Lv3_生产不良原因ID
    private int lv3_PoorID;

    // 14 Lv3_生产不良原因编码
    private String lv3_PoorCode;

    // 15 Lv3_生产不良原因名称
    private String lv3PoorName;

    // 16 Lv4_生产不良原因ID
    private int lv4_PoorID;

    // 17 Lv4_生产不良原因编码
    private String lv4_PoorCode;

    // 18 Lv4_生产不良原因名称
    private String lv4PoorName;

    // 19 Lv5_生产不良原因ID
    private int lv5_PoorID;

    // 20 Lv45_生产不良原因编码
    private String lv5_PoorCode;

    // 21  Lv5_生产不良原因名称
    private String lv5PoorName;
    // 22
    private String  fType;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getMainID() {
        return mainID;
    }

    public void setMainID(int mainID) {
        this.mainID = mainID;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public String getExtendThree() {
        return extendThree;
    }

    public void setExtendThree(String extendThree) {
        this.extendThree = extendThree;
    }

    public int getLv1_PoorID() {
        return lv1_PoorID;
    }

    public void setLv1_PoorID(int lv1_PoorID) {
        this.lv1_PoorID = lv1_PoorID;
    }

    public String getLv1_PoorCode() {
        return lv1_PoorCode;
    }

    public void setLv1_PoorCode(String lv1_PoorCode) {
        this.lv1_PoorCode = lv1_PoorCode;
    }

    public String getLv1_PoorName() {
        return lv1_PoorName;
    }

    public void setLv1_PoorName(String lv1_PoorName) {
        this.lv1_PoorName = lv1_PoorName;
    }

    public int getPoorID() {
        return poorID;
    }

    public void setPoorID(int poorID) {
        this.poorID = poorID;
    }

    public String getPoorCode() {
        return poorCode;
    }

    public void setPoorCode(String poorCode) {
        this.poorCode = poorCode;
    }

    public String getPoorName() {
        return poorName;
    }

    public void setPoorName(String poorName) {
        this.poorName = poorName;
    }

    public int getLv3_PoorID() {
        return lv3_PoorID;
    }

    public void setLv3_PoorID(int lv3_PoorID) {
        this.lv3_PoorID = lv3_PoorID;
    }

    public String getLv3_PoorCode() {
        return lv3_PoorCode;
    }

    public void setLv3_PoorCode(String lv3_PoorCode) {
        this.lv3_PoorCode = lv3_PoorCode;
    }

    public String getLv3PoorName() {
        return lv3PoorName;
    }

    public void setLv3PoorName(String lv3PoorName) {
        this.lv3PoorName = lv3PoorName;
    }

    public int getLv4_PoorID() {
        return lv4_PoorID;
    }

    public void setLv4_PoorID(int lv4_PoorID) {
        this.lv4_PoorID = lv4_PoorID;
    }

    public String getLv4_PoorCode() {
        return lv4_PoorCode;
    }

    public void setLv4_PoorCode(String lv4_PoorCode) {
        this.lv4_PoorCode = lv4_PoorCode;
    }

    public String getLv4PoorName() {
        return lv4PoorName;
    }

    public void setLv4PoorName(String lv4PoorName) {
        this.lv4PoorName = lv4PoorName;
    }

    public int getLv5_PoorID() {
        return lv5_PoorID;
    }

    public void setLv5_PoorID(int lv5_PoorID) {
        this.lv5_PoorID = lv5_PoorID;
    }

    public String getLv5_PoorCode() {
        return lv5_PoorCode;
    }

    public void setLv5_PoorCode(String lv5_PoorCode) {
        this.lv5_PoorCode = lv5_PoorCode;
    }

    public String getLv5PoorName() {
        return lv5PoorName;
    }

    public void setLv5PoorName(String lv5PoorName) {
        this.lv5PoorName = lv5PoorName;
    }

    public String getfType() {
        return fType;
    }

    public void setfType(String fType) {
        this.fType = fType;
    }
}

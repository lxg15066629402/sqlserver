package com.toec.productscreen.business.entity;


/**
 * @Author Jone
 * @Date 2021/1/15 0015 16:59
 */

import javax.xml.crypto.Data;
import java.util.Date;

/**
 * 工单过序表
 */
public class OpPlanExecutDetail {

    // 1 内码 ID (主键)
    private int id;

    // 2 时间戳
    private Date ts;

    // 3 上线ID (外键)
    private int planExecuteMainID;

    // 4 工序ID (外键)
    private int procedureID;

    // 5 工序代码
    private String procedureCode;

    // 6 工序名称
    private String procedureName;

    // 7 顺序号
    private int orderNum;

    // 8 工位ID
    private int workPartId;

    // 9 工位代码
    private String workPartCode;

    // 10 工位名称
    private String  workPartName;

    // 11 最低直通率
    private int lowerFPY;

    // 12
    private Boolean isDataCollect;

    // 13 是否自动读取文件
    private Boolean isAutoReadLocalFile;

    // 14  是否合格
    private Boolean isPass;

    // 15 过序时间
    private  String passTime;

    // 16 检测结果
    private Boolean checkResult;

    // 17 操作员ID
    private int operatorID;

    // 18 操作时间
    private  String peratorDate;

    // 19  是否返修
    private Boolean isRepair;

    // 20
    private String repairMarket;

    // 21  拓展字段1
    private String extendOne;

    // 22  拓展字段2
    private String extendTwo;

    // 23 测试次数
    private String testTimes;

    // 24  软件版本
    private String softVision;

    // 25  软件版本ID
    private int softVisionID;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getPlanExecuteMainID() {
        return planExecuteMainID;
    }

    public void setPlanExecuteMainID(int planExecuteMainID) {
        this.planExecuteMainID = planExecuteMainID;
    }

    public int getProcedureID() {
        return procedureID;
    }

    public void setProcedureID(int procedureID) {
        this.procedureID = procedureID;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public int getWorkPartId() {
        return workPartId;
    }

    public void setWorkPartId(int workPartId) {
        this.workPartId = workPartId;
    }

    public String getWorkPartCode() {
        return workPartCode;
    }

    public void setWorkPartCode(String workPartCode) {
        this.workPartCode = workPartCode;
    }

    public String getWorkPartName() {
        return workPartName;
    }

    public void setWorkPartName(String workPartName) {
        this.workPartName = workPartName;
    }

    public int getLowerFPY() {
        return lowerFPY;
    }

    public void setLowerFPY(int lowerFPY) {
        this.lowerFPY = lowerFPY;
    }

    public Boolean getDataCollect() {
        return isDataCollect;
    }

    public void setDataCollect(Boolean dataCollect) {
        isDataCollect = dataCollect;
    }

    public Boolean getAutoReadLocalFile() {
        return isAutoReadLocalFile;
    }

    public void setAutoReadLocalFile(Boolean autoReadLocalFile) {
        isAutoReadLocalFile = autoReadLocalFile;
    }

    public Boolean getPass() {
        return isPass;
    }

    public void setPass(Boolean pass) {
        isPass = pass;
    }

    public String getPassTime() {
        return passTime;
    }

    public void setPassTime(String passTime) {
        this.passTime = passTime;
    }

    public Boolean getCheckResult() {
        return checkResult;
    }

    public void setCheckResult(Boolean checkResult) {
        this.checkResult = checkResult;
    }

    public int getOperatorID() {
        return operatorID;
    }

    public void setOperatorID(int operatorID) {
        this.operatorID = operatorID;
    }

    public String getPeratorDate() {
        return peratorDate;
    }

    public void setPeratorDate(String peratorDate) {
        this.peratorDate = peratorDate;
    }

    public Boolean getRepair() {
        return isRepair;
    }

    public void setRepair(Boolean repair) {
        isRepair = repair;
    }

    public String getRepairMarket() {
        return repairMarket;
    }

    public void setRepairMarket(String repairMarket) {
        this.repairMarket = repairMarket;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public String getTestTimes() {
        return testTimes;
    }

    public void setTestTimes(String testTimes) {
        this.testTimes = testTimes;
    }

    public String getSoftVision() {
        return softVision;
    }

    public void setSoftVision(String softVision) {
        this.softVision = softVision;
    }

    public int getSoftVisionID() {
        return softVisionID;
    }

    public void setSoftVisionID(int softVisionID) {
        this.softVisionID = softVisionID;
    }
}

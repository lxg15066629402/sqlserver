package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2020/8/12 0012 15:49
 */

import java.util.Date;

/**
 * 生产订单表
 */
public class BaMO2 {

    // 1 内码ID
    private int id;

    // 2 时间戳
    private Date ts;

    // 3 APS排成状态
    private String apsStatus;

    // 4 MES状态
    private String  mesStatus;

    // 5 生产任务单状态
    private String moStatus;

    // 6 单据类型
    private String  moType;

    // 7 单据日期
    private String  fDate;

    // 8 生产任务单号
    private String moNo;

    // 9 生产订单分录ID
    private int entryID;

    // 10 分录序号
    private String entrySeq;

    // 11 产品类型
    private String productType;

    // 12 物料ID
    private int materialID;

    // 13 物料编码
    private String materialCode;

    // 14 物料名称
    private String materialName;

    // 15 物料规格
    private String materialSpc;

    // 16 单位
    private String unit;

    // 17 生产数量
    private String moQty;

    // 18 业务状态
    private String businessStatus;

    // 19  领料状态
    private String pickMtrlStatus;

    // 20  作废状态
    private String cancelStatus;

    // 21  客户ID
    private int customID;

    // 22  客户编码
    private String customCode;

    // 23   客户名称
    private String customName;

    // 24   客户PO
    private String  customPO;

    // 25   销售订单号
    private String sOrder;

    // 26   生产期望开始时间
    private Date moHoperStartDate;

    // 27   生产期望结束时间
    private Date moHoperEndDate;

    // 28  车间ID
    private int workShopID;

    // 29  车间编码
    private String workShopCode;

    // 30  车间名称
    private String workShopName;

    // 31 生产订单状态说明
    private String moStatusName;

    // 32
    private String projectNo;

    // 33  工作令
    private String workOrderNo;

    // 34  备注
    private String remark;

    // 35  工艺版本号
    private String rountingVersion;

    // 36 订单排程优先级
    private int moPriority;

    // 37 父行号
    private String fParentRowId;

    // 38 分录行ID
    private String fRowId;

    // get set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String getApsStatus() {
        return apsStatus;
    }

    public void setApsStatus(String apsStatus) {
        this.apsStatus = apsStatus;
    }

    public String getMesStatus() {
        return mesStatus;
    }

    public void setMesStatus(String mesStatus) {
        this.mesStatus = mesStatus;
    }

    public String getMoStatus() {
        return moStatus;
    }

    public void setMoStatus(String moStatus) {
        this.moStatus = moStatus;
    }

    public String getMoType() {
        return moType;
    }

    public void setMoType(String moType) {
        this.moType = moType;
    }

    public String getfDate() {
        return fDate;
    }

    public void setfDate(String fDate) {
        this.fDate = fDate;
    }

    public String getMoNo() {
        return moNo;
    }

    public void setMoNo(String moNo) {
        this.moNo = moNo;
    }

    public int getEntryID() {
        return entryID;
    }

    public void setEntryID(int entryID) {
        this.entryID = entryID;
    }

    public String getEntrySeq() {
        return entrySeq;
    }

    public void setEntrySeq(String entrySeq) {
        this.entrySeq = entrySeq;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public int getMaterialID() {
        return materialID;
    }

    public void setMaterialID(int materialID) {
        this.materialID = materialID;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getMaterialSpc() {
        return materialSpc;
    }

    public void setMaterialSpc(String materialSpc) {
        this.materialSpc = materialSpc;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getMoQty() {
        return moQty;
    }

    public void setMoQty(String moQty) {
        this.moQty = moQty;
    }

    public String getBusinessStatus() {
        return businessStatus;
    }

    public void setBusinessStatus(String businessStatus) {
        this.businessStatus = businessStatus;
    }

    public String getPickMtrlStatus() {
        return pickMtrlStatus;
    }

    public void setPickMtrlStatus(String pickMtrlStatus) {
        this.pickMtrlStatus = pickMtrlStatus;
    }

    public String getCancelStatus() {
        return cancelStatus;
    }

    public void setCancelStatus(String cancelStatus) {
        this.cancelStatus = cancelStatus;
    }

    public int getCustomID() {
        return customID;
    }

    public void setCustomID(int customID) {
        this.customID = customID;
    }

    public String getCustomCode() {
        return customCode;
    }

    public void setCustomCode(String customCode) {
        this.customCode = customCode;
    }

    public String getCustomName() {
        return customName;
    }

    public void setCustomName(String customName) {
        this.customName = customName;
    }

    public String getCustomPO() {
        return customPO;
    }

    public void setCustomPO(String customPO) {
        this.customPO = customPO;
    }

    public String getsOrder() {
        return sOrder;
    }

    public void setsOrder(String sOrder) {
        this.sOrder = sOrder;
    }

    public Date getMoHoperStartDate() {
        return moHoperStartDate;
    }

    public void setMoHoperStartDate(Date moHoperStartDate) {
        this.moHoperStartDate = moHoperStartDate;
    }

    public Date getMoHoperEndDate() {
        return moHoperEndDate;
    }

    public void setMoHoperEndDate(Date moHoperEndDate) {
        this.moHoperEndDate = moHoperEndDate;
    }

    public int getWorkShopID() {
        return workShopID;
    }

    public void setWorkShopID(int workShopID) {
        this.workShopID = workShopID;
    }

    public String getWorkShopCode() {
        return workShopCode;
    }

    public void setWorkShopCode(String workShopCode) {
        this.workShopCode = workShopCode;
    }

    public String getWorkShopName() {
        return workShopName;
    }

    public void setWorkShopName(String workShopName) {
        this.workShopName = workShopName;
    }

    public String getMoStatusName() {
        return moStatusName;
    }

    public void setMoStatusName(String moStatusName) {
        this.moStatusName = moStatusName;
    }

    public String getProjectNo() {
        return projectNo;
    }

    public void setProjectNo(String projectNo) {
        this.projectNo = projectNo;
    }

    public String getWorkOrderNo() {
        return workOrderNo;
    }

    public void setWorkOrderNo(String workOrderNo) {
        this.workOrderNo = workOrderNo;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getRountingVersion() {
        return rountingVersion;
    }

    public void setRountingVersion(String rountingVersion) {
        this.rountingVersion = rountingVersion;
    }

    public int getMoPriority() {
        return moPriority;
    }

    public void setMoPriority(int moPriority) {
        this.moPriority = moPriority;
    }

    public String getfParentRowId() {
        return fParentRowId;
    }

    public void setfParentRowId(String fParentRowId) {
        this.fParentRowId = fParentRowId;
    }

    public String getfRowId() {
        return fRowId;
    }

    public void setfRowId(String fRowId) {
        this.fRowId = fRowId;
    }
}

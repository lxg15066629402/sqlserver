package com.toec.productscreen.business.utils.test;

/**
 * @author : Jone
 * @date : 22:39 2021/3/11 0011
 * @function :
 */

public class ScreenContext {


    /**
     * 持有策略抽象类
     */
    private AbstractTest abstractTest;

    // 通过构造方法注入，也可以通过其他方式注入
    public ScreenContext(AbstractTest abstractTest) {
        this.abstractTest = abstractTest;
    }

    public String screenID(String id) {
        return abstractTest.screenID(id);
    }
}

// 最后实现方法的调用
// Check
// ScreenContext screenContext = new ScreenContext(new CheckStrategy());
// String id = screenContext.screenID("1");

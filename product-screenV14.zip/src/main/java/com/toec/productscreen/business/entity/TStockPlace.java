package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/2/8 0008 22:34
 */

import java.util.Date;

/**
 * 货位表
 */
public class TStockPlace {

    // 1
    private int id;

    // 2
    private Date ts;

    // 3
    private int  fSPGroupID;

    // 4
    private String fNumber;

    // 5
    private String fName;

    // 6
    private int fLevel;

    // 7
    private boolean fDetail;

    // 8
    private int fParentID;

    // 9
    private String fFullNumber;

    // 10
    private String fShortNumber;

    // 11
    private String fDescription;

    // 12
    private int fDeleted;

    // 13
    private int fSystemType;

    // 14
    private String uUID;

    // 15
    private String fFullName;

    // 16
    private int fClassTypeID;

    // get set 方法

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getfSPGroupID() {
        return fSPGroupID;
    }

    public void setfSPGroupID(int fSPGroupID) {
        this.fSPGroupID = fSPGroupID;
    }

    public String getfNumber() {
        return fNumber;
    }

    public void setfNumber(String fNumber) {
        this.fNumber = fNumber;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public int getfLevel() {
        return fLevel;
    }

    public void setfLevel(int fLevel) {
        this.fLevel = fLevel;
    }

    public boolean isfDetail() {
        return fDetail;
    }

    public void setfDetail(boolean fDetail) {
        this.fDetail = fDetail;
    }

    public int getfParentID() {
        return fParentID;
    }

    public void setfParentID(int fParentID) {
        this.fParentID = fParentID;
    }

    public String getfFullNumber() {
        return fFullNumber;
    }

    public void setfFullNumber(String fFullNumber) {
        this.fFullNumber = fFullNumber;
    }

    public String getfShortNumber() {
        return fShortNumber;
    }

    public void setfShortNumber(String fShortNumber) {
        this.fShortNumber = fShortNumber;
    }

    public String getfDescription() {
        return fDescription;
    }

    public void setfDescription(String fDescription) {
        this.fDescription = fDescription;
    }

    public int getfDeleted() {
        return fDeleted;
    }

    public void setfDeleted(int fDeleted) {
        this.fDeleted = fDeleted;
    }

    public int getfSystemType() {
        return fSystemType;
    }

    public void setfSystemType(int fSystemType) {
        this.fSystemType = fSystemType;
    }

    public String getuUID() {
        return uUID;
    }

    public void setuUID(String uUID) {
        this.uUID = uUID;
    }

    public String getfFullName() {
        return fFullName;
    }

    public void setfFullName(String fFullName) {
        this.fFullName = fFullName;
    }

    public int getfClassTypeID() {
        return fClassTypeID;
    }

    public void setfClassTypeID(int fClassTypeID) {
        this.fClassTypeID = fClassTypeID;
    }
}

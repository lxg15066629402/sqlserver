package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/12 0012 10:32
 */

import java.util.Date;

/**
 * 工单计划编制表表头
 */
public class PlAssemblyPlan {

    // 1 工单计划编制表表头 ID
    private int  id;

    // 2 时间戳
    private Date ts;

    // 3 计划日期
    private String assemblyDate;

    // 4 生产线内码ID
    private  int  asssemblyLineID;

    // 5 生产线编码
    private String  assemblyLineCode;

    // 6 生产线名称
    private  String assemblyLineName;

    // 7 建立人 ID
    private int createUserID;

    // 8 建立日期
    private String createDate;

    // 9 修改人ID
    private int editUserID;

    // 10 修改日期
    private String editDate;

    // 11 版本号
    private String  versionNo;

    // 12 生产订单号
    private String  MONo;

    // 13 生产订单内码ID
    private int MoID;

    // 14 产线产能
    private int LineNum;

    // get set 方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String getAssemblyDate() {
        return assemblyDate;
    }

    public void setAssemblyDate(String assemblyDate) {
        this.assemblyDate = assemblyDate;
    }

    public int getAsssemblyLineID() {
        return asssemblyLineID;
    }

    public void setAsssemblyLineID(int asssemblyLineID) {
        this.asssemblyLineID = asssemblyLineID;
    }

    public String getAssemblyLineCode() {
        return assemblyLineCode;
    }

    public void setAssemblyLineCode(String assemblyLineCode) {
        this.assemblyLineCode = assemblyLineCode;
    }

    public String getAssemblyLineName() {
        return assemblyLineName;
    }

    public void setAssemblyLineName(String assemblyLineName) {
        this.assemblyLineName = assemblyLineName;
    }

    public int getCreateUserID() {
        return createUserID;
    }

    public void setCreateUserID(int createUserID) {
        this.createUserID = createUserID;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public int getEditUserID() {
        return editUserID;
    }

    public void setEditUserID(int editUserID) {
        this.editUserID = editUserID;
    }

    public String getEditDate() {
        return editDate;
    }

    public void setEditDate(String editDate) {
        this.editDate = editDate;
    }

    public String getVersionNo() {
        return versionNo;
    }

    public void setVersionNo(String versionNo) {
        this.versionNo = versionNo;
    }

    public String getMONo() {
        return MONo;
    }

    public void setMONo(String MONo) {
        this.MONo = MONo;
    }

    public int getMoID() {
        return MoID;
    }

    public void setMoID(int moID) {
        MoID = moID;
    }

    public String toString(){
        return "{" +
                "assemblyLineName=" + assemblyLineName +
                "}";


    }
}

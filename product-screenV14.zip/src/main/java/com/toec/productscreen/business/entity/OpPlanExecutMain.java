package com.toec.productscreen.business.entity;

/**
 * @Author Jone
 * @Date 2021/1/12 0012 10:11
 */

import java.util.Date;

/**
 * SMT 上线、生产上线、DC 备料表
 */
public class OpPlanExecutMain {

    // 1  上线表 ID  //  内码ID
    private int id;

    // 2 时间戳
    private Date ts;

    // 3 工单计划编制表表体ID
    private int assemblyPlanDetailID;

    // 4 SN 码、内控码
    private String internalCode;

    // 5 产品工艺ID
    private int routingID;

    // 6 创建人ID
    private int createUserID;

    // 7 创建日期
    private String createDate;

    // 8 是否经过维修
    private boolean isCrossRepair;

    // 9 维修次数
    private int repairTimes;

    // 10 扩展字段1
    private String extendOne;

    // 11 扩展字段2
    private String extendTwo;

    // 12 是否完工
    private int isCompleted;

    // 13 状态
    private int status;

    // 14 入库单号
    private  String icStockBillNo;

    // 15  出库单号
    private String icStockOutBillNo;

    // 16  库位ID
    private int  stockID;

    // 17   货位ID
    private int stockDetailID;

    // 18  批号
    private String  fBatchNo;

    // 19  是否被移除
    private boolean isRemove;

    // 20 维修投入(无用)
    private boolean isRepairCheckIn;

    // 21 最终完工时间
    private String CompletedTime;

    // 22 是否首次条码
    private boolean isFAI;

    // 23 无用字段
    private boolean isActivit;

    // 24 无用字段
    private boolean isNeedOBA;

    // 25 是否生产完工
    private boolean isCompleted2;

    // 26 生产完工时间
    private String CompleteTime2;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getAssemblyPlanDetailID() {
        return assemblyPlanDetailID;
    }

    public void setAssemblyPlanDetailID(int assemblyPlanDetailID) {
        this.assemblyPlanDetailID = assemblyPlanDetailID;
    }

    public String getInternalCode() {
        return internalCode;
    }

    public void setInternalCode(String internalCode) {
        this.internalCode = internalCode;
    }

    public int getRoutingID() {
        return routingID;
    }

    public void setRoutingID(int routingID) {
        this.routingID = routingID;
    }

    public int getCreateUserID() {
        return createUserID;
    }

    public void setCreateUserID(int createUserID) {
        this.createUserID = createUserID;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public boolean isCrossRepair() {
        return isCrossRepair;
    }

    public void setCrossRepair(boolean crossRepair) {
        isCrossRepair = crossRepair;
    }

    public int getRepairTimes() {
        return repairTimes;
    }

    public void setRepairTimes(int repairTimes) {
        this.repairTimes = repairTimes;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public int getIsCompleted() {
        return isCompleted;
    }

    public void setIsCompleted(int isCompleted) {
        this.isCompleted = isCompleted;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getIcStockBillNo() {
        return icStockBillNo;
    }

    public void setIcStockBillNo(String icStockBillNo) {
        this.icStockBillNo = icStockBillNo;
    }

    public String getIcStockOutBillNo() {
        return icStockOutBillNo;
    }

    public void setIcStockOutBillNo(String icStockOutBillNo) {
        this.icStockOutBillNo = icStockOutBillNo;
    }

    public int getStockID() {
        return stockID;
    }

    public void setStockID(int stockID) {
        this.stockID = stockID;
    }

    public int getStockDetailID() {
        return stockDetailID;
    }

    public void setStockDetailID(int stockDetailID) {
        this.stockDetailID = stockDetailID;
    }

    public String getfBatchNo() {
        return fBatchNo;
    }

    public void setfBatchNo(String fBatchNo) {
        this.fBatchNo = fBatchNo;
    }

    public boolean isRemove() {
        return isRemove;
    }

    public void setRemove(boolean remove) {
        isRemove = remove;
    }

    public boolean isRepairCheckIn() {
        return isRepairCheckIn;
    }

    public void setRepairCheckIn(boolean repairCheckIn) {
        isRepairCheckIn = repairCheckIn;
    }

    public String getCompletedTime() {
        return CompletedTime;
    }

    public void setCompletedTime(String completedTime) {
        CompletedTime = completedTime;
    }

    public boolean isIsFAI() {
        return isFAI;
    }

    public void setIsFAI(boolean isFAI) {
        this.isFAI = isFAI;
    }

    public boolean isActivit() {
        return isActivit;
    }

    public void setActivit(boolean activit) {
        isActivit = activit;
    }

    public boolean isNeedOBA() {
        return isNeedOBA;
    }

    public void setNeedOBA(boolean needOBA) {
        isNeedOBA = needOBA;
    }

    public boolean isCompleted2() {
        return isCompleted2;
    }

    public void setCompleted2(boolean completed2) {
        isCompleted2 = completed2;
    }

    public String getCompleteTime2() {
        return CompleteTime2;
    }

    public void setCompleteTime2(String completeTime2) {
        CompleteTime2 = completeTime2;
    }


}

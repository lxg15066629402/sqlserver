//package com.toec.productscreen.business.mapper.first;
//
//import com.toec.productscreen.business.entity.*;
//import org.apache.ibatis.annotations.Mapper;
//
//import java.util.List;
//
//
///**
// * @author Jone
// * @function ProductMapper
// * @date: 2021/1/14
// */
//@Mapper
//public interface ProductMapper1 {
//
//    /**
//     * 查找插装线看板数据 screenId = 1
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingCheckData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekCheckData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeCheckData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableCheckData();
//
//
//    /**
//     * 查找总装线看板数据 screenId = 2
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingAssemblyData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekAssemblyData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeAssemblyData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableAssemblyData();
//
//
//    /**
//     * 查找整装测试线看板数据 screenId = 3
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingWholeData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekWholeData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeWholeData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableWholeData();
//
//
//    /**
//     * 查找部件1线看板数据 screenId = 6
//     */
//    public List<PlAssemblyPlanDetail> findPartsOneData();
//
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingPartsOneData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekPartsOneData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimePartsOneData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTablePartsOneData();
//
//
//    /**
//     * 查找部件2线看板数据 screenId = 7
//     */
//    public List<PlAssemblyPlanDetail> findPartsTwoData();
//
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingPartsTwoData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekPartsTwoData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimePartsTwoData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTablePartsTwoData();
//
//
//    /**
//     * 查看包装线看板数据 screenId = 10
//     */
//    public List<PlAssemblyPlanDetail> findPackingData();
//
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingPackingData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekPackingData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimePackingData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTablePackingData();
//
//
//    /**
//     * 查看电装%线看板数据 screenId = 8
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingFittingData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekFittingData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeFittingData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableFittingData();
//
//
//    /**
//     * 查看自动传动线看板数据 screenId = 9
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingAutoData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekAutoData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeAutoData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableAutoData();
//
//
//    /**
//     * 测试拉看板数据 screenId = 18
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingTestData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekTestData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeTestData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableTestData();
//
//
//    /**
//     * 电装贴片1线看板数据 screenId = 11
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdOneData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdOneData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdOneData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdOneData();
//
//
//    /**
//     * 电装贴片2线看板数据 screenId = 12
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdTwoData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdTwoData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdTwoData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdTwoData();
//
//
//    /**
//     * 电装贴片3线看板数据 screenId = 13
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdThreeData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdThreeData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdThreeData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdThreeData();
//
//
//    /**
//     * 电装贴片4线看板数据 screenId = 14
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdFourData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdFourData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdFourData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdFourData();
//
//
//    /**
//     * 电装贴片5线看板数据 screenId = 15
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdFiveData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdFiveData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdFiveData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdFiveData();
//
//
//    /**
//     * 电装贴片6线看板数据 screenId = 16
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdSixData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdSixData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdSixData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdSixData();
//
//
//    /**
//     * 电装贴片7线看板数据  screenId = 17
//     */
//    // 进行中
//    public List<PlAssemblyPlanDetail> findDoingSmdSevenData();
//
//    // 周数据信息
//    public List<PlAssemblyPlanDetail> findWeekSmdSevenData();
//
//    // 按时完成
//    public List<PlAssemblyPlanDetail> findWeektimeSmdSevenData();
//
//    // 项目生产执行情况
//    public List<PlAssemblyPlanDetail> findTableSmdSevenData();
//
//
//    /**
//     * 维修线看板信息  screenId = 5
//     */
//    // 维修执行情况
//    public List<QlBadAcquistionMain> findRepairTableData();
//
//    // 今日维修完成率
//    public List<QlBadAcquistionMain>  findTodayRepairData();
//
//    // 今日维修不良统计
//    public List<QlBadAcquistionMain> findTodayErroData();
//
//    // 一周维修数量趋势
//    public List<QlBadAcquistionMain> findWeekRepairData();
//
//
//    /**
//     * 查找老化测试看板信息 screenId = 4
//     */
//    public List<OpAgingCar> findOldData();
//
//    /**
//     * 备料线信息 screenId = 19
//     */
//    // 备料执行情况
//    public List<PlMaterialPickMain>  findBillTableData();
//
//    // 今日备料完成率
//    public List<PlMaterialPickMain> findBillTodayData();
//
//    // 一周备料频次趋势
//    public List<PlMaterialPickMain> findWeekBillData();
//
//    // 入库信息
//    public List<PrdMORPT> findInData();
//
//    // 出库信息 plMaterialPickMain
//    public List<PlMaterialPickMain> findOutData();
//
//
//    /**
//     * 测试获取 opAgingCar 表中信息
//     */
//    public List<OpAgingCar> findTets();
//
//}

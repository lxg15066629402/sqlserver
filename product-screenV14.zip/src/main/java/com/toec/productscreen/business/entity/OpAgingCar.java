package com.toec.productscreen.business.entity;

import java.util.Date;
import java.util.List;

/**
 * @Author Jone
 * @Date 2021/1/13 0013 9:23
 */

/**
 * opAgingCar
 */
public class OpAgingCar {

    // 1
    private int id;

    // 2
    private String code;

    // 3
    private String name;

    // 4
    private int capacity;

    // 5
    private String  remark;

    // 6
    private Date ts;

    // 7 关联 OpACWork
    private List<OpACWork> opACWorklist;

    /*OpACWork 属性*/
    private int opACWorkID;

    private int bookDay;

    //
    private int bookHour;

    //
    private int bookMinute;

    //
    private int bookTotal;

    //
    private int currentCount;

    //
    private String currentState;

    //
    private Date  startTime;

    //
    private Date  lastStartTime;

    //
    private String pauseRecord;

    //
    private  Date  endTime;

    //
    private  int takeTime;

    //
    private String  opACWorkremark;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    //
    public List<OpACWork> getOpACWorklist() {
        return opACWorklist;
    }

    public void setOpACWorklist(List<OpACWork> opACWorklist) {
        this.opACWorklist = opACWorklist;
    }

    public int getOpACWorkID() {
        return opACWorkID;
    }

    public void setOpACWorkID(int opACWorkID) {
        this.opACWorkID = opACWorkID;
    }

    public int getBookDay() {
        return bookDay;
    }

    public void setBookDay(int bookDay) {
        this.bookDay = bookDay;
    }

    public int getBookHour() {
        return bookHour;
    }

    public void setBookHour(int bookHour) {
        this.bookHour = bookHour;
    }

    public int getBookMinute() {
        return bookMinute;
    }

    public void setBookMinute(int bookMinute) {
        this.bookMinute = bookMinute;
    }

    public int getBookTotal() {
        return bookTotal;
    }

    public void setBookTotal(int bookTotal) {
        this.bookTotal = bookTotal;
    }

    public int getCurrentCount() {
        return currentCount;
    }

    public void setCurrentCount(int currentCount) {
        this.currentCount = currentCount;
    }

    public String getCurrentState() {
        return currentState;
    }

    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getLastStartTime() {
        return lastStartTime;
    }

    public void setLastStartTime(Date lastStartTime) {
        this.lastStartTime = lastStartTime;
    }

    public String getPauseRecord() {
        return pauseRecord;
    }

    public void setPauseRecord(String pauseRecord) {
        this.pauseRecord = pauseRecord;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public int getTakeTime() {
        return takeTime;
    }

    public void setTakeTime(int takeTime) {
        this.takeTime = takeTime;
    }

    public String getOpACWorkremark() {
        return opACWorkremark;
    }

    public void setOpACWorkremark(String opACWorkremark) {
        this.opACWorkremark = opACWorkremark;
    }
}

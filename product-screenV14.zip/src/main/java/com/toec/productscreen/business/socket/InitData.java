package com.toec.productscreen.business.socket;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.entity.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Jone
 * @Date 2021/3/2 0002 20:11
 */

@Component
public class InitData {

    @Autowired
    private ProdectService prodectService;

    /* 解决*/
    // 当前工具类
    private static InitData sendSmsUtil;
    // 解决静态方法中不能直接用service的问题
    @PostConstruct
    public void init() {
        sendSmsUtil = this;
        sendSmsUtil.prodectService = this.prodectService;
    }


    /**
     * 维修看板
     * item=5
     */
    /**
     * 今日维修完成率
     */
    public String getTodayRepair(String item) {

        try {
            List<QlBadAcquistionMain> todayRepairTest = sendSmsUtil.prodectService.findTodayRepairData();

            // 创建一个map 对象
            Map<String, Object> todayRepairExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayRepairExtTest = new ArrayList<>();
            // 初始化信息
            // todayRepairExtTest.put("code", 0);
            // todayRepairExtTest.put("type", "1");
            for (QlBadAcquistionMain todayRepairTestItem : todayRepairTest) {

                // DecimalFormat df = new DecimalFormat("#.0");
                // 创建一个Map 对象
                Map<String, Object> todayRepair = new LinkedHashMap<String, Object>();

                // 完成数量
                todayRepair.put("completeNumber", todayRepairTestItem.getCompleteNumber());

                // 总维修数量
                todayRepair.put("allNumber", todayRepairTestItem.getAllNumber());

                // 今日维修完成率
                float repairRate = (float) todayRepairTestItem.getCompleteNumber() / (float) todayRepairTestItem.getAllNumber();

                todayRepair.put("repairRate", (int) (repairRate * 100));
                // todayRepair.put("repairRate",df.format(repairRate));

                tempTodayRepairExtTest.add(todayRepair);
            }

            todayRepairExtTest.put("data", tempTodayRepairExtTest);

            // Json 序列化
            String todayRepairData = JSON.toJSONString(todayRepairExtTest); //
            // String todayRepairData = JSON.toJSONString( todayRepairExtTest, SerializerFeature.WriteMapNullValue);

            // System.out.println(todayRepairData);

            return todayRepairData;
        }catch (Exception e){
            e.printStackTrace();
            return "500";
        }

    }

    /**
     * 今日维修不良统计
     * item=5
     */
    private String getRepairError(String item) {

        try {
            List<QlBadAcquistionMain> todayErrorTest = sendSmsUtil.prodectService.findTodayErroData();

            // 创建一个map 对象
            Map<String, Object> todayErrorExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayErrorExtTest = new ArrayList<>();

            // 初始化信息
            // todayErrorExtTest.put("code", 0);
            // todayErrorExtTest.put("type", "2");
            for (QlBadAcquistionMain todayErrorTestItem : todayErrorTest) {
                // 创建一个Map 对象
                Map<String, Object> todayError = new LinkedHashMap<String, Object>();

                // 补焊
                todayError.put("typeOne", todayErrorTestItem.getTypeOne());

                // 创建一个Map 对象
                Map<String, Object> todayErrorOne = new LinkedHashMap<String, Object>();
                todayErrorOne.put("name", "补焊");
                todayErrorOne.put("value", todayErrorTestItem.getTypeOne());

                // 虚焊
                Map<String, Object> todayErrorTwo = new LinkedHashMap<String, Object>();
                todayErrorTwo.put("name", "虚焊");
                todayErrorTwo.put("value", todayErrorTestItem.getTypeTwo());

                // 调整物料
                Map<String, Object> todayErrorThree = new LinkedHashMap<String, Object>();
                todayErrorThree.put("name", "调整物料");
                todayErrorThree.put("value", todayErrorTestItem.getTypeThree());

                // 更换补料
                Map<String, Object> todayErrorFour = new LinkedHashMap<String, Object>();
                todayErrorFour.put("name", "更换补料");
                todayErrorFour.put("value", todayErrorTestItem.getTypeFour());

                // 无法维修
                Map<String, Object> todayErrorFive = new LinkedHashMap<String, Object>();
                todayErrorFive.put("name", "无法维修");
                todayErrorFive.put("value", todayErrorTestItem.getTypeFive());

                tempTodayErrorExtTest.add(todayErrorOne);
                tempTodayErrorExtTest.add(todayErrorTwo);
                tempTodayErrorExtTest.add(todayErrorThree);
                tempTodayErrorExtTest.add(todayErrorFour);
                tempTodayErrorExtTest.add(todayErrorFive);
            }

            todayErrorExtTest.put("data", tempTodayErrorExtTest);
            // Json 序列化
            String todayErrorData = JSON.toJSONString(todayErrorExtTest); //

            // System.out.println(todayErrorData);

            return todayErrorData;
        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 一周维修数量趋势
     * item=5
     */
    private String getWeekRepair(String item) {

        try {
            List<QlBadAcquistionMain> weekRepairTest = sendSmsUtil.prodectService.findWeekRepairData();

            // 创建一个map 对象
            Map<String, Object> weekRepairExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempweekRepairExtTest = new ArrayList<>();

            // 初始化信息
            // weekRepairExtTest.put("code", 0);
            // weekRepairExtTest.put("type", "3");

            Map<String, Object> weekRepair = new LinkedHashMap<String, Object>();
            JSONArray jsonWeekNumber = new JSONArray();

            // 获取当日数据
            Date date = new Date();

            int completeSum = 0;

            int completeSum1 = 0;

            int completeSum2 = 0;

            int completeSum3 = 0;

            int completeSum4 = 0;

            int completeSum5 = 0;

            int completeSum6 = 0;

            int completeSum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeRepairTest = new LinkedHashMap<String, Object>();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for (QlBadAcquistionMain weekRepairTestItem : weekRepairTest) {

                // 获取一周的数据
                Calendar cSql = Calendar.getInstance();

                // String 转化为 Date 类型
                Date dateSql = ft.parse(weekRepairTestItem.getRepairTime());
                cSql.setTime(dateSql);

                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if (weekdaysql == weekday) {
                    completeSum = completeSum + weekRepairTestItem.getCompleteNumber();

                }
                // 周一
                if (weekdaysql == 2) {
                    completeSum1 = completeSum1 + weekRepairTestItem.getCompleteNumber();

                } else if (weekdaysql == 3) {
                    completeSum2 = completeSum2 + weekRepairTestItem.getCompleteNumber();

                } else if (weekdaysql == 4) {
                    completeSum3 = completeSum3 + weekRepairTestItem.getCompleteNumber();

                } else if (weekdaysql == 5) {
                    completeSum4 = completeSum4 + weekRepairTestItem.getCompleteNumber();

                } else if (weekdaysql == 6) {
                    completeSum5 = completeSum5 + weekRepairTestItem.getCompleteNumber();

                } else if (weekdaysql == 7) {
                    completeSum6 = completeSum6 + weekRepairTestItem.getCompleteNumber();

                } else if (weekdaysql == 0) {
                    completeSum7 = completeSum7 + weekRepairTestItem.getCompleteNumber();

                }

            }

            jsonWeekNumber.add(completeSum1);
            jsonWeekNumber.add(completeSum2);
            jsonWeekNumber.add(completeSum3);
            jsonWeekNumber.add(completeSum4);
            jsonWeekNumber.add(completeSum5);
            jsonWeekNumber.add(completeSum6);
            jsonWeekNumber.add(completeSum7);

            // 计划完成一周趋势
            weekRepair.put("weekRepairNumber", jsonWeekNumber);
            tempweekRepairExtTest.add(weekRepair);

            weekRepairExtTest.put("data", tempweekRepairExtTest);
            // Json 序列化
            String weekData = JSON.toJSONString(weekRepairExtTest); //

            // System.out.println(weekData);

            return weekData;
        }catch (Exception e){
            e.printStackTrace();
            return "500";
        }

    }

    /**
     * 维修执行情况
     */
    private String getRepairTable(String item) {

        try {
            List<QlBadAcquistionMain> repairTableTest = sendSmsUtil.prodectService.findRepairTableData();

            // 创建一个map 对象
            Map<String, Object> repairTableExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempRepairTableExtTest = new ArrayList<>();
            // 初始化信息
            // repairTableExtTest.put("code", 0);
            // repairTableExtTest.put("type", "4");

            for (QlBadAcquistionMain repairTableTestItem : repairTableTest) {
                // 创建一个Map 对象
                Map<String, Object> repairtableTest = new LinkedHashMap<String, Object>();

                // 生产线
                repairtableTest.put("assemblyLineName", repairTableTestItem.getAssemblyLineName());

                // 任务单号
                repairtableTest.put("moNO", repairTableTestItem.getMoNo());

                // 不良工序编码
                repairtableTest.put("procedureCode", repairTableTestItem.getProcedureCode());

                // 物料条码
                repairtableTest.put("barCode", repairTableTestItem.getBarCode());

                // 维修类别
                repairtableTest.put("lineRemark", repairTableTestItem.getLineRemark());

                // 维修信息
                repairtableTest.put("lv1_PoorName", repairTableTestItem.getLv1_PoorName());
                // 创建人
                repairtableTest.put("createUser", repairTableTestItem.getCreateUser());
                // 问题原因
                repairtableTest.put("poorReason", repairTableTestItem.getPoorReason());
                // 维修人
                repairtableTest.put("repairUser", repairTableTestItem.getRepairUser());
                // 维修状态
                if (repairTableTestItem.isRepair() == true) {
                    repairtableTest.put("isRepair", "维修完成");
                } else {
                    repairtableTest.put("isRepair", "待维修");
                }


                tempRepairTableExtTest.add(repairtableTest);

            }

            repairTableExtTest.put("data", tempRepairTableExtTest);
            // Json 序列化
            String repairTableData = JSON.toJSONString(repairTableExtTest); //

            // System.out.println(repairTableData);

            return repairTableData;
        }catch (Exception e){
            e.printStackTrace();
            return "500";
        }

    }

    /**
     *
     * @param item 看板类型
     * @return  看板获取数据
     */
    public Map<String, Object> FirstItemMessage(String item) {

        // 插装线
        if (item.equals("1")) {

            Map<String, Object> buffer1 = new HashMap<String, Object>();
            // 把字符串转为JSONObject对象并返回
            buffer1.put("initOne", JSON.parseObject(this.getDoingCheck(item)));
            buffer1.put("initTwo", JSON.parseObject(this.getProductCheck(item)));
            buffer1.put("initThree", JSON.parseObject(this.getTimeCheck(item)));
            buffer1.put("initFour", JSON.parseObject(this.getTableCheck(item)));

            return buffer1;

        }

        // 总装线
        else if(item.equals("2")){//

            Map<String, Object> buffer2 = new HashMap<String, Object>();

            buffer2.put("initOne", JSON.parseObject(this.getDoingAssembly(item)));
            buffer2.put("initTwo", JSON.parseObject(this.getProductAssembly(item)));
            buffer2.put("initThree", JSON.parseObject(this.getTimeAssembly(item)));
            buffer2.put("initFour", JSON.parseObject(this.getTableAssembly(item)));

            return buffer2;

        }
        // 整机测试线
        else if(item.equals("3")){

            Map<String, Object> buffer3 = new HashMap<String, Object>();

            buffer3.put("initOne", JSON.parseObject(this.getDoingWhole(item)));
            buffer3.put("initTwo", JSON.parseObject(this.getProductWhole(item)));
            buffer3.put("initThree", JSON.parseObject(this.getTimeWhole(item)));
            buffer3.put("initFour", JSON.parseObject(this.getTableWhole(item)));

            return buffer3;

        }
        // 老化区测试
        else if(item.equals("4")) {
            // 老化测试看板数据

            Map<String, Object> buffer4 = new HashMap<String, Object>();
            buffer4.put("initOne", JSON.parseObject(this.getOldData(item)));

            return buffer4;
        }
        // 测试、维修线
        else if(item.equals("5")) {

            Map<String, Object> buffer5 = new HashMap<String, Object>();

            /**
             java转两次json出现后json值中出现转义字符,
             只用fastjson转一次。转两次就会出现这个情况，你可以把之前转的json转成map
             */

            // String a = this.getTodayRepair("5");  // 空指针异常
            buffer5.put("initOne", JSON.parseObject(this.getTodayRepair(item)));
            buffer5.put("initTwo", JSON.parseObject(this.getRepairError(item)));
            buffer5.put("initThree", JSON.parseObject(this.getWeekRepair(item)));
            buffer5.put("initFour", JSON.parseObject(this.getRepairTable(item)));

            return buffer5;
        }
        // 部件1线看板
        else if(item.equals("6")) {

            Map<String, Object> buffer6 = new HashMap<String, Object>();

            buffer6.put("initOne", JSON.parseObject(this.getDoingPartsOne(item)));
            buffer6.put("initTwo", JSON.parseObject(this.getProductPartsOne(item)));
            buffer6.put("initThree", JSON.parseObject(this.getTimePartsOne(item)));
            buffer6.put("initFour", JSON.parseObject(this.getTablePartsOne(item)));

            return buffer6;

        }
        // 部件2线看板
        else if(item.equals("7")){


            Map<String, Object> buffer7 = new HashMap<String, Object>();

            buffer7.put("initOne", JSON.parseObject(this.getDoingPartsTwo(item)));
            buffer7.put("initTwo", JSON.parseObject(this.getProductPartsTwo(item)));
            buffer7.put("initThree", JSON.parseObject(this.getTimePartsTwo(item)));
            buffer7.put("initFour", JSON.parseObject(this.getTablePartsTwo(item)));

            return buffer7;
        }

        // 电装%线看板
        else if(item.equals("8")){

            Map<String, Object> buffer8 = new HashMap<String, Object>();


            buffer8.put("initOne", JSON.parseObject(this.getDoingFitting(item)));
            buffer8.put("initTwo", JSON.parseObject(this.getProductFitting(item)));
            buffer8.put("initThree", JSON.parseObject(this.getTimeFitting(item)));
            buffer8.put("initFour", JSON.parseObject(this.getTableFitting(item)));

            return buffer8;
        }
        // 自动传动线
        else if(item.equals("9")){

            Map<String, Object> buffer9 = new HashMap<String, Object>();

            buffer9.put("initOne", JSON.parseObject(this.getDoingAuto(item)));
            buffer9.put("initTwo", JSON.parseObject(this.getProductAuto(item)));
            buffer9.put("initThree", JSON.parseObject(this.getTimeAuto(item)));
            buffer9.put("initFour", JSON.parseObject(this.getTableAuto(item)));

            return buffer9;
        }
        // 包装线看板
        else if(item.equals("10")){

            Map<String, Object> buffer10 = new HashMap<String, Object>();

            buffer10.put("initOne", JSON.parseObject(this.getDoingPacking(item)));
            buffer10.put("initTwo", JSON.parseObject(this.getProductPacking(item)));
            buffer10.put("initThree", JSON.parseObject(this.getTimePacking(item)));
            buffer10.put("initFour", JSON.parseObject(this.getTablePacking(item)));

            return buffer10;
        }

        // 1 电装贴片1线
        else if(item.equals("11")){

            Map<String, Object> buffer11 = new HashMap<String, Object>();

            buffer11.put("initOne", JSON.parseObject(this.getDoingSmdOne(item)));
            buffer11.put("initTwo", JSON.parseObject(this.getProductSmdOne(item)));
            buffer11.put("initThree", JSON.parseObject(this.getTimeSmdOne(item)));
            buffer11.put("initFour", JSON.parseObject(this.getTableSmdOne(item)));

            return buffer11;
        }
        // 2 电装贴片2线
        else if(item.equals("12")){

            Map<String, Object> buffer12 = new HashMap<String, Object>();

            buffer12.put("initOne", JSON.parseObject(this.getDoingSmdTwo(item)));
            buffer12.put("initTwo", JSON.parseObject(this.getProductSmdTwo(item)));
            buffer12.put("initThree", JSON.parseObject(this.getTimeSmdTwo(item)));
            buffer12.put("initFour", JSON.parseObject(this.getTableSmdTwo(item)));

            return buffer12;
        }
        // 3 电装贴片3线
        else if(item.equals("13")){

            Map<String, Object> buffer13 = new HashMap<String, Object>();

            buffer13.put("initOne", JSON.parseObject(this.getDoingSmdThree(item)));
            buffer13.put("initTwo", JSON.parseObject(this.getProductSmdThree(item)));
            buffer13.put("initThree", JSON.parseObject(this.getTimeSmdThree(item)));
            buffer13.put("initFour", JSON.parseObject(this.getTableSmdThree(item)));

            return buffer13;

        }
        // 4 电装贴片4线
        else if(item.equals("14")){

            Map<String, Object> buffer14 = new HashMap<String, Object>();

            buffer14.put("initOne", JSON.parseObject(this.getDoingSmdFour(item)));
            buffer14.put("initTwo", JSON.parseObject(this.getProductSmdFour(item)));
            buffer14.put("initThree", JSON.parseObject(this.getTimeSmdFour(item)));
            buffer14.put("initFour", JSON.parseObject(this.getTableSmdFour(item)));

            return buffer14;
        }
        // 5 电装贴片5线
        else if(item.equals("15")){

            Map<String, Object> buffer15 = new HashMap<String, Object>();

            buffer15.put("initOne", JSON.parseObject(this.getDoingSmdFive(item)));
            buffer15.put("initTwo", JSON.parseObject(this.getProductSmdFive(item)));
            buffer15.put("initThree", JSON.parseObject(this.getTimeSmdFive(item)));
            buffer15.put("initFour", JSON.parseObject(this.getTableSmdFive(item)));

            return buffer15;
        }
        // 6 电装贴片6线
        else if(item.equals("16")){

            Map<String, Object> buffer16 = new HashMap<String, Object>();

            buffer16.put("initOne", JSON.parseObject(this.getDoingSmdSix(item)));
            buffer16.put("initTwo", JSON.parseObject(this.getProductSmdSix(item)));
            buffer16.put("initThree", JSON.parseObject(this.getTimeSmdSix(item)));
            buffer16.put("initFour", JSON.parseObject(this.getTableSmdSix(item)));

            return buffer16;
        }
        // 电装贴片7线
        else if(item.equals("17")){

            Map<String, Object> buffer17 = new HashMap<String, Object>();

            buffer17.put("initOne", JSON.parseObject(this.getDoingSmdSeven(item)));
            buffer17.put("initTwo", JSON.parseObject(this.getProductSmdSeven(item)));
            buffer17.put("initThree", JSON.parseObject(this.getTimeSmdSeven(item)));
            buffer17.put("initFour", JSON.parseObject(this.getTableSmdSeven(item)));

            return buffer17;

        }
        // 测试拉看板
        else if(item.equals("18")){

            Map<String, Object> buffer18 = new HashMap<String, Object>();

            buffer18.put("initOne", JSON.parseObject(this.getDoingTest(item)));
            buffer18.put("initTwo", JSON.parseObject(this.getProductTest(item)));
            buffer18.put("initThree", JSON.parseObject(this.getTimeTest(item)));
            buffer18.put("initFour", JSON.parseObject(this.getTableTest(item)));

            return buffer18;
        }
        // 备料看板
        else if(item.equals("19")) {

            Map<String, Object> buffer19 = new HashMap<String, Object>();

            buffer19.put("initOne", JSON.parseObject(this.getTodayBill(item)));
            buffer19.put("initTwo", JSON.parseObject(this.getBillWeek(item)));
            buffer19.put("initThree", JSON.parseObject(this.getBillTable(item)));

            return buffer19;

        }

        // 仓库看板
        else if(item.equals("20")){

            // 入库
            Map<String, Object> buffer20 = new HashMap<String, Object>();

            buffer20.put("initOne", JSON.parseObject(this.getIn(item)));
            buffer20.put("initTwo", JSON.parseObject(this.getOut(item)));
            //buffer20.put("initThree", JSON.parseObject(this.getTenDayIn(item)));
            //buffer20.put("initFour", JSON.parseObject(this. getTenDayOut(item)));

            return buffer20;


        }
        /*
        else if (item.equals("5")) {

            Map<String, Object> buffer5 = new HashMap<String, Object>();

            // String a = this.getTodayRepair("5");  // 空指针异常
            buffer5.put("initOne", this.getTodayRepair(item));
            buffer5.put("initTwo", this.getRepairError(item));
            buffer5.put("initThree", this.getWeekRepair(item));
            buffer5.put("initFour", this.getRepairTable(item));

            return buffer5;

        }
         */
        // 返回值类型
        Map<String, Object> buffer = new HashMap<String, Object>();
        return buffer;
    }



    /**
     * 插装线看板
     * item = 1
     */
    /**
     * 进行中项目
     * @param item = 1
     */
    private String getDoingCheck(String item){

        try{

            // 加载数据
            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingCheckData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();

            // 初始化信息
            // doingPartsOneExtTest.put("code", 0);
            // doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);

                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }

            doingPartsOneExtTest.put("data", tempPartsOneExtTest);

            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            return doingOneData;


        }catch(Exception e){
            e.printStackTrace();

            // 获取不到服务器数据
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=1
     */
    private String getProductCheck(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekCheckTest = sendSmsUtil.prodectService.findWeekCheckData();

            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            // weekTodayPartsOneExtTest.put("code", 0);
            // weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();

            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekCheckTest){

                Calendar cSql = Calendar.getInstance();
                
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }

                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                }

                // 周二
                else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                }

                // 周三
                else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                }

                // 周四
                else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                }

                // 周五
                else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                }

                // 周六
                else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                }

                // 周日
                else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            // DecimalFormat df = new DecimalFormat("#.00");
            // DecimalFormat df = new DecimalFormat("#");
            float rate =  (float)completesum / (float)productsum;

            // 今日计划完成率
            // weekOneTest.put("completeRate", df.format(rate*100));
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(df.format(rate1*100));
                jsonproduct.add((int)(rate1*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(df.format(rate2*100));
                jsonproduct.add((int)(rate2*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(df.format(rate3*100));
                jsonproduct.add((int)(rate3*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(df.format(rate4*100));
                jsonproduct.add((int)(rate4*100));
            }else{
                jsonproduct.add(0.0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(df.format(rate5*100));
                jsonproduct.add((int)(rate5*100));
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                //jsonproduct.add(df.format(rate6*100));
                jsonproduct.add((int)(rate6*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(df.format(rate7*100));
                jsonproduct.add((int)(rate7*100));
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);

            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest);

            // System.out.println(oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=1
     */
    private String getTimeCheck(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeCheckData();
    
            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
    
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();
    
            // weekTimePartsOneExtTest.put("code", 0);
            // weekTimePartsOneExtTest.put("type", "3");
    
            // 获取当日数据
            Date date = new Date();
    
            int productsum = 0;
            int timeCompletesum = 0;
    
            int productsum1 = 0;
            int timeCompletesum1 = 0;
    
            int productsum2 = 0;
            int timeCompletesum2 = 0;
    
            int productsum3 = 0;
            int timeCompletesum3 = 0;
    
            int productsum4 = 0;
            int timeCompletesum4 = 0;
    
            int productsum5 = 0;
            int timeCompletesum5 = 0;
    
            int productsum6 = 0;
            int timeCompletesum6 = 0;
    
            int productsum7 = 0;
            int timeCompletesum7 = 0;
    
            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
    
            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();
    
            JSONArray jsontime = new JSONArray();
    
            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);
    
            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){
    
                Calendar cSql = Calendar.getInstance();

                Date datecSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
    
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);
    
                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周二
                else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周三
                else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周四
                else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周五
                else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周六
                else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();
    
                }
                // 周日
                else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();
    
                }
    
            }
    
            // 保留两位小数，供前端显示
            DecimalFormat df = new DecimalFormat("#.00");
            float rate =  (float)timeCompletesum  /   (float)productsum;
    
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
    
    
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
    
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);
    
            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  / (float)productsum1;
                // jsontime.add(df.format(rate1*100));
                jsontime.add((int)(rate1*100));
            }else{
                jsontime.add(0);
            }
    
            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(df.format(rate2*100));
                jsontime.add((int)(rate2*100));
            }else{
                jsontime.add(0);
            }
    
            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(df.format(rate3*100));
                jsontime.add((int)(rate3*100));
            }else{
                jsontime.add(0);
            }
    
            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(df.format(rate4*100));
                jsontime.add((int)(rate4*100));
            }else{
                jsontime.add(0);
            }
    
            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(df.format(rate5*100));
                jsontime.add((int)(rate5*100));
            }else{
                jsontime.add(0);
            }
    
            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(df.format(rate6*100));
                jsontime.add((int)(rate6*100));
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(df.format(rate7*100));
                jsontime.add((int)(rate7*100));
            }else{
                jsontime.add(0);
            }
    
            weekTimeOneTest.put("weekTimeRate", jsontime);
    
            tempTimePartsOneExtTest.add(weekTimeOneTest);
    
            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
    
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //
    
            // System.out.println(oneData);
    
            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=1
     */
    private String getTableCheck(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableCheckData();

            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            tableOneExtTest.put("code", 0);
            tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());

                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());

                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }

                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }


                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());

                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());

                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());

                // 完成数量
                // tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                tableOneTest.put("completeNumber", partsOneTestItem.getComputerNumber());

                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());

                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);

            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 总装线看板
     * item = 2
     */
    /**
     * 进行中项目
     * @param item=2
     */
    private String getDoingAssembly(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingAssemblyData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);

                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=2
     */
    private String getProductAssembly(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekCheckTest = sendSmsUtil.prodectService.findWeekAssemblyData();

            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            // weekTodayPartsOneExtTest.put("code", 0);
            // weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekCheckTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            // DecimalFormat df = new DecimalFormat("#.00");
            DecimalFormat df = new DecimalFormat("#");
            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            // weekOneTest.put("completeRate", df.format(rate*100));
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(df.format(rate1*100));
                jsonproduct.add((int)(rate1*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(df.format(rate2*100));
                jsonproduct.add((int)(rate2*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(df.format(rate3*100));
                jsonproduct.add((int)(rate3*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(df.format(rate4*100));
                jsonproduct.add((int)(rate4*100));
            }else{
                jsonproduct.add(0.0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(df.format(rate5*100));
                jsonproduct.add((int)(rate5*100));
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                //jsonproduct.add(df.format(rate6*100));
                jsonproduct.add((int)(rate6*100));
            }else{
                jsonproduct.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(df.format(rate7*100));
                jsonproduct.add((int)(rate7*100));
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=2
     */
    private String getTimeAssembly(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeAssemblyData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            DecimalFormat df = new DecimalFormat("#.00");
            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            //　weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(df.format(rate1*100));
                jsontime.add((int)(rate1*100));
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(df.format(rate2*100));
                jsontime.add((int)(rate2*100));
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(df.format(rate3*100));
                jsontime.add((int)(rate3*100));
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(df.format(rate4*100));
                jsontime.add((int)(rate4*100));
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(df.format(rate5*100));
                jsontime.add((int)(rate5*100));
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(df.format(rate6*100));
                jsontime.add((int)(rate6*100));
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(df.format(rate7*100));
                jsontime.add((int)(rate7*100));
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=2
     */
    private String getTableAssembly(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableAssemblyData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }

                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }



                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                // tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                tableOneTest.put("completeNumber", partsOneTestItem.getComputerNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "";
        }

    }


    /**
     * 整机测试线看板
     * item = 3
     */
    /**
     * 进行中项目
     * @param item=3
     */
    private String getDoingWhole(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingWholeData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);
                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;


        }catch(Exception e){
            e.printStackTrace();
            return "";
        }
    }


    /**
     * 今日计划数据
     * @param item=3
     */
    private String getProductWhole(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekCheckTest = sendSmsUtil.prodectService.findWeekWholeData();

            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekCheckTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            // DecimalFormat df = new DecimalFormat("#.00");
            DecimalFormat df = new DecimalFormat("#");
            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            // weekOneTest.put("completeRate", df.format(rate*100));
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(df.format(rate1*100));
                jsonproduct.add((int)(rate1*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(df.format(rate2*100));
                jsonproduct.add((int)(rate2*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(df.format(rate3*100));
                jsonproduct.add((int)(rate3*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(df.format(rate4*100));
                jsonproduct.add((int)(rate4*100));
            }else{
                jsonproduct.add(0.0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(df.format(rate5*100));
                jsonproduct.add((int)(rate5*100));
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                //jsonproduct.add(df.format(rate6*100));
                jsonproduct.add((int)(rate6*100));
            }else{
                jsonproduct.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(df.format(rate7*100));
                jsonproduct.add((int)(rate7*100));
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=3
     */
    private String getTimeWhole(String item){

         try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeWholeData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            DecimalFormat df = new DecimalFormat("#.00");
            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            //　weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(df.format(rate1*100));
                jsontime.add((int)(rate1*100));
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(df.format(rate2*100));
                jsontime.add((int)(rate2*100));
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(df.format(rate3*100));
                jsontime.add((int)(rate3*100));
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(df.format(rate4*100));
                jsontime.add((int)(rate4*100));
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(df.format(rate5*100));
                jsontime.add((int)(rate5*100));
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(df.format(rate6*100));
                jsontime.add((int)(rate6*100));
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(df.format(rate7*100));
                jsontime.add((int)(rate7*100));
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=3
     */
    private String getTableWhole(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableWholeData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }

                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }



                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                // tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                tableOneTest.put("completeNumber", partsOneTestItem.getComputerNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 老化测试看板数据  item=4
     */
    private String getOldData(String item){

        try{
            /**
             * 查找老化看板
             */
            List<OpAgingCar> oldDataTest =  sendSmsUtil.prodectService.findOldData();
            // 创建一个map 对象
            Map<String, Object> oldExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempoldTest=new ArrayList<>();

            //oldExtTest.put("code", 0);
            //oldExtTest.put("type", "4");
            for(OpAgingCar oldDataTestItem:oldDataTest){

                Map<String, Object> oldTest = new LinkedHashMap<String, Object>();
                // 时间格式
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                // 老化台车
                oldTest.put("aCode", oldDataTestItem.getCode());
                // 老化状态
                if(oldDataTestItem.getCurrentState() != null){
                    oldTest.put("currentState", oldDataTestItem.getCurrentState());
                }else{
                    oldTest.put("currentState", "空置中");
                }
                // 产品数量
                oldTest.put("currentCount", oldDataTestItem.getCurrentCount());
                // 开始时间
                if(oldDataTestItem.getStartTime() != null){
                    oldTest.put("startTime", sdf.format(oldDataTestItem.getStartTime()));
                }else{
                    oldTest.put("startTime", "");
                }
                // 获取当前时间
                Date date = new Date();
                /**
                 *  进行时长
                 */
                if(oldDataTestItem.getCurrentState().equals("已完成")){
                    if(oldDataTestItem.getEndTime() != null){
                        // 任务完成情况下，实现结束时间-开始时间
                        long Taketime = oldDataTestItem.getEndTime().getTime() - oldDataTestItem.getStartTime().getTime();
                        long minutes = Taketime / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("takeTime",  hour+":"+min);
                    }else{
                        long Taketime = oldDataTestItem.getTakeTime();
                        long minutes = Taketime / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("takeTime",  hour+":"+min);
                    }
                    //  未完成情况
                }else{
                    if(oldDataTestItem.getStartTime()!= null){
                        long Taketime =  Math.abs(date.getTime() - oldDataTestItem.getStartTime().getTime());
                        long minutes = Taketime / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("takeTime",  hour+":"+min);
                    }else{
                        oldTest.put("takeTime",  "");
                    }
                }
                /**
                 * 计划完成时间
                 */
                if(oldDataTestItem.getEndTime() != null){
                    // 计划完成时间 大于 当前时间
                    if (oldDataTestItem.getEndTime().getTime() >= date.getTime()){
                        oldTest.put("endTime", sdf.format(oldDataTestItem.getEndTime()));
                        // 结束倒计时
                        long Countdown =oldDataTestItem.getEndTime().getTime() - date.getTime();

                        long minutes = Countdown / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("countDown",  hour+":"+min+":");

                        // 计划完成时间 小于 当前时间
                    }else{
                        oldTest.put("endTime", sdf.format(oldDataTestItem.getEndTime()));
                        oldTest.put("countDown", "00:00");
                    }
                }else{
                    oldTest.put("endTime", oldDataTestItem.getEndTime() + "");
                    // 结束倒计时
                    long minutes = oldDataTestItem.getBookTotal() / (60*1000);
                    long min = minutes % 60;
                    long hour = minutes / 60;
                    oldTest.put("countDown", hour+":"+min);
                }
                tempoldTest.add(oldTest);
            }
            oldExtTest.put("data", tempoldTest);
            // Json 序列化
            String oldData = JSON.toJSONString(oldExtTest); //

            // System.out.println(oldData);

            // webSocketServer.sendOneMessage(item, oldData);
            return oldData;
        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }



    /**
     * 部件看板1
     */
    /**
     * 进行中项目
     * @param item
     */
    private String getDoingPartsOne(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingPartsOneData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);

                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);

            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }
            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "";
        }
    }


    /**
     * 今日计划数据
     * @param item=6
     */
    private String getProductPartsOne(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekPartsOneData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            // DecimalFormat df = new DecimalFormat("#.00");
            DecimalFormat df = new DecimalFormat("#");
            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            // weekOneTest.put("completeRate", df.format(rate*100));
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(df.format(rate1*100));
                jsonproduct.add((int)(rate1*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(df.format(rate2*100));
                jsonproduct.add((int)(rate2*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(df.format(rate3*100));
                jsonproduct.add((int)(rate3*100));
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(df.format(rate4*100));
                jsonproduct.add((int)(rate4*100));
            }else{
                jsonproduct.add(0.0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(df.format(rate5*100));
                jsonproduct.add((int)(rate5*100));
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                //jsonproduct.add(df.format(rate6*100));
                jsonproduct.add((int)(rate6*100));
            }else{
                jsonproduct.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(df.format(rate7*100));
                jsonproduct.add((int)(rate7*100));
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=6
     */
    private String getTimePartsOne(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimePartsOneData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            // 保留两位小数，供前端显示
            DecimalFormat df = new DecimalFormat("#.00");
            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            //　weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(df.format(rate1*100));
                jsontime.add((int)(rate1*100));
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(df.format(rate2*100));
                jsontime.add((int)(rate2*100));
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(df.format(rate3*100));
                jsontime.add((int)(rate3*100));
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(df.format(rate4*100));
                jsontime.add((int)(rate4*100));
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(df.format(rate5*100));
                jsontime.add((int)(rate5*100));
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(df.format(rate6*100));
                jsontime.add((int)(rate6*100));
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(df.format(rate7*100));
                jsontime.add((int)(rate7*100));
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

        // webSocketServer.sendOneMessage(item, oneData);


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item
     */
    private String getTablePartsOne(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTablePartsOneData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }

                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }


                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                // tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                tableOneTest.put("completeNumber", partsOneTestItem.getComputerNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 部件看板2
     */
    /**
     * 进行中项目
     * @param item = 7
     */
    private String getDoingPartsTwo(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingPartsTwoData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);
                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=7
     */
    private String getProductPartsTwo(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekPartsTwoData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

            // webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();

            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=7
     */
    private String getTimePartsTwo(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimePartsTwoData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=7
     */
    private String getTablePartsTwo(String item){

        try {

            List<PlAssemblyPlanDetail> tablePartsOneTest = sendSmsUtil.prodectService.findTablePartsTwoData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest = new ArrayList<>();
            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for (PlAssemblyPlanDetail partsOneTestItem : tablePartsOneTest) {

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if (partsOneTestItem.isUsing() == true) {
                    tableOneTest.put("open", "开工");
                } else {
                    tableOneTest.put("open", " ");
                }


                if (partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()) {
                    tableOneTest.put("doing", "进行中");
                } else {
                    tableOneTest.put("doing", "");
                }

                if (partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()) {
                    tableOneTest.put("complete", "完成");
                } else {
                    tableOneTest.put("complete", "");
                }


                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() - partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if (((ArrayList) to).size() != 0) {
                // webSocketServer.sendOneMessage(item, oneData);
            }
            return oneData;

    }catch(Exception e){
        e.printStackTrace();
        return "500";
    }

    }


    /**
     * 包装看板
     */
    /**
     * 进行中项目
     * @param item = 10
     */
    private String getDoingPacking(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingPackingData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);
                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }
            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=10
     */
    private String getProductPacking(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekPackingData();

            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

            // webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=10
     */
    private String getTimePacking(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimePackingData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

            // webSocketServer.sendOneMessage(item, oneData);


        }catch(Exception e){
            e.printStackTrace();
            return "500";

        }
    }

    /**
     * 项目生产执行情况
     * @param item=10
     */
    private String getTablePacking(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTablePackingData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }


                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 电装%线
     * item=8
     */
    /**
     * 进行中项目
     * @param item = 8
     */
    private String getDoingFitting(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  prodectService.findDoingFittingData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);
                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=8
     */
    private String getProductFitting(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekFittingData();

            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", rate*100);
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

                // webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=8
     */
    private String getTimeFitting(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeFittingData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
    //            Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
    //            cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=8
     */
    private String getTableFitting(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableFittingData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 自动传动线
     * item=9
     */
    /**
     * 进行中项目
     * @param item = 9
     */
    private String getDoingAuto(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingAutoData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);
                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=9
     */
    private String getProductAuto(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekAutoData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

            // webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=9
     */
    private String getTimeAuto(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeAutoData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";

        }
    }

    /**
     * 项目生产执行情况
     * @param item=9
     */
    private String getTableAuto(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableAutoData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            // System.out.println(oneData);

            return oneData;

        // webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 电装贴片1线
     * item=11
     */
    /**
     * 进行中项目
     * @param item = 11
     */
    private String getDoingSmdOne(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdOneData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }
            return doingOneData;

    }catch(Exception e){
        e.printStackTrace();
        return "500";
    }
    }


    /**
     * 今日计划数据
     * @param item=11
     */
    private String getProductSmdOne(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdOneData();

            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;

        }catch(Exception e){
            e.printStackTrace();

            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=11
     */
    private String getTimeSmdOne(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdOneData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;


    }catch(Exception e){
        e.printStackTrace();
        return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=11
     */
    private String getTableSmdOne(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdOneData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();

            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量 （累计完成量）                           partsOneTestItem.getComputerNumber()
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }

    /**
     * 电装贴片2线
     * item=12
     */
    /**
     * 进行中项目
     * @param item = 12
     */
    private String getDoingSmdTwo(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdTwoData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=12
     */
    private String getProductSmdTwo(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdTwoData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

            // webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();
            return "500";

        }
    }


    /**
     * 按时完成情况
     * @param item=12
     */
    private String getTimeSmdTwo(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdTwoData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
    //            Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
    //            cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

            return oneData;
        }catch(Exception e){
            e.printStackTrace();

            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=12
     */
    private String getTableSmdTwo(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdTwoData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }

    /**
     * 电装贴片3线
     * item=13
     */
    /**
     * 进行中项目
     * @param item = 13
     */
    private String getDoingSmdThree(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdThreeData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }
            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=13
     */
    private String getProductSmdThree(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdThreeData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";

        }
    }


    /**
     * 按时完成情况
     * @param item=13
     */
    private String getTimeSmdThree(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdThreeData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=13
     */
    private String getTableSmdThree(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdThreeData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 电装贴片4线
     * item=14
     */
    /**
     * 进行中项目
     * @param item = 14
     */
    private String getDoingSmdFour(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdFourData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=14
     */
    private String getProductSmdFour(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdFourData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);

        return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500" ;

        }
    }


    /**
     * 按时完成情况
     * @param item=14
     */
    private String getTimeSmdFour(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdFourData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

            // webSocketServer.sendOneMessage(item, oneData);


        }catch(Exception e){
            e.printStackTrace();
            return "500" ;
        }
    }

    /**
     * 项目生产执行情况
     * @param item=14
     */
    private String getTableSmdFour(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdFourData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                // webSocketServer.sendOneMessage(item, oneData);
            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 电动贴片15线
     * item=15
     */
    /**
     * 进行中项目
     * @param item = 15
     */
    private String getDoingSmdFive(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdFiveData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                // webSocketServer.sendOneMessage(item, doingOneData);
            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=15
     */
    private String getProductSmdFive(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdFiveData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            // webSocketServer.sendOneMessage(item, oneData);
            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=15
     */
    private String getTimeSmdFive(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdFiveData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=15
     */
    private String getTableSmdFive(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdFiveData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            // tableOneExtTest.put("code", 0);
            // tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }


                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){

            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 电装贴片6线
     * item=16
     */
    /**
     * 进行中项目
     * @param item = 16
     */
    private String getDoingSmdSix(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdSixData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){

            }
            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=16
     */
    private String getProductSmdSix(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdSixData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=16
     */
    private String getTimeSmdSix(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdSixData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;



        }catch(Exception e){
            e.printStackTrace();

            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=16
     */
    private String getTableSmdSix(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdSixData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            //tableOneExtTest.put("code", 0);
            //tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }


                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){

            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 电装贴片7线
     * item=17
     */
    /**
     * 进行中项目
     * @param item = 17
     */
    private String getDoingSmdSeven(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingSmdSevenData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){

            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=17
     */
    private String getProductSmdSeven(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekSmdSevenData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=17
     */
    private String getTimeSmdSeven(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeSmdSevenData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=17
     */
    private String getTableSmdSeven(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  sendSmsUtil.prodectService.findTableSmdSevenData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            tableOneExtTest.put("code", 0);
            tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){

            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }


    /**
     * 测试拉线
     * item=18
     */
    /**
     * 进行中项目
     * @param item = 18
     */
    private String getDoingTest(String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  sendSmsUtil.prodectService.findDoingTestData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            //doingPartsOneExtTest.put("code", 0);
            //doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 工单号   --  任务单号
                doingoneTest.put("worOrder", doingPartsOneTestItem.getMoNo());

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料名称  -- 完成品号  -- 项目名称
                doingoneTest.put("materialName", doingPartsOneTestItem.getMaterialName());

                // 物料编码  -- 产品编码
                doingoneTest.put("materialCode", doingPartsOneTestItem.getMaterialCode());

                // 直通率
                float rolledRate = (doingPartsOneTestItem.getQuantity() -  doingPartsOneTestItem.getOfflineNumber()) / doingPartsOneTestItem.getQuantity();
                doingoneTest.put("rolledRate", rolledRate);
                // 物料型号  -- 产品型号  -- 生产类型
                // doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());
                doingoneTest.put("materialID", doingPartsOneTestItem.getMoType());
                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o  = doingPartsOneExtTest.get("data");

            // System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){

            }

            return doingOneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 今日计划数据
     * @param item=18
     */
    private String getProductTest(String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = sendSmsUtil.prodectService.findWeekTestData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();

            //weekTodayPartsOneExtTest.put("code", 0);
            //weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     * 按时完成情况
     * @param item=18
     */
    private String getTimeTest(String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = sendSmsUtil.prodectService.findWeektimeTestData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            //weekTimePartsOneExtTest.put("code", 0);
            //weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
    //            Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
    //            cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            // System.out.println(oneData);

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 项目生产执行情况
     * @param item=18
     */
    private String getTableTest(String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest = sendSmsUtil.prodectService.findTableTestData();

            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            tableOneExtTest.put("code", 0);
            tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }

                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            // System.out.println(oneData);

            if(((ArrayList) to).size() != 0){

            }

            return oneData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }




    /**
     * 备料线信息
     * item=19
     */
    /**
     * 今日备料完成率
     * item= 19
     */
    private String getTodayBill(String item){

        try{
            List<PlMaterialPickMain> billTodayTest = sendSmsUtil.prodectService.findBillTodayData();

            // 创建一个map 对象
            Map<String, Object> todayBillExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayBillExtTest=new ArrayList<>();
            // 初始化信息
            //todayBillExtTest.put("code", 0);
            //todayBillExtTest.put("type", "1");

            for(PlMaterialPickMain billTodayTestItem: billTodayTest) {

                DecimalFormat df = new DecimalFormat("#");
                // 创建一个Map 对象
                Map<String, Object> todayBill = new LinkedHashMap<String, Object>();

                // 完成数量
                todayBill.put("completeNumber", billTodayTestItem.getCompleteBill());
                // 总维修数量
                todayBill.put("allNumber", billTodayTestItem.getAllBill());

                // 今日维修完成率
                float billRate = (float) billTodayTestItem.getCompleteBill() / (float) billTodayTestItem.getAllBill();

                todayBill.put("billRate", (int)(billRate*100));
                // todayBill.put("billRate", df.format(billRate));

                tempTodayBillExtTest.add(todayBill);
            }

            todayBillExtTest.put("data", tempTodayBillExtTest);
            // Json 序列化
            String todayBillData = JSON.toJSONString(todayBillExtTest); //

            Object to  = todayBillExtTest.get("data");

            // System.out.println(todayBillData);

            if(((ArrayList) to).size() != 0){

            }

            return todayBillData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }

    /**
     * 一周备料频次趋势
     * item=19
     */
    private String getBillWeek(String item){

        try{
            List<PlMaterialPickMain> billWeekTest =  sendSmsUtil.prodectService.findWeekBillData();

            // 创建一个map 对象
            Map<String, Object> billWeekExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempBillWeekTest=new ArrayList<>();

            //billWeekExtTest.put("code", 0);
            //billWeekExtTest.put("type", "2");


            // 创建一个Map 对象
            Map<String, Object> weekBill = new LinkedHashMap<String, Object>();

            JSONArray jsonWeekNumber = new JSONArray();

            for(PlMaterialPickMain billWeekTestItem: billWeekTest){

                jsonWeekNumber.add(billWeekTestItem.getCompleteBill());

            }

            // 判断jsonWeekNumber
            if(jsonWeekNumber.size() !=7){
                jsonWeekNumber.add(0);
            }

            weekBill.put("weekBillNumber",  jsonWeekNumber);

            tempBillWeekTest.add(weekBill);

            billWeekExtTest.put("data", tempBillWeekTest);

            // Json 序列化
            String weekBillData = JSON.toJSONString(billWeekExtTest); //

            // System.out.println(weekBillData);

            return weekBillData;


        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    /**
     *
     * @param item
     */
    // 备料执行情况
    private String getBillTable(String item){

        try{
            List<PlMaterialPickMain> billTableTest = sendSmsUtil.prodectService.findBillTableData();

            // 创建一个map 对象
            Map<String, Object> billTableExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempBillTableTest=new ArrayList<>();
            billTableExtTest.put("code", 0);
            billTableExtTest.put("type", "3");

            for(PlMaterialPickMain billTableTestItem: billTableTest) {

                // 创建一个Map 对象
                Map<String, Object> billTable = new LinkedHashMap<String, Object>();

                // 备料单号
                billTable.put("billNo", billTableTestItem.getBillNo());

                //生产订单号
                billTable.put("moNo", billTableTestItem.getMoNo());

                //备料类型
                billTable.put("billType", billTableTestItem.getBillType());

                //备料状态
                billTable.put("completeStatus", billTableTestItem.getCompleteStatus());

                //备料人
                billTable.put("userName", billTableTestItem.getUserName());

                tempBillTableTest.add(billTable);


            }

            billTableExtTest.put("data", tempBillTableTest);

            String billTableData =  JSON.toJSONString(billTableExtTest);

            Object  bill = billTableExtTest.get("data");

            // System.out.println(billTableData);

            if(((ArrayList) bill).size() != 0){

            }

            return billTableData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }
    }


    // 入库信息
    private String getIn(String item){

        try{

            List<PrdMORPT> inData = sendSmsUtil.prodectService.findInData();

            // 创建一个map 对象
            Map<String, Object> inDataExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempInDataTest=new ArrayList<>();
            // inDataExtTest.put("code", 0);
            // inDataExtTest.put("type", "1");

            for(PrdMORPT inDataItem: inData){

                // 创建一个Map 对象
                Map<String, Object> inDataTest = new LinkedHashMap<String, Object>();

                SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");

                // 日期
                inDataTest.put("date", sdf.format(inDataItem.getfDate()));

                // 入库名称
                inDataTest.put("materialName", inDataItem.getfMaterialName());

                // 批次
                inDataTest.put("lot", inDataItem.getfLot());

                // 数量
                inDataTest.put("fQty", inDataItem.getfQty());

                // 仓位
                inDataTest.put("fName", inDataItem.getfName());

                // 保管人
                inDataTest.put("custos", inDataItem.getCustos());


                tempInDataTest.add(inDataTest);

            }
            inDataExtTest.put("data", tempInDataTest);

            String billTableData =  JSON.toJSONString(inDataExtTest);

            Object  bin = inDataExtTest.get("data");

            // System.out.println(billTableData);

            if(((ArrayList) bin).size() != 0){

            }

            return billTableData;

        }catch(Exception e){
            e.printStackTrace();
            return "500";
        }

    }



    // 出库信息
    private String getOut(String item){

        try {

            List<PlMaterialPickMain> outData = sendSmsUtil.prodectService.findOutData();

            // 创建一个map 对象
            Map<String, Object> outDataExtTest = new LinkedHashMap<String, Object>();

            // 创建一个List 对象
            List<Map> tempOutDataTest = new ArrayList<>();

            //outDataExtTest.put("code", 0);
            //outDataExtTest.put("type", "2");

            for (PlMaterialPickMain outDataItem : outData) {

                // 创建一个Map 对象
                Map<String, Object> outDataTest = new LinkedHashMap<String, Object>();

                SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");

                // 日期
                outDataTest.put("date", sdf.format(outDataItem.getfDate()));

                // 入库名称
                outDataTest.put("materialName", outDataItem.getMaterialName());

                // 批次
                outDataTest.put("batchNo", outDataItem.getBatchNo());

                // 数量
                outDataTest.put("planPickedQty", outDataItem.getPlanPickedQty());

                // 仓位
                outDataTest.put("fName", outDataItem.getfName());

                // 保管人
                outDataTest.put("custos", outDataItem.getCustos());

                tempOutDataTest.add(outDataTest);

            }

            outDataExtTest.put("data", tempOutDataTest);

            String billTableData = JSON.toJSONString(outDataExtTest);

            Object bin = outDataExtTest.get("data");

            // System.out.println(billTableData);

            return billTableData;
        }catch (Exception e){
            e.printStackTrace();
            return "500";
        }


    }


    private String getTenDayIn(String item){

        try {
            // 初始一个数组变量
            int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

            return Arrays.toString(a);
        }catch (Exception e){
            e.printStackTrace();
            return "500";
        }
    }



    private String getTenDayOut(String item){


        try{
            // 初始一个数组变量
            int[] a = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

            return Arrays.toString(a);
        }
        catch (Exception e){
            e.printStackTrace();
            return "500";
        }



    }





}

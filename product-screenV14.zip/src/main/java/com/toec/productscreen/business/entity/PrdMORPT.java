package com.toec.productscreen.business.entity;

import java.util.Date;
import java.util.List;

/**
 * @Author Jone
 * @Date 2021/2/8 0008 22:23
 */


public class PrdMORPT {

    // 1 内码ID
    private int id;

    // 2 时间戳
    private Date ts;

    // 3
    private int fID;

    // 4
    private Date fDate;

    // 5
    private String fBillNo;

    // 6
    private String fBillType;

    // 7
    private String fDocumentStatus;

    // 8
    private String fDescription;

    // 9
    private String fMateriaNumber;

    // 10
    private String fMaterialName;

    // 11
    private String fSpecification;

    // 12
    private String  fUnit;

    // 13
    private String fFinishQty;

    // 14
    private  int fQuaQty;

    // 15
    private String fFailQty;

    // 16
    private int fScrapQty;

    // 17
    private int fReMadeQty;

    // 18
    private int fReworkQty;

    // 19
    private String fLot;

    // 20
    private String fSrcBillNo;

    // 21
    private int fSrcInterId;

    // 22
    private int fSrcEntryId;

    // 23
    private String fSrcEntrySeq;

    // 24
    private String fMoBillNo;

    // 25
    private int fMoId;

    // 26
    private int fMoEntryId;

    // 27
    private String fMoEntrySeq;

    // 28
    private Date fStartTime;

    // 29
    private Date fEndTime;

    // 30
    private int fStdManHour;

    // 31
    private int fHrPrepareTime;

    // 32
    private int fHrWorkTime;

    // 33
    private int fMacPrepareTime;

    // 34
    private int fMacWorkTime;

    // 35
    private Date crtTime;

    // 36
    private int crtUserID;

    // 37
    private int fStatus;

    // 38
    private int checkedQty;

    // 39
    private String inStockBillNo;

    // 40
    private String inStockDate;

    // 41
    private int productType;

    // 42
    private int stockID;

    // 43
    private  int stockPlaceID;

    // 44
    private String pqcCheckBillNo;

    // 45
    private int printQty;

    // list
    private List<BaMaterial> baMaterialList;

    //
    private List<TStockPlace> tStockPlaceList;

    //
    private int fQty;

    //
    private String fName;

    //
    private String custos;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getfID() {
        return fID;
    }

    public void setfID(int fID) {
        this.fID = fID;
    }

    public Date getfDate() {
        return fDate;
    }

    public void setfDate(Date fDate) {
        this.fDate = fDate;
    }

    public String getfMateriaNumber() {
        return fMateriaNumber;
    }

    public void setfMateriaNumber(String fMateriaNumber) {
        this.fMateriaNumber = fMateriaNumber;
    }

    public String getfMaterialName() {
        return fMaterialName;
    }

    public void setfMaterialName(String fMaterialName) {
        this.fMaterialName = fMaterialName;
    }

    public int getfQuaQty() {
        return fQuaQty;
    }

    public void setfQuaQty(int fQuaQty) {
        this.fQuaQty = fQuaQty;
    }

    public String getfLot() {
        return fLot;
    }

    public void setfLot(String fLot) {
        this.fLot = fLot;
    }

    public int getCheckedQty() {
        return checkedQty;
    }

    public void setCheckedQty(int checkedQty) {
        this.checkedQty = checkedQty;
    }

    public int getStockPlaceID() {
        return stockPlaceID;
    }

    public void setStockPlaceID(int stockPlaceID) {
        this.stockPlaceID = stockPlaceID;
    }

    public List<BaMaterial> getBaMaterialList() {
        return baMaterialList;
    }

    public void setBaMaterialList(List<BaMaterial> baMaterialList) {
        this.baMaterialList = baMaterialList;
    }

    public List<TStockPlace> gettStockPlaceList() {
        return tStockPlaceList;
    }

    public void settStockPlaceList(List<TStockPlace> tStockPlaceList) {
        this.tStockPlaceList = tStockPlaceList;
    }

    public int getfQty() {
        return fQty;
    }

    public void setfQty(int fQty) {
        this.fQty = fQty;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getCustos() {
        return custos;
    }

    public void setCustos(String custos) {
        this.custos = custos;
    }

    public String getfBillType() {
        return fBillType;
    }

    public void setfBillType(String fBillType) {
        this.fBillType = fBillType;
    }

    public String getfBillNo() {
        return fBillNo;
    }

    public void setfBillNo(String fBillNo) {
        this.fBillNo = fBillNo;
    }

    public String getfDocumentStatus() {
        return fDocumentStatus;
    }

    public void setfDocumentStatus(String fDocumentStatus) {
        this.fDocumentStatus = fDocumentStatus;
    }

    public String getfDescription() {
        return fDescription;
    }

    public void setfDescription(String fDescription) {
        this.fDescription = fDescription;
    }

    public String getfSpecification() {
        return fSpecification;
    }

    public void setfSpecification(String fSpecification) {
        this.fSpecification = fSpecification;
    }

    public String getfUnit() {
        return fUnit;
    }

    public void setfUnit(String fUnit) {
        this.fUnit = fUnit;
    }

    public String getfFinishQty() {
        return fFinishQty;
    }

    public void setfFinishQty(String fFinishQty) {
        this.fFinishQty = fFinishQty;
    }

    public String getfFailQty() {
        return fFailQty;
    }

    public void setfFailQty(String fFailQty) {
        this.fFailQty = fFailQty;
    }

    public int getfScrapQty() {
        return fScrapQty;
    }

    public void setfScrapQty(int fScrapQty) {
        this.fScrapQty = fScrapQty;
    }

    public int getfReMadeQty() {
        return fReMadeQty;
    }

    public void setfReMadeQty(int fReMadeQty) {
        this.fReMadeQty = fReMadeQty;
    }

    public int getfReworkQty() {
        return fReworkQty;
    }

    public void setfReworkQty(int fReworkQty) {
        this.fReworkQty = fReworkQty;
    }

    public String getfSrcBillNo() {
        return fSrcBillNo;
    }

    public void setfSrcBillNo(String fSrcBillNo) {
        this.fSrcBillNo = fSrcBillNo;
    }

    public int getfSrcInterId() {
        return fSrcInterId;
    }

    public void setfSrcInterId(int fSrcInterId) {
        this.fSrcInterId = fSrcInterId;
    }

    public int getfSrcEntryId() {
        return fSrcEntryId;
    }

    public void setfSrcEntryId(int fSrcEntryId) {
        this.fSrcEntryId = fSrcEntryId;
    }

    public String getfSrcEntrySeq() {
        return fSrcEntrySeq;
    }

    public void setfSrcEntrySeq(String fSrcEntrySeq) {
        this.fSrcEntrySeq = fSrcEntrySeq;
    }

    public String getfMoBillNo() {
        return fMoBillNo;
    }

    public void setfMoBillNo(String fMoBillNo) {
        this.fMoBillNo = fMoBillNo;
    }

    public int getfMoId() {
        return fMoId;
    }

    public void setfMoId(int fMoId) {
        this.fMoId = fMoId;
    }

    public int getfMoEntryId() {
        return fMoEntryId;
    }

    public void setfMoEntryId(int fMoEntryId) {
        this.fMoEntryId = fMoEntryId;
    }

    public String getfMoEntrySeq() {
        return fMoEntrySeq;
    }

    public void setfMoEntrySeq(String fMoEntrySeq) {
        this.fMoEntrySeq = fMoEntrySeq;
    }

    public Date getfStartTime() {
        return fStartTime;
    }

    public void setfStartTime(Date fStartTime) {
        this.fStartTime = fStartTime;
    }

    public Date getfEndTime() {
        return fEndTime;
    }

    public void setfEndTime(Date fEndTime) {
        this.fEndTime = fEndTime;
    }

    public int getfStdManHour() {
        return fStdManHour;
    }

    public void setfStdManHour(int fStdManHour) {
        this.fStdManHour = fStdManHour;
    }

    public int getfHrPrepareTime() {
        return fHrPrepareTime;
    }

    public void setfHrPrepareTime(int fHrPrepareTime) {
        this.fHrPrepareTime = fHrPrepareTime;
    }

    public int getfHrWorkTime() {
        return fHrWorkTime;
    }

    public void setfHrWorkTime(int fHrWorkTime) {
        this.fHrWorkTime = fHrWorkTime;
    }

    public int getfMacPrepareTime() {
        return fMacPrepareTime;
    }

    public void setfMacPrepareTime(int fMacPrepareTime) {
        this.fMacPrepareTime = fMacPrepareTime;
    }

    public int getfMacWorkTime() {
        return fMacWorkTime;
    }

    public void setfMacWorkTime(int fMacWorkTime) {
        this.fMacWorkTime = fMacWorkTime;
    }

    public Date getCrtTime() {
        return crtTime;
    }

    public void setCrtTime(Date crtTime) {
        this.crtTime = crtTime;
    }

    public int getCrtUserID() {
        return crtUserID;
    }

    public void setCrtUserID(int crtUserID) {
        this.crtUserID = crtUserID;
    }

    public int getfStatus() {
        return fStatus;
    }

    public void setfStatus(int fStatus) {
        this.fStatus = fStatus;
    }

    public String getInStockBillNo() {
        return inStockBillNo;
    }

    public void setInStockBillNo(String inStockBillNo) {
        this.inStockBillNo = inStockBillNo;
    }

    public String getInStockDate() {
        return inStockDate;
    }

    public void setInStockDate(String inStockDate) {
        this.inStockDate = inStockDate;
    }

    public int getProductType() {
        return productType;
    }

    public void setProductType(int productType) {
        this.productType = productType;
    }

    public int getStockID() {
        return stockID;
    }

    public void setStockID(int stockID) {
        this.stockID = stockID;
    }

    public String getPqcCheckBillNo() {
        return pqcCheckBillNo;
    }

    public void setPqcCheckBillNo(String pqcCheckBillNo) {
        this.pqcCheckBillNo = pqcCheckBillNo;
    }

    public int getPrintQty() {
        return printQty;
    }

    public void setPrintQty(int printQty) {
        this.printQty = printQty;
    }
}

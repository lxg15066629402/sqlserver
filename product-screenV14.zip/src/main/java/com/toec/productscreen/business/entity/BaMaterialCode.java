package com.toec.productscreen.business.entity;


/**
 * @Author Jone
 * @Date 2021/2/8 0008 15:58
 */


import java.util.Date;

/**
 *  物料条码信息表
 */

public class BaMaterialCode {

    // 1 内码ID
    private int ID;

    // 2 时间戳
    private Date ts;

    // 3 物料条码
    private String  barCode;

    // 4 物料ID
    private int materialID;

    // 5 供应商ID
    private int providerID;

    // 6 批次
    private String provideBatch;

    // 7 物料数量
    private int amount;

    // 8 备注
    private String remark;

    // 9 采购订单
    private String po;

    // 10 采购日期
    private Date poDate;

    // 11 检验日期
    private String checkDate;

    // 12 检验标志
    private String checkSign;

    // 13 检验人
    private String checkUser;

    // 14 检验结果
    private String checkResult;

    // 15 状态
    private int status;

    // 16 仓库ID
    private int stockID;

    // 17 货位ID
    private int stockDetailID;

    // 18 收获通知单号货完工汇报报单号
    private String poInStock;

    // 19
    private int fInterID;

    // 20 ERP 单据明细内码
    private int fEntryID;

    // 21 打印状态（0 已打印|1未打印）
    private int printStatus;

    // 22 打印人ID
    private int printUserID;

    // 23 入库单号（采购入库或生产入库）
    private String iCStockBillNo;

    // 24 出库单号（备料单或销售出库单）
    private String iCStockOutBillNo;

    // 25 物料编码
    private String  worTeam;

    // 26
    private  int worAmount;

    // 27 工单计划编制表表体ID
    private int AssemblyPlanDetailID;

    // 28 条码类型 0 物料 1 半成品
    private int type;

    // 29 ERP 采购单号 （空值）
    private  String poOrder;

    // 30 ERP 采购单表头ID （空值）
    private  int poOrderID;

    // 31  ERP 采购单分录ID （空值）
    private int poOrderEntryID;

    // 32 备注
    private String extend;

    // 33 备注拓展1
    private String extendOne;

    // 34 备注拓展2
    private String extendTwo;

    // 35 备注拓展3
    private String extendThree;

    // 36
    private  String printBrand;

    // 37
    private Boolean isNeedTrack;

    // 38
    private int fbID;

    // 39
    private int havePackDetail;

    // 40
    private String trackBillNo;

    // 41
    private  String  packBoxCode;

    // 42
    private  String  packPalletCode;


    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public String getBarCode() {
        return barCode;
    }

    public void setBarCode(String barCode) {
        this.barCode = barCode;
    }

    public int getMaterialID() {
        return materialID;
    }

    public void setMaterialID(int materialID) {
        this.materialID = materialID;
    }

    public int getProviderID() {
        return providerID;
    }

    public void setProviderID(int providerID) {
        this.providerID = providerID;
    }

    public String getProvideBatch() {
        return provideBatch;
    }

    public void setProvideBatch(String provideBatch) {
        this.provideBatch = provideBatch;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getPo() {
        return po;
    }

    public void setPo(String po) {
        this.po = po;
    }

    public Date getPoDate() {
        return poDate;
    }

    public void setPoDate(Date poDate) {
        this.poDate = poDate;
    }

    public String getCheckDate() {
        return checkDate;
    }

    public void setCheckDate(String checkDate) {
        this.checkDate = checkDate;
    }

    public String getCheckSign() {
        return checkSign;
    }

    public void setCheckSign(String checkSign) {
        this.checkSign = checkSign;
    }

    public String getCheckUser() {
        return checkUser;
    }

    public void setCheckUser(String checkUser) {
        this.checkUser = checkUser;
    }

    public String getCheckResult() {
        return checkResult;
    }

    public void setCheckResult(String checkResult) {
        this.checkResult = checkResult;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getStockID() {
        return stockID;
    }

    public void setStockID(int stockID) {
        this.stockID = stockID;
    }

    public int getStockDetailID() {
        return stockDetailID;
    }

    public void setStockDetailID(int stockDetailID) {
        this.stockDetailID = stockDetailID;
    }

    public String getPoInStock() {
        return poInStock;
    }

    public void setPoInStock(String poInStock) {
        this.poInStock = poInStock;
    }

    public int getfInterID() {
        return fInterID;
    }

    public void setfInterID(int fInterID) {
        this.fInterID = fInterID;
    }

    public int getfEntryID() {
        return fEntryID;
    }

    public void setfEntryID(int fEntryID) {
        this.fEntryID = fEntryID;
    }

    public int getPrintStatus() {
        return printStatus;
    }

    public void setPrintStatus(int printStatus) {
        this.printStatus = printStatus;
    }

    public int getPrintUserID() {
        return printUserID;
    }

    public void setPrintUserID(int printUserID) {
        this.printUserID = printUserID;
    }

    public String getiCStockBillNo() {
        return iCStockBillNo;
    }

    public void setiCStockBillNo(String iCStockBillNo) {
        this.iCStockBillNo = iCStockBillNo;
    }

    public String getiCStockOutBillNo() {
        return iCStockOutBillNo;
    }

    public void setiCStockOutBillNo(String iCStockOutBillNo) {
        this.iCStockOutBillNo = iCStockOutBillNo;
    }

    public String getWorTeam() {
        return worTeam;
    }

    public void setWorTeam(String worTeam) {
        this.worTeam = worTeam;
    }

    public int getWorAmount() {
        return worAmount;
    }

    public void setWorAmount(int worAmount) {
        this.worAmount = worAmount;
    }

    public int getAssemblyPlanDetailID() {
        return AssemblyPlanDetailID;
    }

    public void setAssemblyPlanDetailID(int assemblyPlanDetailID) {
        AssemblyPlanDetailID = assemblyPlanDetailID;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getPoOrder() {
        return poOrder;
    }

    public void setPoOrder(String poOrder) {
        this.poOrder = poOrder;
    }

    public int getPoOrderID() {
        return poOrderID;
    }

    public void setPoOrderID(int poOrderID) {
        this.poOrderID = poOrderID;
    }

    public int getPoOrderEntryID() {
        return poOrderEntryID;
    }

    public void setPoOrderEntryID(int poOrderEntryID) {
        this.poOrderEntryID = poOrderEntryID;
    }

    public String getExtend() {
        return extend;
    }

    public void setExtend(String extend) {
        this.extend = extend;
    }

    public String getExtendOne() {
        return extendOne;
    }

    public void setExtendOne(String extendOne) {
        this.extendOne = extendOne;
    }

    public String getExtendTwo() {
        return extendTwo;
    }

    public void setExtendTwo(String extendTwo) {
        this.extendTwo = extendTwo;
    }

    public String getExtendThree() {
        return extendThree;
    }

    public void setExtendThree(String extendThree) {
        this.extendThree = extendThree;
    }

    public String getPrintBrand() {
        return printBrand;
    }

    public void setPrintBrand(String printBrand) {
        this.printBrand = printBrand;
    }

    public Boolean getNeedTrack() {
        return isNeedTrack;
    }

    public void setNeedTrack(Boolean needTrack) {
        isNeedTrack = needTrack;
    }

    public int getFbID() {
        return fbID;
    }

    public void setFbID(int fbID) {
        this.fbID = fbID;
    }

    public int getHavePackDetail() {
        return havePackDetail;
    }

    public void setHavePackDetail(int havePackDetail) {
        this.havePackDetail = havePackDetail;
    }

    public String getTrackBillNo() {
        return trackBillNo;
    }

    public void setTrackBillNo(String trackBillNo) {
        this.trackBillNo = trackBillNo;
    }

    public String getPackBoxCode() {
        return packBoxCode;
    }

    public void setPackBoxCode(String packBoxCode) {
        this.packBoxCode = packBoxCode;
    }

    public String getPackPalletCode() {
        return packPalletCode;
    }

    public void setPackPalletCode(String packPalletCode) {
        this.packPalletCode = packPalletCode;
    }
}

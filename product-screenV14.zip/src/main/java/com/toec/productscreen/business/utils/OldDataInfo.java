package com.toec.productscreen.business.utils;

import com.alibaba.fastjson.JSON;
import com.toec.productscreen.business.entity.OpAgingCar;
import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.socket.WebSocketServer;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : Jone
 * @date : 20:54 2021/3/8 0008
 * @function :
 */
public class OldDataInfo {

    /**
     * 老化测试看板数据  item=4
     */
    public void getOldData(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{
            /**
             * 查找老化看板
             */
            List<OpAgingCar> oldDataTest =  prodectService.findOldData();
            // 创建一个map 对象
            Map<String, Object> oldExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempoldTest=new ArrayList<>();
            oldExtTest.put("code", 0);
            oldExtTest.put("type", "4");
            for(OpAgingCar oldDataTestItem:oldDataTest){

                Map<String, Object> oldTest = new LinkedHashMap<String, Object>();
                // 时间格式
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                // 老化台车
                oldTest.put("aCode", oldDataTestItem.getCode());
                // 老化状态
                if(oldDataTestItem.getCurrentState() != null){
                    oldTest.put("currentState", oldDataTestItem.getCurrentState());
                }else{
                    oldTest.put("currentState", "空置中");
                }
                // 产品数量
                oldTest.put("currentCount", oldDataTestItem.getCurrentCount());
                // 开始时间
                if(oldDataTestItem.getStartTime() != null){
                    oldTest.put("startTime", sdf.format(oldDataTestItem.getStartTime()));
                }else{
                    oldTest.put("startTime", "");
                }
                // 获取当前时间
                Date date = new Date();
                /**
                 *  进行时长
                 */
                if(oldDataTestItem.getCurrentState().equals("已完成")){
                    if(oldDataTestItem.getEndTime() != null){
                        // 任务完成情况下，实现结束时间-开始时间
                        long Taketime = oldDataTestItem.getEndTime().getTime() - oldDataTestItem.getStartTime().getTime();
                        long minutes = Taketime / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("takeTime",  hour+":"+min);
                    }else{
                        long Taketime = oldDataTestItem.getTakeTime();
                        long minutes = Taketime / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("takeTime",  hour+":"+min);
                    }
                    //  未完成情况
                }else{
                    if(oldDataTestItem.getStartTime()!= null){
                        long Taketime =  Math.abs(date.getTime() - oldDataTestItem.getStartTime().getTime());
                        long minutes = Taketime / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("takeTime",  hour+":"+min);
                    }else{
                        oldTest.put("takeTime",  "");
                    }
                }
                /**
                 * 计划完成时间
                 */
                if(oldDataTestItem.getEndTime() != null){
                    // 计划完成时间 大于 当前时间
                    if (oldDataTestItem.getEndTime().getTime() >= date.getTime()){
                        oldTest.put("endTime", sdf.format(oldDataTestItem.getEndTime()));
                        // 结束倒计时
                        long Countdown =oldDataTestItem.getEndTime().getTime() - date.getTime();

                        long minutes = Countdown / (60*1000);
                        long min = minutes % 60;
                        long hour = minutes / 60;
                        oldTest.put("countDown",  hour+":"+min+":");

                        // 计划完成时间 小于 当前时间
                    }else{
                        oldTest.put("endTime", sdf.format(oldDataTestItem.getEndTime()));
                        oldTest.put("countDown", "00:00");
                    }
                }else{
                    oldTest.put("endTime", oldDataTestItem.getEndTime() + "");
                    // 结束倒计时
                    long minutes = oldDataTestItem.getBookTotal() / (60*1000);
                    long min = minutes % 60;
                    long hour = minutes / 60;
                    oldTest.put("countDown", hour+":"+min);
                }
                tempoldTest.add(oldTest);
            }
            oldExtTest.put("data", tempoldTest);
            // Json 序列化
            String oldData = JSON.toJSONString(oldExtTest); //
            System.out.println(oldData);
            webSocketServer.sendOneMessage(item, oldData);
        }catch(Exception e){
            e.printStackTrace();
        }

    }
}

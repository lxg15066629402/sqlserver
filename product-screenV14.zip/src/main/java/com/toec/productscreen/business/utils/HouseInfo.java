package com.toec.productscreen.business.utils;

import com.alibaba.fastjson.JSON;
import com.toec.productscreen.business.entity.PlMaterialPickMain;
import com.toec.productscreen.business.entity.PrdMORPT;
import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.socket.WebSocketServer;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : Jone
 * @date : 22:37 2021/3/8 0008
 * @function :
 */
public class HouseInfo {

    // 入库信息
    public void getIn(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{


            List<PrdMORPT> inData = prodectService.findInData();

            // 创建一个map 对象
            Map<String, Object> inDataExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempInDataTest=new ArrayList<>();
            inDataExtTest.put("code", 0);
            inDataExtTest.put("type", "1");

            for(PrdMORPT inDataItem: inData){

                // 创建一个Map 对象
                Map<String, Object> inDataTest = new LinkedHashMap<String, Object>();

                SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");

                // 日期
                inDataTest.put("date", sdf.format(inDataItem.getfDate()));

                // 入库名称
                inDataTest.put("materialName", inDataItem.getfMaterialName());

                // 批次
                inDataTest.put("lot", inDataItem.getfLot());

                // 数量
                inDataTest.put("fQty", inDataItem.getfQty());

                // 仓位
                inDataTest.put("fName", inDataItem.getfName());

                // 保管人
                inDataTest.put("custos", inDataItem.getCustos());


                tempInDataTest.add(inDataTest);

            }
            inDataExtTest.put("data", tempInDataTest);

            String billTableData =  JSON.toJSONString(inDataExtTest);

            Object  bin = inDataExtTest.get("data");

            System.out.println(billTableData);

            if(((ArrayList) bin).size() != 0){
                webSocketServer.sendOneMessage(item, billTableData);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }



    // 出库信息
    public void getOut(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{


            List<PlMaterialPickMain> outData = prodectService.findOutData();

            // 创建一个map 对象
            Map<String, Object> outDataExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempOutDataTest=new ArrayList<>();
            outDataExtTest.put("code", 0);
            outDataExtTest.put("type", "2");

            for(PlMaterialPickMain outDataItem: outData){

                // 创建一个Map 对象
                Map<String, Object> outDataTest = new LinkedHashMap<String, Object>();

                SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");

                // 日期
                outDataTest.put("date", sdf.format(outDataItem.getfDate()));

                // 入库名称
                outDataTest.put("materialName", outDataItem.getMaterialName());

                // 批次
                outDataTest.put("batchNo", outDataItem.getBatchNo());

                // 数量
                outDataTest.put("planPickedQty", outDataItem.getPlanPickedQty());

                // 仓位
                outDataTest.put("fName", outDataItem.getfName());

                // 保管人
                outDataTest.put("custos", outDataItem.getCustos());


                tempOutDataTest.add(outDataTest);

            }
            outDataExtTest.put("data", tempOutDataTest);

            String billTableData =  JSON.toJSONString( outDataExtTest);

            Object  bin =  outDataExtTest.get("data");

            System.out.println(billTableData);

            if(((ArrayList) bin).size() != 0){
                webSocketServer.sendOneMessage(item, billTableData);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }


    public void getTenDayIn(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{
            // 初始一个数组变量
            int[] a = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
            webSocketServer.sendOneMessage(item, Arrays.toString(a));
        }catch(Exception e){

        }

    }

    public void getTenDayOut(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{
            // 初始一个数组变量
            int[] a = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
            webSocketServer.sendOneMessage(item, Arrays.toString(a));
        }catch(Exception e){

        }

    }

}

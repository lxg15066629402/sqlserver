package com.toec.productscreen.business.socket;

import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.utils.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @Author Jone
 * @Date 2021/1/7 0007 8:50
 */

//@Async
@Component
// public class SendData extends Thread{
public class SendData{

    @Autowired
    private WebSocketServer webSocketServer;

    @Autowired
    private ProdectService prodectService;


    /**
     * 设置间隔时间
     */
    // @Scheduled(cron = "*/60 * * * * ?") // * 任意取值
    @Scheduled(initialDelay=0, fixedDelay=1000*100)
    private void SendMessage(){

        try {

            // 获取 session 值，实现 对应的session 发送数据
            for( String  item:webSocketServer.webSocketSet.keySet())
                    // 加入判断信息

                    // 插装线
                    if (item.equals("1")) {
                        // 进行中的产品
                        //getDoingCheck(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        //getProductCheck(webSocketServer, prodectService, item);
                        // 按时完成情况
                        //getTimeCheck(webSocketServer, prodectService, item);
                        // 项目生产情况
                        //getTableCheck(webSocketServer, prodectService, item);

                        // 初始化对象
                        CheckInfo checkInfo = new CheckInfo();
                        // 进行中的产品
                        checkInfo.getDoingCheck(webSocketServer, prodectService,item);
                        // 今日计划完成情况
                        checkInfo.getProductCheck(webSocketServer, prodectService, item);
                        // 按时完成情况
                        checkInfo.getTimeCheck(webSocketServer, prodectService, item);
                        // 项目生产情况
                        checkInfo.getTableCheck(webSocketServer, prodectService, item);

                    }
                    // 总装线
                    else if(item.equals("2")){//
                        // 进行中的产品
                        // getDoingAssembly(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        // getProductAssembly(webSocketServer, prodectService, item);
                        // 按时完成情况
                        // getTimeAssembly(webSocketServer, prodectService, item);
                        // 项目生产情况
                        // getTableAssembly(webSocketServer, prodectService, item);

                        // 初始化对象
                        AssemblyInfo assemblyInfo = new AssemblyInfo();

                        // 进行中的产品
                        assemblyInfo.getDoingAssembly(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        assemblyInfo.getProductAssembly(webSocketServer, prodectService, item);
                        // 按时完成情况
                        assemblyInfo.getTimeAssembly(webSocketServer, prodectService, item);
                        // 项目生产情况
                        assemblyInfo.getTableAssembly(webSocketServer, prodectService, item);


                    }
                    // 整机测试线
                    else if(item.equals("3")){
//                        // 进行中的产品
//                        getDoingWhole(webSocketServer, prodectService, item);
//                        // 今日计划完成情况
//                        getProductWhole(webSocketServer, prodectService, item);
//                        // 按时完成情况
//                        getTimeWhole(webSocketServer, prodectService, item);
//                        // 项目生产情况
//                        getTableWhole(webSocketServer, prodectService, item);

                        // 初始化对象
                        WholeInfo wholeInfo = new WholeInfo();
                        
                        wholeInfo.getDoingWhole(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        wholeInfo.getProductWhole(webSocketServer, prodectService, item);
                        // 按时完成情况
                        wholeInfo.getTimeWhole(webSocketServer, prodectService, item);
                        // 项目生产情况
                        wholeInfo.getTableWhole(webSocketServer, prodectService, item);

                    }
                    // 老化区测试
                    else if(item.equals("4")) {
                        // 老化测试看板数据
                        // getOldData(webSocketServer, prodectService, item);
                        // 初始化对象
                        OldDataInfo oldDataInfo = new OldDataInfo();
                        
                        oldDataInfo.getOldData(webSocketServer, prodectService, item);
                    }
                    // 测试、维修线
                    else if(item.equals("5")) {

                        RepairInfo repairInfo = new RepairInfo();
                        // 今日维修完成情况
                        repairInfo.getTodayRepair(webSocketServer, prodectService, item);
                        // 今日维修不良统计
                        repairInfo.getRepairError(webSocketServer, prodectService, item);
                        // 一周维修数量趋势
                        repairInfo.getWeekRepair(webSocketServer, prodectService, item);
                        // 维修执行情况
                        repairInfo.getRepairTable(webSocketServer, prodectService, item);
                    }
                    // 部件1线看板
                    else if(item.equals("6")) {

                        PartsOneInfo partsOneInfo = new PartsOneInfo();
                        // 进行中的产品
                        partsOneInfo.getDoingPartsOne(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        partsOneInfo.getProductPartsOne(webSocketServer, prodectService, item);
                        // 按时完成情况
                        partsOneInfo.getTimePartsOne(webSocketServer, prodectService, item);
                        // 项目生产情况
                        partsOneInfo.getTablePartsOne(webSocketServer, prodectService, item);

                    }
                    // 部件2线看板
                    else if(item.equals("7")){

                        PartsTwoInfo partsTwoInfo = new PartsTwoInfo();
                        // 进行中的产品
                        partsTwoInfo.getDoingPartsTwo(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        partsTwoInfo.getProductPartsTwo(webSocketServer, prodectService, item);
                        // 按时完成情况
                        partsTwoInfo.getTimePartsTwo(webSocketServer, prodectService, item);
                        // 项目生产情况
                        partsTwoInfo.getTablePartsTwo(webSocketServer, prodectService, item);
                    }
                    // 电装%线看板
                    else if(item.equals("8")){

                        FittingInfo fittingInfo = new FittingInfo();
                        // 进行中的产品
                        fittingInfo.getDoingFitting(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        fittingInfo.getProductFitting(webSocketServer, prodectService, item);
                        // 按时完成情况
                        fittingInfo.getTimeFitting(webSocketServer, prodectService, item);
                        // 项目生产情况
                        fittingInfo.getTableFitting(webSocketServer, prodectService, item);
                    }
                    // 自动传动线
                    else if(item.equals("9")){

                        AutoInfo autoInfo = new AutoInfo();
                        // 进行中的产品
                        autoInfo.getDoingAuto(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        autoInfo.getProductAuto(webSocketServer, prodectService, item);
                        // 按时完成情况
                        autoInfo.getTimeAuto(webSocketServer, prodectService, item);
                        // 项目生产情况
                        autoInfo.getTableAuto(webSocketServer, prodectService, item);
                    }
                    // 包装线看板
                    else if(item.equals("10")){

                        PackingInfo packingInfo = new PackingInfo();
                        // 进行中的产品
                        packingInfo.getDoingPacking(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        packingInfo.getProductPacking(webSocketServer, prodectService, item);
                        // 按时完成情况
                        packingInfo.getTimePacking(webSocketServer, prodectService, item);
                        // 项目生产情况
                        packingInfo.getTablePacking(webSocketServer, prodectService, item);
                    }

                    // 1 电装贴片1线
                    else if(item.equals("11")){

                        SdmOneInfo sdmOneInfo = new SdmOneInfo();
                        // 进行中的产品
                        sdmOneInfo.getDoingSmdOne(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmOneInfo.getProductSmdOne(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmOneInfo.getTimeSmdOne(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmOneInfo.getTableSmdOne(webSocketServer, prodectService, item);
                    }
                    // 2 电装贴片2线
                    else if(item.equals("12")){

                        SdmTwoInfo sdmTwoInfo = new SdmTwoInfo();
                        // 进行中的产品
                        sdmTwoInfo.getDoingSmdTwo(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmTwoInfo.getProductSmdTwo(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmTwoInfo.getTimeSmdTwo(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmTwoInfo.getTableSmdTwo(webSocketServer, prodectService, item);
                    }
                    // 3 电装贴片3线
                    else if(item.equals("13")){

                        SdmThreeInfo sdmThreeInfo = new SdmThreeInfo();
                        // 进行中的产品
                        sdmThreeInfo.getDoingSmdThree(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmThreeInfo.getProductSmdThree(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmThreeInfo.getTimeSmdThree(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmThreeInfo.getTableSmdThree(webSocketServer, prodectService, item);

                    }
                    // 4 电装贴片4线
                    else if(item.equals("14")){

                        SdmFourInfo sdmFourInfo = new SdmFourInfo();
                        // 进行中的产品
                        sdmFourInfo.getDoingSmdFour(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmFourInfo.getProductSmdFour(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmFourInfo.getTimeSmdFour(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmFourInfo.getTableSmdFour(webSocketServer, prodectService, item);
                    }
                    // 5 电装贴片5线
                    else if(item.equals("15")){

                        SdmFiveInfo sdmFiveInfo = new SdmFiveInfo();
                        // 进行中的产品
                        sdmFiveInfo.getDoingSmdFive(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmFiveInfo.getProductSmdFive(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmFiveInfo.getTimeSmdFive(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmFiveInfo.getTableSmdFive(webSocketServer, prodectService, item);
                    }
                    // 6 电装贴片6线
                    else if(item.equals("16")){

                        SdmSixInfo sdmSixInfo = new SdmSixInfo();
                        // 进行中的产品
                        sdmSixInfo.getDoingSmdSix(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmSixInfo.getProductSmdSix(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmSixInfo.getTimeSmdSix(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmSixInfo.getTableSmdSix(webSocketServer, prodectService, item);
                    }
                    // 电装贴片7线
                    else if(item.equals("17")){

                        SdmSevenInfo sdmSevenInfo = new SdmSevenInfo();
                        // 进行中的产品
                        sdmSevenInfo.getDoingSmdSeven(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        sdmSevenInfo.getProductSmdSeven(webSocketServer, prodectService, item);
                        // 按时完成情况
                        sdmSevenInfo.getTimeSmdSeven(webSocketServer, prodectService, item);
                        // 项目生产情况
                        sdmSevenInfo.getTableSmdSeven(webSocketServer, prodectService, item);
                    }
                    // 测试拉看板
                    else if(item.equals("18")){

                        TestInfo testInfo = new TestInfo();
                        // 进行中的产品
                        testInfo.getDoingTest(webSocketServer, prodectService, item);
                        // 今日计划完成情况
                        testInfo.getProductTest(webSocketServer, prodectService, item);
                        // 按时完成情况
                        testInfo.getTimeTest(webSocketServer, prodectService, item);
                        // 项目生产情况
                        testInfo.getTableTest(webSocketServer, prodectService, item);
                    }
                    // 仓库看板
                    else if(item.equals("19")) {

                        BillInfo billInfo = new BillInfo();
                        // 今日备料完成率
                        billInfo.getTodayBill(webSocketServer, prodectService, item);
                        // 一周备料频次趋势
                        billInfo.getBillWeek(webSocketServer, prodectService, item);
                        // 备料执行情况
                        billInfo.getBillTable(webSocketServer, prodectService, item);
                    }

                    //
                    else if(item.equals("20")){
                        HouseInfo houseInfo = new HouseInfo();
                        // 入库
                        houseInfo.getIn(webSocketServer, prodectService, item);

                        houseInfo.getOut(webSocketServer, prodectService, item);

                        houseInfo.getTenDayIn(webSocketServer, prodectService, item);

                        houseInfo.getTenDayIn(webSocketServer, prodectService, item);
                    }

            }catch(Exception e){
                 e.printStackTrace();
            }

    }

}

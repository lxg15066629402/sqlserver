package com.toec.productscreen.business.entity;

import java.util.Date;

/**
 * @Author Jone
 * @Date 2021/2/8 0008 22:58
 */


public class PlMaterialPickDetail {

    // 1
    private int id;

    // 2
    private Date ts;

    // 3
    private int materialPickMainID;

    // 4
    private int prdppBomID;

    // 5
    private String prdppBomBillNo;

    // 6
    private int fEntryId;

    // 7
    private String fOperID;

    // 8
    private String fProcess;

    // 9
    private String fReplaceGroup;

    // 10
    private String  materialID;

    // 11
    private String materialCode;

    // 12
    private String materialName;

    // 13
    private String materialModel;

    // 14
    private int planPickedQty;

    // 15
    private int checkAmount;

    // 16
    private int srcStockId;

    // 17
    private int srcStockLocId;

    // 18
    private int destStockId;

    // 19
    private int destStockLocId;

    // 20
    private String batchNo;

    // 21
    private int linkEntryId;

    // 22
    private boolean isNeedTrack;

    // 23
    private String icStockOutJoinBillNo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getTs() {
        return ts;
    }

    public void setTs(Date ts) {
        this.ts = ts;
    }

    public int getMaterialPickMainID() {
        return materialPickMainID;
    }

    public void setMaterialPickMainID(int materialPickMainID) {
        this.materialPickMainID = materialPickMainID;
    }

    public int getPrdppBomID() {
        return prdppBomID;
    }

    public void setPrdppBomID(int prdppBomID) {
        this.prdppBomID = prdppBomID;
    }

    public String getPrdppBomBillNo() {
        return prdppBomBillNo;
    }

    public void setPrdppBomBillNo(String prdppBomBillNo) {
        this.prdppBomBillNo = prdppBomBillNo;
    }

    public int getfEntryId() {
        return fEntryId;
    }

    public void setfEntryId(int fEntryId) {
        this.fEntryId = fEntryId;
    }

    public String getfOperID() {
        return fOperID;
    }

    public void setfOperID(String fOperID) {
        this.fOperID = fOperID;
    }

    public String getfProcess() {
        return fProcess;
    }

    public void setfProcess(String fProcess) {
        this.fProcess = fProcess;
    }

    public String getfReplaceGroup() {
        return fReplaceGroup;
    }

    public void setfReplaceGroup(String fReplaceGroup) {
        this.fReplaceGroup = fReplaceGroup;
    }

    public String getMaterialID() {
        return materialID;
    }

    public void setMaterialID(String materialID) {
        this.materialID = materialID;
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName;
    }

    public String getMaterialModel() {
        return materialModel;
    }

    public void setMaterialModel(String materialModel) {
        this.materialModel = materialModel;
    }

    public int getPlanPickedQty() {
        return planPickedQty;
    }

    public void setPlanPickedQty(int planPickedQty) {
        this.planPickedQty = planPickedQty;
    }

    public int getCheckAmount() {
        return checkAmount;
    }

    public void setCheckAmount(int checkAmount) {
        this.checkAmount = checkAmount;
    }

    public int getSrcStockId() {
        return srcStockId;
    }

    public void setSrcStockId(int srcStockId) {
        this.srcStockId = srcStockId;
    }

    public int getSrcStockLocId() {
        return srcStockLocId;
    }

    public void setSrcStockLocId(int srcStockLocId) {
        this.srcStockLocId = srcStockLocId;
    }

    public int getDestStockId() {
        return destStockId;
    }

    public void setDestStockId(int destStockId) {
        this.destStockId = destStockId;
    }

    public int getDestStockLocId() {
        return destStockLocId;
    }

    public void setDestStockLocId(int destStockLocId) {
        this.destStockLocId = destStockLocId;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public int getLinkEntryId() {
        return linkEntryId;
    }

    public void setLinkEntryId(int linkEntryId) {
        this.linkEntryId = linkEntryId;
    }

    public boolean isNeedTrack() {
        return isNeedTrack;
    }

    public void setNeedTrack(boolean needTrack) {
        isNeedTrack = needTrack;
    }

    public String getIcStockOutJoinBillNo() {
        return icStockOutJoinBillNo;
    }

    public void setIcStockOutJoinBillNo(String icStockOutJoinBillNo) {
        this.icStockOutJoinBillNo = icStockOutJoinBillNo;
    }
}

package com.toec.productscreen.business.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.toec.productscreen.business.entity.PlAssemblyPlanDetail;
import com.toec.productscreen.business.service.first.ProdectService;
import com.toec.productscreen.business.socket.WebSocketServer;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author : Jone
 * @date : 21:47 2021/3/8 0008
 * @function :
 */
public class SdmSevenInfo {

    /**
     * 电装贴片7线
     * item=17
     */
    /**
     * 进行中项目
     * @param item = 17
     */
    public void getDoingSmdSeven(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{

            List<PlAssemblyPlanDetail> doingPartsOneTest =  prodectService.findDoingSmdSevenData();

            // 创建一个map 对象
            Map<String, Object> doingPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempPartsOneExtTest=new ArrayList<>();
            // 初始化信息
            doingPartsOneExtTest.put("code", 0);
            doingPartsOneExtTest.put("type", "1");

            for(PlAssemblyPlanDetail doingPartsOneTestItem: doingPartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> doingoneTest = new LinkedHashMap<String, Object>();

                // 计划数量
                doingoneTest.put("quantity", doingPartsOneTestItem.getQuantity());

                // 累计数量  --  完成数量
                doingoneTest.put("completeNumber", doingPartsOneTestItem.getComputerNumber());

                // 物料型号  -- 产品型号
                doingoneTest.put("materialID", doingPartsOneTestItem.getMaterialID());

                // 计划完成时间
                doingoneTest.put("completeTime", doingPartsOneTestItem.getOfflineTime());

                tempPartsOneExtTest.add(doingoneTest);

            }
            doingPartsOneExtTest.put("data", tempPartsOneExtTest);
            // Json 序列化
            String doingOneData = JSON.toJSONString(doingPartsOneExtTest); //

            Object o = doingPartsOneExtTest.get("data");

            System.out.println(doingOneData);

            if(((ArrayList) o).size() != 0){
                webSocketServer.sendOneMessage(item, doingOneData);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }


    /**
     * 今日计划数据
     * @param item=17
     */
    public void getProductSmdSeven(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{

            List<PlAssemblyPlanDetail> partsWeekOneTest = prodectService.findWeekSmdSevenData();
            // 创建一个map 对象
            Map<String, Object> weekTodayPartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTodayPartsOneExtTest=new ArrayList<>();
            weekTodayPartsOneExtTest.put("code", 0);
            weekTodayPartsOneExtTest.put("type", "2");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int completesum = 0;

            int productsum1 = 0;
            int completesum1 = 0;

            int productsum2 = 0;
            int completesum2 = 0;

            int productsum3 = 0;
            int completesum3 = 0;

            int productsum4 = 0;
            int completesum4 = 0;

            int productsum5 = 0;
            int completesum5 = 0;

            int productsum6 = 0;
            int completesum6 = 0;

            int productsum7 = 0;
            int completesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsonproduct = new JSONArray();

            // 并获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail partsWeekOneTestItem: partsWeekOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date datecSql = ft.parse(partsWeekOneTestItem.getOfflineTime());
                cSql.setTime(datecSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + partsWeekOneTestItem.getQuantity();
                    completesum = completesum + partsWeekOneTestItem.getComputerNumber();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + partsWeekOneTestItem.getQuantity();
                    completesum1 = completesum1 + partsWeekOneTestItem.getComputerNumber();
                    // 周二
                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + partsWeekOneTestItem.getQuantity();
                    completesum2 = completesum2 + partsWeekOneTestItem.getComputerNumber();
                    // 周三
                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + partsWeekOneTestItem.getQuantity();
                    completesum3 = completesum3 + partsWeekOneTestItem.getComputerNumber();
                    // 周四
                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + partsWeekOneTestItem.getQuantity();
                    completesum4 = completesum4 + partsWeekOneTestItem.getComputerNumber();
                    // 周五
                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + partsWeekOneTestItem.getQuantity();
                    completesum5 = completesum5 + partsWeekOneTestItem.getComputerNumber();
                    // 周六
                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + partsWeekOneTestItem.getQuantity();
                    completesum6 = completesum6 + partsWeekOneTestItem.getComputerNumber();
                    // 周日
                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + partsWeekOneTestItem.getQuantity();
                    completesum7 = completesum7 + partsWeekOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)completesum /   (float)productsum;

            // 今日计划完成率
            weekOneTest.put("completeRate", (int)(rate*100));
            // 计划数量
            weekOneTest.put("productNumber", productsum);
            // 完成数量
            weekOneTest.put("completeNumber", completesum);

            if(productsum1 != 0){
                float rate1 = (float) completesum1  / (float)  productsum1;
                // jsonproduct.add(rate1*100);
                jsonproduct.add((int)rate1*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum1 != 0) {
                float rate2 = (float) completesum2 / (float) productsum2;
                // jsonproduct.add(rate2*100);
                jsonproduct.add((int)rate2*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 = (float) completesum3  /  (float) productsum3;
                // jsonproduct.add(rate3*100);
                jsonproduct.add((int)rate3*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)completesum4  /   (float)productsum4;
                // jsonproduct.add(rate4*100);
                jsonproduct.add((int)rate4*100);
            }else{
                jsonproduct.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)completesum5  /  (float) productsum5;
                // jsonproduct.add(rate5*100);
                jsonproduct.add((int)rate5*100);
            }else{
                jsonproduct.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)completesum6 /  (float)productsum6;
                // jsonproduct.add(rate6*100);
                jsonproduct.add((int)rate6*100);
            }else{
                jsonproduct.add(0.0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)completesum7  / (float)productsum7;
                // jsonproduct.add(rate7*100);
                jsonproduct.add((int)rate7*100);
            }else{
                jsonproduct.add(0);
            }

            // 计划完成一周趋势
            weekOneTest.put("weekCompleteRate", jsonproduct);
            tempTodayPartsOneExtTest.add(weekOneTest);

            weekTodayPartsOneExtTest.put("data", tempTodayPartsOneExtTest);
            // Json 序列化
            String oneData = JSON.toJSONString(weekTodayPartsOneExtTest); //

            System.out.println(oneData);

            webSocketServer.sendOneMessage(item, oneData);

        }catch(Exception e){
            e.printStackTrace();
        }
    }


    /**
     * 按时完成情况
     * @param item=17
     */
    public void getTimeSmdSeven(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{

            List<PlAssemblyPlanDetail> timePartsOneTest = prodectService.findWeektimeSmdSevenData();

            // 创建一个map 对象
            Map<String, Object> weekTimePartsOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTimePartsOneExtTest=new ArrayList<>();

            weekTimePartsOneExtTest.put("code", 0);
            weekTimePartsOneExtTest.put("type", "3");

            // 获取当日数据
            Date date = new Date();

            int productsum = 0;
            int timeCompletesum = 0;
            // String completeTime = "";

            int productsum1 = 0;
            int timeCompletesum1 = 0;

            int productsum2 = 0;
            int timeCompletesum2 = 0;

            int productsum3 = 0;
            int timeCompletesum3 = 0;

            int productsum4 = 0;
            int timeCompletesum4 = 0;

            int productsum5 = 0;
            int timeCompletesum5 = 0;

            int productsum6 = 0;
            int timeCompletesum6 = 0;

            int productsum7 = 0;
            int timeCompletesum7 = 0;

            SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, Object> weekTimeOneTest = new LinkedHashMap<String, Object>();

            JSONArray jsontime = new JSONArray();

            // 获取今天是周几
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int weekday = c.get(Calendar.DAY_OF_WEEK);

            for(PlAssemblyPlanDetail timePartsOneTestItem: timePartsOneTest){

                Calendar cSql = Calendar.getInstance();
                // String 转化为 Date 类型
                Date dateSql = ft.parse(timePartsOneTestItem.getOfflineTime());
                cSql.setTime(dateSql);
                int weekdaysql = cSql.get(Calendar.DAY_OF_WEEK);

                if(weekdaysql == weekday){
                    productsum = productsum + timePartsOneTestItem.getQuantity();
                    timeCompletesum = timeCompletesum + timePartsOneTestItem.getComputerNumber();
                    // completeTime = timePartsOneTestItem.getOfflineTime();

                }
                // 周一
                if(weekdaysql == 2){
                    productsum1 = productsum1 + timePartsOneTestItem.getQuantity();
                    timeCompletesum1 = timeCompletesum1 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 3){
                    productsum2 = productsum2 + timePartsOneTestItem.getQuantity();
                    timeCompletesum2 = timeCompletesum2 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 4){
                    productsum3 = productsum3 + timePartsOneTestItem.getQuantity();
                    timeCompletesum3 = timeCompletesum3 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 5){
                    productsum4 = productsum4 + timePartsOneTestItem.getQuantity();
                    timeCompletesum4 = timeCompletesum4 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 6){
                    productsum5 = productsum5 + timePartsOneTestItem.getQuantity();
                    timeCompletesum5 = timeCompletesum5 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 7){
                    productsum6 = productsum6 + timePartsOneTestItem.getQuantity();
                    timeCompletesum6 = timeCompletesum6 + timePartsOneTestItem.getComputerNumber();

                }else if(weekdaysql == 0){
                    productsum7 = productsum7 + timePartsOneTestItem.getQuantity();
                    timeCompletesum7 = timeCompletesum7 + timePartsOneTestItem.getComputerNumber();

                }

            }

            float rate =  (float)timeCompletesum  /   (float)productsum;
            // 按时完成率
            weekTimeOneTest.put("timeRate", (int)(rate*100));
            // 预计完成时间
            // weekTimeOneTest.put("completeTime", completeTime);
            // 计划数量
            weekTimeOneTest.put("productNumber", productsum);
            // 完成数量
            weekTimeOneTest.put("timeCompleteNumber", timeCompletesum);

            if(productsum1 != 0){
                float rate1 =  (float)timeCompletesum1  /   (float)productsum1;
                // jsontime.add(rate1*100);
                jsontime.add((int)rate1*100);
            }else{
                jsontime.add(0);
            }

            if(productsum2 != 0) {
                float rate2 = (float)timeCompletesum2 / (float)productsum2;
                // jsontime.add(rate2*100);
                jsontime.add((int)rate2*100);
            }else{
                jsontime.add(0);
            }

            if(productsum3 !=0 ){
                float rate3 =  (float)timeCompletesum3  / (float)productsum3;
                // jsontime.add(rate3*100);
                jsontime.add((int)rate3*100);
            }else{
                jsontime.add(0);
            }

            if(productsum4 !=0 ) {
                float rate4 =  (float)timeCompletesum4  /  (float)productsum4;
                // jsontime.add(rate4*100);
                jsontime.add((int)rate4*100);
            }else{
                jsontime.add(0);
            }

            if(productsum5 !=0 ){
                float rate5 =  (float)timeCompletesum5  /  (float)productsum5;
                // jsontime.add(rate5*100);
                jsontime.add((int)rate5*100);
            }else{
                jsontime.add(0);
            }

            if( productsum6 !=0 ){
                float rate6 =  (float)timeCompletesum6 /  (float)productsum6;
                // jsontime.add(rate6*100);
                jsontime.add((int)rate6*100);
            }else{
                jsontime.add(0);
            }
            if(productsum7 !=0){
                float rate7 =  (float)timeCompletesum7  /  (float)productsum7;
                // jsontime.add(rate7*100);
                jsontime.add((int)rate7*100);
            }else{
                jsontime.add(0);
            }

            weekTimeOneTest.put("weekTimeRate", jsontime);

            tempTimePartsOneExtTest.add(weekTimeOneTest);

            weekTimePartsOneExtTest.put("data", tempTimePartsOneExtTest);
            // weekTimePartsOneExtTest.put("data", JSONObject.parse(JSONArray.toJSONString(tempTimePartsOneExtTest, SerializerFeature.DisableCircularReferenceDetect)));
            // Json 序列化
            String oneData = JSON.toJSONString(weekTimePartsOneExtTest); //

            System.out.println(oneData);

            webSocketServer.sendOneMessage(item, oneData);


        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * 项目生产执行情况
     * @param item=17
     */
    public void getTableSmdSeven(WebSocketServer webSocketServer, ProdectService prodectService, String item){

        try{

            List<PlAssemblyPlanDetail> tablePartsOneTest =  prodectService.findTableSmdSevenData();
            // 创建一个map 对象
            Map<String, Object> tableOneExtTest = new LinkedHashMap<String, Object>();
            // 创建一个List 对象
            List<Map> tempTableOneTest=new ArrayList<>();
            tableOneExtTest.put("code", 0);
            tableOneExtTest.put("type", "4");

            for(PlAssemblyPlanDetail partsOneTestItem: tablePartsOneTest){

                // 创建一个Map 对象
                Map<String, Object> tableOneTest = new LinkedHashMap<String, Object>();

                // 物料名称  -- 完成品号  -- 项目名称
                tableOneTest.put("materialName", partsOneTestItem.getMaterialName());
                // 工单号   --  任务单号
                // tableOneTest.put("worOrder", partsOneTestItem.getWorOrder());
                tableOneTest.put("worOrder", partsOneTestItem.getMoNo());
                // 开工
                if(partsOneTestItem.isUsing() == true){
                    tableOneTest.put("open", "开工");
                }else{
                    tableOneTest.put("open", " ");
                }


                if(partsOneTestItem.getQuantity() < partsOneTestItem.getAccumulateNumber()){
                    tableOneTest.put("doing", "进行中");
                }else{
                    tableOneTest.put("doing", "");
                }

                if(partsOneTestItem.getQuantity() == partsOneTestItem.getComputerNumber()){
                    tableOneTest.put("complete", "完成");
                }else{
                    tableOneTest.put("complete", "");
                }
//                // 进行中
//                if( partsOneTestItem.isUsing() == true && partsOneTestItem.getCompleted2() == false){
//                    tableOneTest.put("doing", "进行中");
//                }else{
//                    tableOneTest.put("doing", "");
//                }
//
//                // 完成
//                if( partsOneTestItem.isUsing() != true && partsOneTestItem.getCompleted2() == true){
//                    tableOneTest.put("complete", "完成");
//                }else{
//                    tableOneTest.put("complete", "");
//                }

                // 物料编码  -- 产品编码
                tableOneTest.put("materialCode", partsOneTestItem.getMaterialCode());
                // 物料型号  -- 产品型号  -- 生产类型
                // tableOneTest.put("materialID", partsOneTestItem.getMaterialID());
                tableOneTest.put("materialID", partsOneTestItem.getMoType());
                // 计划数量
                tableOneTest.put("quantity", partsOneTestItem.getQuantity());
                // 完成数量
                tableOneTest.put("completeNumber", partsOneTestItem.getAccumulateNumber());
                // 下线数量
                tableOneTest.put("offlineNumber", partsOneTestItem.getOfflineNumber());
                // 直通率
                float rolledRate = (partsOneTestItem.getQuantity() -  partsOneTestItem.getOfflineNumber()) / partsOneTestItem.getQuantity();
                tableOneTest.put("rolledRate", rolledRate);
                tempTableOneTest.add(tableOneTest);

            }
            tableOneExtTest.put("data", tempTableOneTest);
            // Json 序列化
            String oneData = JSON.toJSONString(tableOneExtTest); //

            Object to  = tableOneExtTest.get("data");

            System.out.println(oneData);

            if(((ArrayList) to).size() != 0){
                webSocketServer.sendOneMessage(item, oneData);
            }

        }catch(Exception e){
            e.printStackTrace();
        }

    }

}

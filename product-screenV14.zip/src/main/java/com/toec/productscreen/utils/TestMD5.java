package com.toec.productscreen.utils;


import org.apache.commons.codec.digest.DigestUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * @Author Jone
 * @Date 2021/1/5 0005 11:45
 */

/**
 * MD5 数据加密
 * 数据加密的基本过程就是对原来为明文的文件或数据按某种加密算法进行处理，
 * 使其成为一段不可读的代码，通常称为“密文”，通过这种途径来达到保护原始数据的目的。
 * 通过解密方法或秘钥，经过解密过程，可以将密文还原成可读的原文。
 *
 * md5加密是我们常用的一种加密算法，可以对明文进行处理产生一个128位（16字节）的散列值，
 * 为了便于展示和读写一般将128位的二进制数转换成32位16进制数（如：655A6E9A375DF4F82B730833C807AADD）。
 * 通常用在密码存储和文件的完整性校验上
 *
 * Java中提供了MessageDigest类为应用程序提供信息摘要算法的功能，如 MD5 或 SHA 算法。
 *
 * MD5加密的应用
 *
 * 1.对密码进行加密，移动端会将用户密码通过MD5加密转换后发送给服务器，服务器会在数据库中保存加密后的md5值。
 * 这样做的好处是不会直接发送明文密码、服务器管理人员也无法确切的知道密码。但是一旦拿到密码的md5值后仍然存在被暴力破解的可能性。
 *
 * 2.文件的完整性校验，在传递文件的过程中附带传递文件的md5值，接收端通过比较文件的md5值判断文件的完整性。
 *
 * 增强MD5的安全性
 *
 */

public class TestMD5 {


     public static void main(String args[]){

         StringBuilder token = new StringBuilder("token:");

         String password = "123456";
         //加密的用户名
         token.append(DigestUtils.md5Hex(password) + "-");
         //时间
         token.append(new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()) + "-");
         //六位随机字符串
         token.append(new Random().nextInt(999999 - 111111 + 1) + 111111 );
         System.out.println("token-->" + token.toString());

         // password + md5 实现密码保护
         String info = "toec";
         String result = password + info;
         System.out.println("resultNd5 ************************" + result);
         System.out.println("MD5 result: " + DigestUtils.md5Hex(result));
         //    e0a2456e0943997d816485a5c057b4c7
         // set admin "e0a2456e0943997d816485a5c057b4c7"  e0a2456e0943997d816485a5c057b4c7
         // "token":"YgqqWRTbreossiYysWfrfdEgyibWbhjW"
     }

}

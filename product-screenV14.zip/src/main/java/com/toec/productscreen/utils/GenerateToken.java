package com.toec.productscreen.utils;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Random;


/**
 * @Author Jone
 * @Date 2021/1/5 0005 14:47
 */

@Component
public class GenerateToken {

    public String getToken(){
        int length = 32;
        String str= "zxcvbnmlkjhgfdsaqwertyuiopQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
        //由Random生成随机数
        Random random=new Random();
        StringBuffer sb = new StringBuffer();

        for(int i=0; i<length; ++i){
            //产生0-31的数字
            int number=random.nextInt(32);
            //将产生的数字通过length次承载到sb中
            sb.append(str.charAt(number));
        }
        System.out.println(sb.toString());
        return sb.toString();

    }
}

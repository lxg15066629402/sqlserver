package com.toec.productscreen.sys.controller;


import com.toec.productscreen.sys.entity.User;
import com.toec.productscreen.sys.service.serviceImpl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;


/**
 * @Author Jone
 * @Date 2021/1/5 0005 11:11
 */

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    private static Cookie cookie;

    /**
     * // @RequestParam(value = "username1",required = true)String userName,
     *                         // @RequestParam传递的参数格式是param格式
     *                         // username1和前端传递的参数一致，
     *                         //String userName,可以和前端不一致
     */

    // 添加此行，处理跨域问题
    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")

    // POST 方式
    public String login(HttpServletResponse response, @RequestBody User user){

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE");

        System.out.println("================前端发送过来的用户名" + user.getUsername());
        System.out.println("================前端发送过来的密码" + user.getPassword());
        String logininfor = userServiceImpl.login(user.getUsername(), user.getPassword());

        return logininfor;
    }

    /**
     * 登出接口
     * @param user  用户名
     * @return
     */
    @CrossOrigin(origins = "*")
    @RequestMapping(value = "/logout", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String logout(HttpServletResponse response, @RequestBody User user){

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE");
        // 打印输出
        System.out.println("================前端发送过来的用户名 " + user.getUsername());
        System.out.println("================前端发送过来的令牌 " + user.getToken());
        String logoutinfor = userServiceImpl.logout(user.getUsername(), user.getToken());

        return logoutinfor;
    }
}

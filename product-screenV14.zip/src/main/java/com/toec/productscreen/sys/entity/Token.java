package com.toec.productscreen.sys.entity;

/**
 * @Author Jone
 * @Date 2021/1/6 0006 13:39
 */


public class Token {

    private String token;
    private String expire;

    public String getToken() {
        return token;
    }

    public String getExpire() {
        return expire;
    }
}

package com.toec.productscreen.sys.entity;

/**
 * @Author Jone
 * @Date 2021/1/5 0005 9:28
 */

/**
 * 用户类
 */
public class User {

    // 定义用户名、密码、token
    private String username;
    private String password;
    private String token;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}

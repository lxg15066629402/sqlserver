package com.toec.productscreen.sys.service.serviceImpl;


import com.alibaba.fastjson.JSONObject;
import com.toec.productscreen.sys.service.TokenService;
import com.toec.productscreen.sys.service.UserService;
import com.toec.productscreen.utils.GenerateToken;
import com.toec.productscreen.utils.RedisUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import com.alibaba.fastjson.JSON;
import org.springframework.stereotype.Service;


import javax.annotation.Resource;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @Author Jone
 * @Date 2021/1/5 0005 13:20
 */

/**
 * 登录、登出接口的实现
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private TokenService tokenService;

    @Autowired
    private GenerateToken generateToken;

    // private String token;
    // 定义一个全局变量
    public  static String token;

    Map<String, Object> map = new HashMap<String, Object>(new LinkedHashMap());
    JSONObject jsonData = new JSONObject(new LinkedHashMap());

    @Resource
    private RedisTemplate<String, String> redisTemplate;

    /**
     * 实现登录接口
     * @param username  用户名
     * @param password  密码
     * @return  返回输出结果
     */
    public String login(String username, String password){


        //  读取redis 数据库中的 用户名和密码
        String redisUsername = "admin";
        // 类型转化
        String redisPassword = (String)redisUtil.get(redisUsername);

        // 首先对前端获取到的密码进行加密操作
        String info = "toec";
        String resultMd5 = password + info;

        System.out.println("resultNd5 ************************" + resultMd5);

        String newPassword = DigestUtils.md5Hex(resultMd5);
        System.out.println("MD5 result ==============================" + newPassword);

        // 进行判断 "admin"    redisPassword = null
        // redisTemplate.opsForValue().get("admin");
        //String redisPassword = "e0a2456e0943997d816485a5c057b4c7";

        if(redisUsername.equals(username) && redisPassword.equals(newPassword)){

            // 产生token
            token = generateToken.getToken();

            // 保存token
            tokenService.save(token, username);

            // 验证成功
            map.put("code", 200);
            map.put("result", jsonData);

            jsonData.put("token", token);

            // 不设置过期时间
            // jsonData.put("expire", 1800);

            map.put("message", "登录成功");


        }else if(!redisPassword.equals(newPassword)){
            // 密码错误
            map.put("code", 201);
            // map.put("result", null);
            map.put("result", "");

            map.put("message", "用户名密码错误");

        }else if(!redisUsername.equals(username)){
            // 用户名不存在
            map.put("code", 202);
            // map.put("result", null);
            map.put("result", "");

            map.put("message", "用户名不存在");
        }

        String mapResult = JSON.toJSONString(map);
        return  mapResult;
    }


    public String logout(String username, String token){

        // 判断token 是否存在
        if(redisUtil.hasKey(token)){
            // 删除 redis 中的 token
            redisUtil.del(token);

            map.put("code", 200);
            // map.put("result", null);
            map.put("result", "");

            map.put("message", "登出成功");

        }else {
            // 令牌不存在或者超出时间
            map.put("code", 210);
            map.put("result", null);

            map.put("message", "令牌不存在或已过期");
        }
        // 反序列化
        String mapResult = JSON.toJSONString(map);
        return mapResult;
    }


}

package com.toec.productscreen.sys.service;

/**
 * @Author Jone
 * @Date 2021/1/5 0005 11:09
 */

/**
 * 初始化登录、登出接口
 */
public interface UserService {
    public String login(String username, String password);

    public String logout(String username, String password);
}

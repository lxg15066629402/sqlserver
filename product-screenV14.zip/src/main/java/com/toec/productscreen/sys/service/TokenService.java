package com.toec.productscreen.sys.service;

import com.toec.productscreen.utils.RedisUtil;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.util.Random;



/**
 * @Author Jone
 * @Date 2021/1/5 0005 10:57
*/

@Service("tokenService")
public class TokenService {

    @Resource
    private RedisUtil redisUtil;

    //生成token(格式为token:32位随机数)
    public String generateToken(String userAgentStr, String username) {

        //32位随机字符串
        //定义一个字符串（A-Z，a-z，0-9）即62位；
        int length = 32;
        String str="zxcvbnmlkjhgfdsaqwertyuiopQWERTYUIOPASDFGHJKLZXCVBNM1234567890";
        //由Random生成随机数
        Random random=new Random();
        StringBuffer token =new StringBuffer();
        //长度为几就循环几次
        for(int i=0; i<length; ++i){
            //产生0-31的数字
            int number=random.nextInt(32);
            //将产生的数字通过length次承载到token中
            token.append(str.charAt(number));
        }

        //将承载的字符转换成字符串
        System.out.println("token-->" + token.toString());
        return token.toString();
    }


    /**
     * 把token存到redis中
     */
    public void save(String token, String name) {
        // 将 token 存储到Redis中， String key, String value
        redisUtil.set(token, name);

    }


    /**
     * 把token存到redis中，并加入过期时间
     */
    public void saveex(String token, String name) {
        // 将 token 存储到Redis中
        redisUtil.setex(token, name, 30*60);
        /**
        if (token.startsWith("token:PC")) {
            redisUtil.setex(token, JSONObject.toJSONString(user), 30*60);
        } else {
            redisUtil.set(token, JSONObject.toJSONString(user));
        }
         */
    }


}


